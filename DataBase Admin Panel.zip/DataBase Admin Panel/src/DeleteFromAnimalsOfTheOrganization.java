import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JTable;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;

import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Button;

public class DeleteFromAnimalsOfTheOrganization {

	private JFrame frame;
	private JTable table;
	private DefaultTableModel dm;
	/**
	 * Launch the application.
	 */
	public static void delete() {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					DeleteFromAnimalsOfTheOrganization window = new DeleteFromAnimalsOfTheOrganization();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public DeleteFromAnimalsOfTheOrganization() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 529, 323);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		table = new JTable();
		table.setForeground(Color.BLACK);
		//Add columns
		dm=(DefaultTableModel) table.getModel();
		dm.addColumn("Name");
		dm.addColumn("Ref.No ");
		dm.addColumn("Gender");
		dm.addColumn("Age");
		dm.addColumn("Adopted");
		dm.addColumn("Adoptors name");
		//Add rows
		String[] Row={"Name", "Ref. No", "Breed", "Gender", "Age", "Adopted", "Adoptors name"};
		dm.addRow(Row);
		String[]Row1= {"Max", "815", "Chihuahua", "Male", "5y", "Yes", "Sherlock"};
		dm.addRow(Row1);
		String []Row2={"Anne", "66", "Labrator", "Female", "3months", "No", null};
		dm.addRow(Row2);
		
		TableRowSorter<DefaultTableModel> tr=new TableRowSorter<DefaultTableModel>(dm);
		table.setRowSorter(tr);
		
		
		table.setBounds(10, 36, 493, 179);
		frame.getContentPane().add(table);
		
		JButton btnDelet = new JButton("Delete");
		btnDelet.setForeground(Color.RED);
		btnDelet.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(table.getSelectedRow()!=-1) {
				dm.removeRow(table.getSelectedRow());
				}
				else
					JOptionPane.showMessageDialog(null, "Please select a record");
			}
		});
		btnDelet.setBounds(218, 250, 89, 23);
		frame.getContentPane().add(btnDelet);
		
		JLabel lblDeleteFromTable = new JLabel("Delete From Table Animals Of The Organization");
		lblDeleteFromTable.setForeground(Color.RED);
		lblDeleteFromTable.setBounds(137, 11, 268, 14);
		frame.getContentPane().add(lblDeleteFromTable);
		
		Button button = new Button("<- Go Back");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				DeleteSelectDatabase.SelectTable();
				frame.setVisible(false);
			}
		});
		button.setBounds(0, 0, 70, 22);
		frame.getContentPane().add(button);
	}
}
