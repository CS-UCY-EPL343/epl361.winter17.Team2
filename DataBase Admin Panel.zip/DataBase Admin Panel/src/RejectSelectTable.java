import java.awt.Button;
import java.awt.Color;
import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;

public class RejectSelectTable {

	private JFrame frame;

	/**
	 * Launch the application.
	 */
	public static void reject() {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					RejectSelectTable window = new RejectSelectTable();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public RejectSelectTable() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel label = new JLabel("");
		label.setBounds(0, 0, 434, 0);
		frame.getContentPane().add(label);
		
		JButton btnNewButton = new JButton("Dogs Requests");
		btnNewButton.setForeground(Color.RED);
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				RejectDogRequest.reject();
				frame.setVisible(false);
			}
		});
		btnNewButton.setBounds(154, 102, 125, 23);
		frame.getContentPane().add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("Cats Requests");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				RejevtCatRequest.reject();
			}
		});
		btnNewButton_1.setForeground(Color.RED);
		btnNewButton_1.setBounds(154, 158, 125, 23);
		frame.getContentPane().add(btnNewButton_1);
		
		JLabel lblSelectATable = new JLabel("Select A Table From Were You would Like to Reject a request");
		lblSelectATable.setForeground(Color.RED);
		lblSelectATable.setBounds(81, 44, 305, 14);
		frame.getContentPane().add(lblSelectATable);
		
		JButton button = new JButton("<-Go Back");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				DB_initialView.main(null);
				frame.setVisible(false);
			}
		});
		button.setBounds(0, 0, 100, 23);
		frame.getContentPane().add(button);

	
	}
}