import java.awt.Color;
import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;
import java.awt.Button;

public class DeleteFromParticipants {

	private JFrame frame;
	private JTable table;
	private DefaultTableModel dm;
	/**
	 * Launch the application.
	 */
	public static void delete() {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					DeleteFromParticipants window = new DeleteFromParticipants();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public DeleteFromParticipants() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 529, 323);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		table = new JTable();
		table.setForeground(Color.BLACK);
		//Add columns
		dm=(DefaultTableModel) table.getModel();
		dm.addColumn("Name");
		dm.addColumn("Surname");
		dm.addColumn("Phone Number");
		dm.addColumn("Email");
		dm.addColumn("Number of Participants");
		//Add rows
		String[] Row={"Name", "Surname", "Phone Number", "Email", "Number of Participants"};
		dm.addRow(Row);
		String[]Row1= {"Shelrock", "Holmes", "35565021", "sherlock.Holmes@gmail.com", "3"};
		dm.addRow(Row1);
		String []Row2={"James", "Mac Avoy", "6565656", "james.macavo@gmail,com", "1"};
		dm.addRow(Row2);
		String []Row3={"Jane", "Austen", "656584121", "jane.austen@gmail,com", "3"};
		dm.addRow(Row3);

		
		TableRowSorter<DefaultTableModel> tr=new TableRowSorter<DefaultTableModel>(dm);
		table.setRowSorter(tr);
		
		
		table.setBounds(10, 36, 493, 179);
		frame.getContentPane().add(table);
		
		JButton btnDelet = new JButton("Delete");
		btnDelet.setForeground(Color.RED);
		btnDelet.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(table.getSelectedRow()!=-1)
				dm.removeRow(table.getSelectedRow());
				else
					JOptionPane.showMessageDialog(null, "Please select a record");
			}
		});
		btnDelet.setBounds(218, 250, 89, 23);
		frame.getContentPane().add(btnDelet);
		
		JLabel lblDeleteFromTable = new JLabel("Delete From Participants");
		lblDeleteFromTable.setForeground(Color.RED);
		lblDeleteFromTable.setBounds(199, 11, 268, 14);
		frame.getContentPane().add(lblDeleteFromTable);
		
		Button button = new Button("<- Go Back");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				DeleteSelectDatabase.SelectTable();
				frame.setVisible(false);
			}
		});
		button.setBounds(0, 0, 70, 22);
		frame.getContentPane().add(button);
	}
	}


