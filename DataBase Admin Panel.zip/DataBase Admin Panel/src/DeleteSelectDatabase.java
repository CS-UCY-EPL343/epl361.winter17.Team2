import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.AbstractListModel;
import java.awt.Color;
import javax.swing.JButton;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Button;

public class DeleteSelectDatabase {

	private JFrame frame;

	/**
	 * Launch the application.
	 */
	private DeleteFromAnimalsOfTheOrganization deleteFromAnimals;
	private DeleteFromParticipants deleteFromP;
	public static void SelectTable() {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					DeleteSelectDatabase window = new DeleteSelectDatabase();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public DeleteSelectDatabase() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblSelectATable = new JLabel("Select A Table from Below");
		lblSelectATable.setForeground(Color.RED);
		lblSelectATable.setBounds(149, 28, 148, 14);
		frame.getContentPane().add(lblSelectATable);
		
		JList list = new JList();
		list.setForeground(Color.RED);
		list.setModel(new AbstractListModel() {
			String[] values = new String[] {"1. All animals Of the Organization", "2. Participants",  "3. Report for stray Animal"};
			public int getSize() {
				return values.length;
			}
			public Object getElementAt(int index) {
				return values[index];
			}
		});
		list.setBounds(35, 72, 348, 89);
		frame.getContentPane().add(list);
		
		JButton btnSelectTable = new JButton("Select Table");
		btnSelectTable.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String selection=null;
				if(list.getSelectedValue()!=null) {
				selection=list.getSelectedValue().toString();
					if(selection.compareTo("1. All animals Of the Organization")==0 ) {
						deleteFromAnimals.delete();
						frame.setVisible(false);

					}
					else if(selection.compareTo("2. Participants")==0) {
						deleteFromP.delete();
						frame.setVisible(false);

					}
				
					else if(selection.compareTo("3. Report for stray Animal")==0) {
						DeleteReport.delete();
						frame.setVisible(false);
					}
				}
				else {
					JOptionPane.showMessageDialog(null, "Please select a Table");
					}
				
				}
			}
		
			
			
		
			);
		
	
		btnSelectTable.setFont(new Font("Tahoma", Font.PLAIN, 11));
		btnSelectTable.setBounds(157, 172, 102, 23);
		frame.getContentPane().add(btnSelectTable);
		
		Button button = new Button("<- Go Back");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				DB_initialView.main(null);
			}
		});
		button.setBounds(0, 0, 70, 22);
		frame.getContentPane().add(button);
		
		
		}
}
		
