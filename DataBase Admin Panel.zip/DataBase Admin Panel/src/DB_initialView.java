import java.awt.Color;
import java.awt.Dimension;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JButton;
import javax.swing.JTextField;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JFormattedTextField;
import java.awt.Button;
import java.awt.Choice;

public class DB_initialView {

	private JFrame frame;
	private JTextField textField;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					DB_initialView window = new DB_initialView();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	public void newHomeWindow() {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					DB_initialView window = new DB_initialView();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public DB_initialView() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 705, 318);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);

		JButton View = new JButton("Select a Record to View");
		View.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
			}
		});
		View.setForeground(Color.RED);
		View.setBounds(84, 59, 162, 23);
		frame.getContentPane().add(View);
		
		JButton SearchB = new JButton("Search A record");
		SearchB.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			
				}
			});
		
		SearchB.setForeground(Color.RED);

		SearchB.setBounds(84, 107, 162, 23);
		frame.getContentPane().add(SearchB);
		
		JButton Edit = new JButton("Edit");
		Edit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		Edit.setForeground(Color.RED);
		Edit.setBounds(371, 59, 162, 23);
		frame.getContentPane().add(Edit);
		
		JButton Insert = new JButton("Insert a record");
		Insert.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		Insert.setForeground(Color.RED);
		Insert.setBounds(84, 154, 162, 23);
		frame.getContentPane().add(Insert);
		
		JButton Delete = new JButton("Delete a record");
		Delete.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				DeleteSelectDatabase.SelectTable();
				frame.setVisible(false);
			}
		});
		Delete.setBounds(84, 204, 162, 23);
		frame.getContentPane().add(Delete);
		Delete.setForeground(Color.RED);
		
		JButton Reject = new JButton("Reject");
		Reject.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				RejectSelectTable.reject();
				frame.setVisible(false);
			}
		});
		Reject.setForeground(Color.RED);

		Reject.setBounds(371, 107, 162, 23);
		frame.getContentPane().add(Reject);
		
		JButton Accept = new JButton("Accept");
		Accept.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				AcceptSelectTable.accept();
				frame.setVisible(false);
			}
		});
		Accept.setForeground(Color.RED);

		Accept.setBounds(371, 154, 162, 23);
		frame.getContentPane().add(Accept);
		
		JButton LogOut = new JButton("Log Out");
		LogOut.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				frame.setVisible(false);
			}
		});
		LogOut.setForeground(Color.RED);

		LogOut.setBounds(371, 204, 162, 23);
		frame.getContentPane().add(LogOut);
		
		Button PreviousPage = new Button("<- Go Back");
		PreviousPage.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		PreviousPage.setBounds(10, 11, 70, 22);
		frame.getContentPane().add(PreviousPage);
		
		textField = new JTextField();
		textField.setText("Username of User Loged In");
		textField.setColumns(10);
		textField.setBounds(533, 0, 156, 20);
		frame.getContentPane().add(textField);
		
		
	}
}
