(function (window, $) {

    /* Plugin Constructor */

    var MozGrid = function(element, options) {
        this.element = $(element);
        this.options = options;
    };

    /* Plugin Prototype */

    MozGrid.prototype = {

        /**
         * Initializes the Plugin.
         */
        init: function()
        {
            var base = this;

            this.isEditingMode = false;
            this.componentID = $(this.element).data('cid');
            this.pageID = $(this.element).data('pid');

            $('.moze-change-layout').on('click touchend', function(e) {

                if (noClicks() || isSwipeTakingPlace) {
                    e.stopPropagation();
                    return false;
                }
                
                $.smartModalWindow({
                    href: '/m/pages-subtype-edit/params/pid/' + base.pageID + '/popup/1/',
                    title: '',
                    innerWidth: '90%',
                    innerHeight: '90%'
                });
                
                return false;
            });

            $('.moze-begin-layout').on('click touchend', function(e) {
                if (noClicks() || isSwipeTakingPlace) {
                    e.stopPropagation();
                    return false;
                }
                base.beginGridEditing();
                return false;
            });
        },

        /**
         * Initializes Grid button actions.
         */
        initActions: function()
        {
            var base = this;

            $('.mz_layout_overlay').off().on('click touchend', function(e) {
                
                if (noClicks() || isSwipeTakingPlace) {
                    e.stopPropagation();
                    return false;
                }

                // var element = document.elementFromPoint(e.pageX, e.pageY);

                base.endGridEditing();
                return false;
            });

            $('a.moze-layout-add').off().on('click touchend', function(e) {

                if (noClicks() || isSwipeTakingPlace) {
                    e.stopPropagation();
                    return false;
                }

                var row = $(this).parents('div.section-customizable');
                var rowID = (typeof row.data('rowid') !== 'undefined') ? row.data('rowid') : 0;
                var rowType = null;

                var method = 'after';
                if ($(this).parent('div').hasClass('is-first')) {
                    method = 'before';
                }

                $.smartModalWindow({
                    href: '/m/grid-row-add/',
                    title: LAY_ADD_CONTENT_BLOCK,
                    innerWidth: '90%',
                    innerHeight: '90%',
                    onClosed: function() {

                        rowType = this.result;

                        $.ajax({
                            url: '/m/grid-row-add-do/',
                            type: 'post',
                            data: {
                                component: base.componentID,
                                method: method,
                                row: rowID,
                                rowtype: rowType
                            },
                            success: function(response) {
                                if (response && response.error == false) {
                                    var newRow = $(response.html);
                                    if (row.length > 0) {
                                        if (method == 'before') {
                                            newRow.insertBefore(row);
                                        }
                                        if (method == 'after') {
                                            newRow.insertAfter(row);
                                        }
                                    }
                                    else {
                                        base.element.append(newRow)
                                        base.adjustAdd();
                                    }

                                    base.initComponents();
                                    base.initOverlays([ newRow.find('div.container') ]);
                                    base.adjustOverlays();
                                    newRow.find('.mz_layout_overlay:not(:visible)').fadeIn(500);
                                }
                            }
                        });
                    }
                });

                return false;
            });

            $('a.moze-layout-up').off().on('click touchend', function(e) {

                if (noClicks() || isSwipeTakingPlace) {
                    e.stopPropagation();
                    return false;
                }

                var currRow = $(this).parents('.section ');
                var prevRow = currRow.prev('.section');

                if (currRow.length > 0 && prevRow.length > 0) {

                    currRow.detach().insertBefore(prevRow);
                    base.adjustOverlays();

                    $.ajax({
                        url: '/m/grid-row-sort-do/',
                        type: 'post',
                        data: {
                            component: base.componentID,
                            ids: base.getRowIDs()
                        }
                    });
                }

                return false;
            });

            $('a.moze-layout-down').off().on('click touchend', function(e) {

                if (noClicks() || isSwipeTakingPlace) {
                    e.stopPropagation();
                    return false;
                }

                var currRow = $(this).parents('.section ');
                var nextRow = currRow.next('.section');

                if (currRow.length > 0 && nextRow.length > 0) {

                    currRow.detach().insertAfter(nextRow);
                    base.adjustOverlays();

                    $.ajax({
                        url: '/m/grid-row-sort-do/',
                        type: 'post',
                        data: {
                            component: base.componentID,
                            ids: base.getRowIDs()
                        }
                    });
                }

                return false;
            });

            $('a.moze-layout-delete').off().on('click touchend', function(e) {

                if (noClicks() || isSwipeTakingPlace) {
                    e.stopPropagation();
                    return false;
                }

                if (!confirm(LAY_CONFIRM_ROW_DELETE)) {
                    return false;
                }

                var currRow = $(this).parents('.section ');
                var currRowID = currRow.data('rowid');

                if (currRow.length > 0 && currRowID > 0) {

                    currRow.fadeOut(500, function() {
                        base.removeRowSplitters($(this).find('.container')[0]);
                        $(this).remove();
                        base.adjustAdd();
                        base.adjustOverlays();
                    });

                    $.ajax({
                        url: '/m/grid-row-delete-do/',
                        type: 'post',
                        data: {
                            component: base.componentID,
                            row: currRowID
                        }
                    });
                }

                return false;
            });

            $('a.moze-layout-gear').off().on('click touchend', function(e) {

                if (noClicks() || isSwipeTakingPlace) {
                    e.stopPropagation();
                    return false;
                }
                
                var row = $(this).parents('.section ');
                var rowID = row.data('rowid');
                var rowNewType = null;

                if (row.length > 0 && rowID > 0) {

                    $.smartModalWindow({
                        href: '/m/grid-row-change/',
                        title: LAY_CHANGE_CONTENT_BLOCK,
                        innerWidth: '90%',
                        innerHeight: '90%',
                        onClosed: function() {

                            rowNewType = this.result;

                            $.ajax({
                                url: '/m/grid-row-change-do/',
                                type: 'post',
                                data: {
                                    component: base.componentID,
                                    row: rowID,
                                    ntype: rowNewType
                                },
                                success: function(response) {
                                    if (response && response.error == false) {
                                        var newRow = $(response.html);
                                        if (row.length > 0) {
                                            base.removeRowSplitters(row.find('.container')[0]);
                                            row.replaceWith(newRow);
                                        }
                                        base.initComponents();
                                        base.initOverlays([ newRow.find('div.container') ]);
                                        base.adjustOverlays();
                                        newRow.find('.mz_layout_overlay:not(:visible)').show();
                                    }
                                }
                            });
                        }
                    });
                    
                }

                return false;
            });
        },

        /**
         * Initializes overlays and action buttons for the specified row.
         */
        initOverlays: function(rows)
        {
            var base = this;

            if (typeof rows == 'undefined') {
                rows = $('.section-customizable .container');
            }

            var overlayBar = $('<div>').addClass('mz_overlay_bar').addClass('mz_layout_overlay_bar');

            var buttons = $('<a>').addClass('moze-layout-gear')
            .add($('<a>').addClass('moze-layout-up'))
            .add($('<a>').addClass('moze-layout-down'))
            .add($('<a>').addClass('moze-layout-delete'));
            var buttonAdd = $('<a>').addClass('moze-layout-add').attr('title', LAY_ADD_CONTENT_BLOCK);

            $(rows).each(function() {

                var rowOverlayBar = overlayBar.clone().append(buttons.clone());
                var rowAddOverlayBar = overlayBar.clone().addClass('layout-plus').append(buttonAdd.clone());

                var overlay = $('<div>').addClass('mz_layout_overlay');
                if (overlay.is(':empty')) {
                    overlay.append(rowOverlayBar);
                    overlay.append(rowAddOverlayBar);
                }
                var itop =  parseInt($(this).css('padding-top')) - 7;
                var ibottom = parseInt($(this).css('padding-bottom')) - 7;
                overlay.css('top', itop);
                overlay.css('bottom', ibottom);

                if (base.isFirstRow($(this))) {
                    overlay.append(rowAddOverlayBar.clone().addClass('is-first'));
                }

                $(this).append(overlay);

                if (base.isFirstRow($(this))) {
                    overlay.find('a.moze-layout-up').hide();
                }
                if (base.isLastRow($(this))) {
                    overlay.find('a.moze-layout-down').hide();
                }

                // base.initSplitters(this);
            });

            base.initActions();
        },

        /**
         * Reinitializes Mozello components.
         */
        initComponents: function()
        {
            var base = this;

            $.mozbannerinit();
            $.mozgalleryinit();
            $.mozwysiwyginit();

            if (base.isEditingMode == true) {
                base.element.find('.mz_the_button_bar').hide();
            }
        },

        /**
         * Adjusts the add button, which allows adding rows to an empty grid.
         */
        adjustAdd: function()
        {
            var base = this;
            
            var html =
                '<div class="section selection-add">' +
                '<div class="container empty">' +
                '<div>' +
                '<div class="mz_overlay_bar mz_layout_overlay_bar layout-plus">' +
                '<a class="moze-layout-add" title="' + LAY_ADD_CONTENT_BLOCK + '">' + '</a>' +
                '</div>' +
                '</div>' +
                '</div>' +
                '</div>';

            var rows = base.element.find('.section-customizable .container');
            var addBtn = base.element.find('.selection-add');

            if (base.isEditingMode) {
                if (rows.length == 0) {
                    if (addBtn.length == 0) {
                        base.element.append($(html));
                        base.initActions();
                    }
                }
                else {
                    addBtn.remove();
                }
            }
            else {
                addBtn.remove();
            }
        },

        /**
         * Adjusts overlays and button after row actions.
         */
        adjustOverlays: function(rows)
        {
            var base = this;

            if (typeof rows == 'undefined') {
                rows = $('.section-customizable .container');
            }

            $(rows).each(function() {

                var overlay = $(this).find('.mz_layout_overlay');

                if (overlay.length > 0) {

                    // Fixes an existing overlay.

                    var itop =  parseInt($(this).css('padding-top')) - 7;
                    var ibottom = parseInt($(this).css('padding-bottom')) - 7;

                    overlay
                        .css('top', itop)
                        .css('bottom', ibottom);

                    if (base.isFirstRow($(this)) == false) {
                        overlay.find('.is-first').remove();
                    }
                    else {
                        var overlayBar = $('<div>').addClass('mz_overlay_bar').addClass('mz_layout_overlay_bar');
                        var buttonAdd = $('<a>').addClass('moze-layout-add').attr('title', LAY_ADD_CONTENT_BLOCK);
                        var rowAddOverlayBar = overlayBar.clone().addClass('layout-plus').append(buttonAdd.clone());
                        overlay.append(rowAddOverlayBar.clone().addClass('is-first'));
                    }

                    if (base.isFirstRow($(this))) {
                        overlay.find('a.moze-layout-up').hide();
                    }
                    else {
                        overlay.find('a.moze-layout-up').show();
                    }
                    if (base.isLastRow($(this))) {
                        overlay.find('a.moze-layout-down').hide();
                    }
                    else {
                        overlay.find('a.moze-layout-down').show();
                    }

                    base.initActions();
                }
            });
        },

        /**
         * Returns a list of row IDs in the correct order sequence.
         */
        getRowIDs: function()
        {
            var ids = new Array();
            $('.section-customizable').each(function() {
                ids.push($(this).data('rowid'));
            });

            return ids;
        },

        /**
         * Begins editing the grid.
         */
        beginGridEditing: function()
        {
            var base = this;

            base.isEditingMode = true;
            base.adjustAdd();

            $('.mz_the_button_bar, .section-backend-bottom').hide();
            $('.mz_overlay_bar:not(.layout-plus)').hide();

            base.initOverlays();

            var modeButtons = $('<a>')
                .addClass('moze-the-button ok green moze-end-layout')
                .text(LAY_END_EDITING)
                .on('click', function() {
                    base.endGridEditing();
                });

            var modeBar = $('<div id="mz_floating_bar">')
                .append($('<div>')
                .addClass('mz_the_button_bar')
                .append(modeButtons));

            $('body').append(modeBar);
            $('.mz_layout_overlay').fadeIn(500);
        },

        /**
         * Ends editing the grid.
         */
        endGridEditing: function()
        {
            var base = this;

            base.isEditingMode = false;
            base.adjustAdd();

            $('.mz_layout_overlay').fadeOut(500, function() { $(this).remove(); });
            $('.section-add').remove();
            $('.mz_layout_splitter').remove();
            $('.moze-end-layout').hide();
            $('.mz_overlay_bar').css('display', '');
            $('.mz_the_button_bar, .section-backend-bottom').show();
        },

        /**
         * Returns True if the specified row is the first row in the grid.
         */
        isFirstRow: function(row)
        {
            return $(row).parents('div.section-customizable').prev().length == 0;
        },

        /**
         * Returns True if the specified row is the last row in the grid.
         */
        isLastRow: function(row)
        {
            return $(row).parents('div.section-customizable').next().length == 0;
        },

        ///
        /// Splitter.
        ///

        /**
         * Returns the column size by the class name.
         */
        getDivWidthIn12: function(jqelem)
        {
            for (var i = 1; i <= 12; i++) {
                if (jqelem.hasClass('column-' + i + '-12')) {
                    return i;
                }
            }
            return 0;
        },

        /**
         * Initializes column splitters.
         */
        initSplitters: function(row)
        {
            var base = this;

            base.activesplitter = {
                startX: 0,
                startY: 0,
                moving: 0,
                elem: null,
                splitternum: 0,
                startColLeftSize12: 0,
                startColRightSize12: 0
            }

            if (row instanceof jQuery) {
                row = row[0];
            }
            base.removeRowSplitters(row);

            $(row).find('div.gridrow div[class^="column-"]').each(function(i, el) {

                if ($(el).nextAll('div[class^="column-"]').length > 0) {

                    var splitternum = $(el).prevAll('div[class^="column-"]').length;

                    $('<div>', {
                        class: 'mz_layout_splitter'
                    })
                    .appendTo('body')
                    .data('splitternum', splitternum)
                    .data('parentrow', row)
                    .on('mousedown', function(e) {
                        $(this).css({
                            width: $('body').width() - 2,
                            left: 0
                        });
                        $('.mz_layout_splitter').addClass('active');
                        base.activesplitter.startX = e.pageX;
                        base.activesplitter.startY = e.pageY;
                        base.activesplitter.moving = true;
                        base.activesplitter.splitternum = $(this).data('splitternum');

                        // Save start state: size in 1/12s of columns to the left and right of splitter
                        base.activesplitter.startColLeftSize12 = base.getDivWidthIn12($(row).find('div.gridrow div[class^=column-]:nth(' + base.activesplitter.splitternum + ')'));
                        base.activesplitter.startColRightSize12 = base.getDivWidthIn12($(row).find('div.gridrow div[class^=column-]:nth(' + (base.activesplitter.splitternum + 1) + ')'));
                    })
                    .on('mousemove', function(e) {
                        if (e.which != 1) {
                            base.activesplitter.moving = false;
                        }
                        if (base.activesplitter.moving) {
                            
                            var leftcell = $(row).find('div.gridrow div[class^=column-]:nth(' + base.activesplitter.splitternum + ')');
                            var rightcell = $(row).find('div.gridrow div[class^=column-]:nth(' + (base.activesplitter.splitternum + 1) + ')');

                            // Calculate current size in 1/12s of columns to the left and right of splitter
                            var width12_1 =  base.getDivWidthIn12(leftcell);
                            var width12_2 =  base.getDivWidthIn12(rightcell);

                            if (width12_1 > 0 && width12_2 > 0) {

                                var width12inpixels = leftcell.width() / width12_1;
                                var colChange = Math.round((e.pageX - base.activesplitter.startX) / width12inpixels);

                                // Constrain
                                if (base.activesplitter.startColLeftSize12 + colChange <= 0) {
                                    colChange = 1 - base.activesplitter.startColLeftSize12;
                                }
                                if (base.activesplitter.startColRightSize12 - colChange <= 0) {
                                    colChange = base.activesplitter.startColRightSize12 - 1;   // Reverse because of different direction
                                }

                                if (base.activesplitter.startColLeftSize12 + colChange != width12_1 &&   // If column width changed by dragging
                                    base.activesplitter.startColLeftSize12 + colChange > 0 &&            // Just extra check if constraints fail
                                    base.activesplitter.startColRightSize12 - colChange > 0) {           // Just extra check if constraints fail
                                        leftcell.removeClass('column-' + width12_1 + '-12');
                                        rightcell.removeClass('column-' + width12_2 + '-12');
                                        leftcell.addClass('column-' + (base.activesplitter.startColLeftSize12 + colChange) + '-12');
                                        rightcell.addClass('column-' + (base.activesplitter.startColRightSize12 - colChange) + '-12');
                                }
                            }
                        }
                    })
                    .on('mouseup', function(e) {
                        base.activesplitter.moving = false;
                        base.splitterChangedDone($(this));
                        $('.mz_layout_splitter').removeClass('active');
                    });

                }

            });

            base.positionSplitters(row);
        },

        /**
         * Saves new column widths.
         */
        splitterChangedDone : function (splitterdiv)
        {
            var base = this;

            var splitternum = splitterdiv.data('splitternum');
            var row = splitterdiv.data('parentrow');
            var leftcol = $(row).find('div.gridrow div[class^=column-]:nth(' + splitternum + ')');
            var rightcol = $(row).find('div.gridrow div[class^=column-]:nth(' + (splitternum + 1) + ')');

            // If actually changed then saves.

            if (!leftcol.hasClass('column-' + base.activesplitter.startColLeftSize12 + '-12') ||
                !rightcol.hasClass('column-' + base.activesplitter.startColRightSize12 + '-12')) {
                
                var id1 = leftcol.data('cellid');
                var size1 = base.getDivWidthIn12(leftcol);
                var id2 = rightcol.data('cellid');
                var size2 = base.getDivWidthIn12(rightcol);

                $.ajax({
                    url: '/m/grid-splitter-do/',
                    type: 'post',
                    data: {
                        cell1: id1,
                        cell1size: size1,
                        cell2: id2,
                        cell2size: size2
                    }
                });
            }
            base.positionSplitters();
        },

        /**
         * Positions splitters.
         *
         * All splitters are absolute divs and they need to be moved to the correct positions.
         * This has to be done periodically because changing the layout may change the positions of the columns.
         */
        positionSplitters : function(row)
        {
            var base = this;

            var rows;
            if (typeof row == 'undefined') {
                rows = $('.section-customizable .container');
            } else {
                rows = [row];
            }

            if (!base.activesplitter.moving) {

                for (var i = 0; i < rows.length; i++) {

                    row = rows[i];

                    var splitters = [];
                    $('.mz_layout_splitter').each(function(i, el) {
                        if ($(this).data('parentrow') == row) {
                            var splitternum = $(this).data('splitternum');
                            splitters[splitternum] = this;
                        }
                    });

                    for (var splitternum = 0; splitternum < splitters.length; splitternum++) {

                        var leftcol = $(row).find('div.gridrow div[class^=column-]:nth(' + splitternum + ')');
                        var rightcol = $(row).find('div.gridrow div[class^=column-]:nth(' + (splitternum + 1) + ')');

                        $(splitters[splitternum]).css({
                            
                            // Top matches column to
                            top: leftcol.offset().top + parseInt(leftcol.css('margin-top')) + parseInt(leftcol.css('padding-top')),

                            // Left matches column right side and extra 10px
                            left: leftcol.offset().left + leftcol.width() + (parseInt(leftcol.css('margin-left')) + parseInt(leftcol.css('padding-left'))) * 1.5,

                            // Height matches tallest column (either left or right)
                            height: Math.max(leftcol.height(), rightcol.height()),

                            // Width matches gap between columns, minus 20px
                            width: rightcol.offset().left - (leftcol.offset().left + leftcol.width()) - 20
                        });
                    }
                }
            }
            
            window.setTimeout(function() { base.positionSplitters(); }, 100);
        },

        /**
         * Removes the splitter for the specified row.
         */
        removeRowSplitters: function(row)
        {
            $('.mz_layout_splitter').each(function(i, el) {
                if ($(this).data('parentrow') == row) {
                    $(this).remove();
                }
            });
        },
    };

    /* Main Entry Point */

    $.fn.mozgrid = function (options) {
        return this.each(function () {
            new MozGrid(this, options).init();
        })
    };

})(window, jQuery);

jQuery.mozgridinit = function() {
    $('.mz_grid').mozgrid({ });
};