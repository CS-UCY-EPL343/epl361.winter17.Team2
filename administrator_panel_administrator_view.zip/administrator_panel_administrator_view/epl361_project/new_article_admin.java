package epl361_project;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.Font;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.io.File;
import java.awt.event.ActionEvent;
import javax.swing.JComboBox;
import javax.swing.SwingConstants;
import javax.swing.JEditorPane;
import javax.swing.JFileChooser;

import java.awt.Color;
import javax.swing.UIManager;

public class new_article_admin extends JFrame {

	private JPanel contentPane;
	private JEditorPane textField;
	private JButton btnUploadVideo;
	private JButton btnEditTextFont;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					new_article_admin frame = new new_article_admin();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public new_article_admin() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100,577, 411);
		contentPane = new JPanel();
		contentPane.setBackground(UIManager.getColor("Button.highlight"));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
	
		
		JButton btnUploadPhoto = new JButton("+ Upload Photo");
		btnUploadPhoto.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				JFileChooser chooser= new JFileChooser();
				chooser.showOpenDialog(null);
				File f= chooser.getSelectedFile();
			}
		});
		btnUploadPhoto.setBounds(377, 23, 164, 23);
		contentPane.add(btnUploadPhoto);
		
		btnUploadVideo = new JButton("+ Upload Video");
		btnUploadVideo.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JFileChooser chooser= new JFileChooser();
				chooser.showOpenDialog(null);
				File f= chooser.getSelectedFile();
			}
		});
		btnUploadVideo.setBounds(379, 68, 162, 23);
		contentPane.add(btnUploadVideo);
		
		JButton btnSaveAndPublish = new JButton("Save and Publish");
		btnSaveAndPublish.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
				new Save_admin().setVisible(true);
				
				
			}
		});
		btnSaveAndPublish.setBounds(98, 322, 164, 23);
		contentPane.add(btnSaveAndPublish);
		
		btnEditTextFont = new JButton("Edit Text Font");
		btnEditTextFont.setBackground(new Color(240, 240, 240));
		btnEditTextFont.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				FontChoser fontChooser = new FontChoser();
				fontChooser.getSampleTextField().setBounds(16, 21, 408, 108);
				fontChooser.getSamplePanel().setLayout(null);
				fontChooser.setVisible(true);
				int result = fontChooser.showDialog(getParent());
				if (result == FontChoser.OK_OPTION)
				{
				  Font font = fontChooser.getSelectedFont(); 
				 textField.setFont(font);;
				} 
			}
		});
		btnEditTextFont.setBounds(98, 288, 164, 23);
		contentPane.add(btnEditTextFont);
		
		JPanel panel = new JPanel();
		panel.setBackground(Color.BLACK);
		panel.setBounds(23, 11, 337, 262);
		contentPane.add(panel);
		panel.setLayout(null);
		
		textField = new JEditorPane();
		textField.setBounds(10, 11, 318, 238);
		panel.add(textField);
		textField.setForeground(new Color(0, 0, 0));
		textField.setToolTipText("");
	}
}
