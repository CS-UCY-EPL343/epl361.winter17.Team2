package epl361_project;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.FlowLayout;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.SwingConstants;
import java.awt.Color;
import java.awt.Font;
import java.awt.SystemColor;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Statistics extends JFrame {

	private JPanel contentPane;
	private JTextField txtTodaysVisitors;
	private JTextField txtTodaysReports;
	private JTextField txtTodaysAdoptionsRequests;
	private JTextField txtPageViews;
	private JTextField textField;
	private JTextField txtYearly;
	private JTextField txtVisitors;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Statistics frame = new Statistics();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Statistics() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 900, 492);
		contentPane = new JPanel();
		contentPane.setBackground(Color.WHITE);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(153, 0, 0));
		panel.setBounds(0, 0, 884, 76);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel label = new JLabel("50");
		label.setFont(new Font("Tahoma", Font.BOLD, 18));
		label.setForeground(new Color(255, 255, 255));
		label.setHorizontalAlignment(SwingConstants.CENTER);
		label.setBounds(170, 0, 79, 76);
		panel.add(label);
		
		JLabel label_1 = new JLabel("7");
		label_1.setForeground(SystemColor.textHighlightText);
		label_1.setFont(new Font("Tahoma", Font.BOLD, 18));
		label_1.setHorizontalAlignment(SwingConstants.CENTER);
		label_1.setBounds(461, 8, 61, 60);
		panel.add(label_1);
		
		JLabel label_2 = new JLabel("3");
		label_2.setForeground(SystemColor.window);
		label_2.setFont(new Font("Tahoma", Font.BOLD, 18));
		label_2.setHorizontalAlignment(SwingConstants.CENTER);
		label_2.setBounds(800, 8, 74, 60);
		panel.add(label_2);
		
		txtTodaysVisitors = new JTextField();
		txtTodaysVisitors.setFont(new Font("Calibri", Font.BOLD, 15));
		txtTodaysVisitors.setHorizontalAlignment(SwingConstants.CENTER);
		txtTodaysVisitors.setText("Today\r\nVisitors");
		txtTodaysVisitors.setBounds(0, 0, 160, 76);
		panel.add(txtTodaysVisitors);
		txtTodaysVisitors.setBackground(SystemColor.controlHighlight);
		txtTodaysVisitors.setEditable(false);
		txtTodaysVisitors.setColumns(10);
		
		txtTodaysReports = new JTextField();
		txtTodaysReports.setEditable(false);
		txtTodaysReports.setFont(new Font("Calibri", Font.BOLD, 15));
		txtTodaysReports.setBackground(SystemColor.controlHighlight);
		txtTodaysReports.setHorizontalAlignment(SwingConstants.CENTER);
		txtTodaysReports.setText("Today Reports");
		txtTodaysReports.setBounds(272, 0, 160, 87);
		panel.add(txtTodaysReports);
		txtTodaysReports.setColumns(10);
		
		txtTodaysAdoptionsRequests = new JTextField();
		txtTodaysAdoptionsRequests.setEditable(false);
		txtTodaysAdoptionsRequests.setFont(new Font("Calibri", Font.BOLD, 15));
		txtTodaysAdoptionsRequests.setBackground(SystemColor.controlHighlight);
		txtTodaysAdoptionsRequests.setHorizontalAlignment(SwingConstants.CENTER);
		txtTodaysAdoptionsRequests.setText("Today Adoptions Requests");
		txtTodaysAdoptionsRequests.setBounds(545, -2, 238, 87);
		panel.add(txtTodaysAdoptionsRequests);
		txtTodaysAdoptionsRequests.setColumns(10);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBackground(SystemColor.desktop);
		panel_1.setBounds(0, 70, 884, 23);
		contentPane.add(panel_1);
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setIcon(new ImageIcon(Statistics.class.getResource("/epl361_project/23756075_1772883072753361_100923169_n.jpg")));
		lblNewLabel.setBounds(144, 104, 587, 380);
		contentPane.add(lblNewLabel);
		
		txtPageViews = new JTextField();
		txtPageViews.setEditable(false);
		txtPageViews.setFont(new Font("Calibri", Font.BOLD, 15));
		txtPageViews.setText("Page Views ");
		txtPageViews.setHorizontalAlignment(SwingConstants.CENTER);
		txtPageViews.setBounds(768, 159, 106, 76);
		contentPane.add(txtPageViews);
		txtPageViews.setColumns(10);
		
		textField = new JTextField();
		textField.setEditable(false);
		textField.setFont(new Font("Tahoma", Font.BOLD, 15));
		textField.setForeground(new Color(255, 255, 255));
		textField.setBackground(new Color(204, 0, 0));
		textField.setText("506");
		textField.setHorizontalAlignment(SwingConstants.CENTER);
		textField.setBounds(768, 230, 106, 76);
		contentPane.add(textField);
		textField.setColumns(10);
		
		JPanel panel_2 = new JPanel();
		panel_2.setBackground(new Color(0, 0, 0));
		panel_2.setBounds(741, 87, 27, 376);
		contentPane.add(panel_2);
		
		JPanel panel_3 = new JPanel();
		panel_3.setBackground(new Color(0, 0, 0));
		panel_3.setBounds(874, 87, 10, 376);
		contentPane.add(panel_3);
		
		JPanel panel_4 = new JPanel();
		panel_4.setBackground(new Color(0, 0, 0));
		panel_4.setBounds(112, 87, 22, 376);
		contentPane.add(panel_4);
		
		txtYearly = new JTextField();
		txtYearly.setBackground(new Color(255, 255, 255));
		txtYearly.setHorizontalAlignment(SwingConstants.CENTER);
		txtYearly.setEditable(false);
		txtYearly.setFont(new Font("Calibri", Font.BOLD, 15));
		txtYearly.setText("Monthly\r\n ");
		txtYearly.setBounds(-11, 340, 113, 59);
		contentPane.add(txtYearly);
		txtYearly.setColumns(10);
		
		txtVisitors = new JTextField();
		txtVisitors.setBackground(new Color(255, 255, 255));
		txtVisitors.setEditable(false);
		txtVisitors.setHorizontalAlignment(SwingConstants.CENTER);
		txtVisitors.setFont(new Font("Calibri", Font.BOLD, 15));
		txtVisitors.setText("Visitors");
		txtVisitors.setBounds(-1, 397, 103, 45);
		contentPane.add(txtVisitors);
		txtVisitors.setColumns(10);
		
		JButton btnGoBack = new JButton("Go Back");
		btnGoBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
				new admin_webuser_administrator().main(null);
				
			}
		});
		btnGoBack.setBounds(778, 408, 89, 23);
		contentPane.add(btnGoBack);
	}
}
