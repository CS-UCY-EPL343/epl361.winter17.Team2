package epl361_project;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.BorderLayout;
import javax.swing.ImageIcon;
import java.awt.Font;
import javax.swing.SwingConstants;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.JButton;
import javax.swing.JComboBox;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.Color;
import javax.swing.JToolBar;
import javax.swing.JPanel;

public class admin_webuser_administrator {

	public JFrame frame;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					admin_webuser_administrator window = new admin_webuser_administrator();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public admin_webuser_administrator() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.getContentPane().setBackground(Color.WHITE);
		frame.setBounds(100, 100, 769, 506);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setIcon(new ImageIcon(admin_webuser_administrator.class.getResource("/epl361_project/23721782_1771329182908750_1673673037_n.jpg")));
		lblNewLabel.setBounds(0, 0, 113, 101);
		frame.getContentPane().add(lblNewLabel);
		
		JLabel lblAdminPanel = new JLabel("H&H Administrator Panel");
		lblAdminPanel.setForeground(new Color(178, 34, 34));
		lblAdminPanel.setHorizontalAlignment(SwingConstants.CENTER);
		lblAdminPanel.setFont(new Font("Times New Roman", Font.BOLD, 30));
		lblAdminPanel.setBounds(177, 44, 427, 57);
		frame.getContentPane().add(lblAdminPanel);
		
		    
		
		String tabs[] ={"Home","Successful Stories", "Events","Animal's Gallery","Advices&Tips"};		
		JComboBox comboBox = new JComboBox(tabs);
		comboBox.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent event) {
                //
                // Get the source of the component, which is our combo
                // box.
                //
                JComboBox comboBox = (JComboBox) event.getSource();

                Object selected = comboBox.getSelectedItem();
                if(selected.toString().equals("Home")) {
                	frame.setVisible(false);
                new Tabs_admin().setVisible(true);}
                else if(selected.toString().equals("Events")) {
                	frame.setVisible(false);
                new EventTab_admin().setVisible(true);}
                else if(selected.toString().equals("Adoptions")) {
                	frame.setVisible(false);
                new Tabs_admin().setVisible(true);}
                else if(selected.toString().equals("Animal's Gallery")) {
                	frame.setVisible(false);
                new GalleryOption_admin().setVisible(true);} 
                else if(selected.toString().equals("Advices&Tips")) {
                	frame.setVisible(false);
                new Tabs_admin().setVisible(true);}
                else if(selected.toString().equals("Successful Stories")) {
                	frame.setVisible(false);
                new Tabs_admin().setVisible(true);}
               
                

            }
        });
		
		comboBox.setBounds(280, 156, 175, 48);
		frame.getContentPane().add(comboBox);
		
		JButton btnView = new JButton("View Website");
		btnView.setBounds(42, 156, 184, 48);
		frame.getContentPane().add(btnView);
		JButton btnEdit = new JButton("Edit Website");
		btnEdit.addActionListener(new ActionListener() {	
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				btnEdit.setVisible(false);
				
				comboBox.setVisible(!comboBox.isVisible());}
						
		});
		comboBox.setVisible(Boolean.FALSE);
		//frame.getContentPane().add(comboBox);
		frame.getContentPane().add(comboBox);
		
		btnEdit.setBounds(271, 156, 184, 48);
		frame.getContentPane().add(btnEdit);
		
		
		
		JLabel label = new JLabel("");
		label.setIcon(new ImageIcon(admin_webuser_administrator.class.getResource("/epl361_project/1511588_604719249605970_1089402828_n1.jpg")));
		label.setBounds(10, 197, 718, 317);
		frame.getContentPane().add(label);
		
		JToolBar toolBar = new JToolBar();
		toolBar.setBounds(494, 342, 87, 16);
		frame.getContentPane().add(toolBar);
		
		JButton btnStatistics = new JButton("Statistics");
		btnStatistics.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frame.setVisible(false);
				new  Statistics().setVisible(true);
			}
		});
		btnStatistics.setBounds(514, 156, 184, 48);
		frame.getContentPane().add(btnStatistics);
		
		JPanel panel = new JPanel();
		panel.setBackground(Color.BLACK);
		panel.setBounds(0, 105, 753, 10);
		frame.getContentPane().add(panel);

		btnView.addActionListener(new ActionListener() {	
			@Override
			public void actionPerformed(ActionEvent e) {
				try { 
			         String url = "http://eriakouppari97.mozello.com/";
			         java.awt.Desktop.getDesktop().browse(java.net.URI.create(url));
			       }
			       catch (java.io.IOException ex) {
			           System.out.println(ex.getMessage());
			       }}
						
		});
		
		
	
	}
}
