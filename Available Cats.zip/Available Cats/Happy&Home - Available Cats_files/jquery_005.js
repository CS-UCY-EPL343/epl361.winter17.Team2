(function (window, $) {

    /* Plugin Constructor */

    var MozGallery = function (element, options) {
        this.element = $(element);
        this.options = options;
    };

    /* Plugin Prototype */

    MozGallery.prototype = {

        /**
         * Contains the default configuration.
         */
        defaults: {
            status: null
        },

        /**
         * Initializes the Plugin.
         */
        init: function()
        {
            var base = this;

            base.config = $.extend({}, base.defaults, base.options);
            base.componentID = this.element.data('cid');
            base.groupID = this.element.data('gid');

            // Enables uploads.

            base.element.find('a.moze-the-button.add').click(function () {
                base.element.find('input[name="gallery-upload"]').trigger('click');
                return false;
            });

            base.element.find('input[name="gallery-upload"]').on('change', function(e) {
                base.actionPictureUpload(e, base);
            });

            // Enables actions.

            base.element.find('a.moze-gallery-group-add').on('click', function(e) {
                if (noClicks() || isSwipeTakingPlace) {
                    e.stopPropagation();
                    return false;
                }
                base.actionGroupAdd(base);
            })

            base.element.find('a.moze-gallery-group-title').on('click', function(e) {
                if (noClicks() || isSwipeTakingPlace) {
                    e.stopPropagation();
                    return false;
                }
                base.actionGroupTitle(e.target, base);
            });

            base.element.find('a.moze-gallery-group-delete').on('click', function(e) {
                if (noClicks() || isSwipeTakingPlace) {
                    e.stopPropagation();
                    return false;
                }
                base.actionGroupDelete(e.target, base);
            });

            base.element.find('a.moze-gallery-group-delete-warn').on('click', function(e) {
                if (noClicks() || isSwipeTakingPlace) {
                    e.stopPropagation();
                    return false;
                }
                alert(MGA_GROUP_DELETE_WARNING);
            });

            base.element.find('a.moze-gallery-title').on('click', function(e) {
                if (noClicks() || isSwipeTakingPlace) {
                    e.stopPropagation();
                    return false;
                }
                base.actionPictureTitle(e.target, base);
            });

            base.element.find('a.moze-gallery-delete').on('click', function(e) {
                if (noClicks() || isSwipeTakingPlace) {
                    e.stopPropagation();
                    return false;
                }
                base.actionPictureDelete(e.target, base);
            });

            // Positions the progress bar form.

            $("#upload-status").detach().appendTo("body");

            // Makes pictures and galleries sortable.

            base.element.children('ul').sortable({
                stop: function(event, ui) {

                    var ul = base.element.find('ul').first();
                    var ids = [];
                    var mode = '';

                    if (ul.hasClass('groups') && !ul.hasClass('pictures')) {
                        $.each(base.element.find('li'), function() {
                            ids.push($(this).data('gid'));
                        });
                        mode = 'groups';
                    }

                    if (ul.hasClass('pictures') && !ul.hasClass('groups')) {
                        $.each(base.element.find('li'), function() {
                            ids.push($(this).data('pid'));
                        });
                        mode = 'pictures';
                    }

                    $.ajax({
                        url: '/m/gallery-do-sort/',
                        type: 'post',
                        data: {
                            component: base.componentID,
                            group: base.groupID,
                            mode: mode,
                            ids: ids
                        }
                    });

                }
            });
        },

        /**
         * Adds a new group for pictures.
         */
        actionGroupAdd: function(base)
        {
            var title = prompt('Enter title');

            if (title != null) {
                $.ajax({
                    url: '/m/gallery-group-do-add/',
                    type: 'post',
                    data: {
                        component: base.componentID,
                        title: title
                    },
                    success: function() {
                        window.location.reload();
                    },
                    error: function() {
                        window.location.reload();
                    }
                });
            }
        },

        /**
         * Changes the title of the selected group of pictures.
         */
        actionGroupTitle: function(sender, base)
        {
            var groupID = $(sender).parents('li').data('gid');
            var titleTag = $(sender).parents('li').find('div.title span');

            var title = prompt(MGA_ENTER_TITLE, titleTag.html());

            if (title != null) {
                title = title.substring(0, 90);
                $.ajax({
                    url: '/m/gallery-group-do-title/',
                    type: 'post',
                    data: {
                        component: base.componentID,
                        group: groupID,
                        title: title
                    }
                });
                titleTag.html(title);
            }
        },

        /**
         * Deletes the selected group of pictures.
         */
        actionGroupDelete: function(sender, base)
        {
            var groupID = $(sender).parents('li').data('gid');

            if (confirm(MGA_GROUP_DELETE_CONFIRM)) {
                $.ajax({
                    url: '/m/gallery-group-do-delete/',
                    type: 'post',
                    data: {
                        component: base.componentID,
                        group: groupID
                    },
                    success: function(response) {
                        if (response == 'Ok') {
                            $(sender).parents('li').remove();
                        }
                        if (response == 'Refresh') {
                            window.location.reload();
                        }
                    }
                });
            }
        },

        /**
         * Uploads pictures to the gallery.
         */
        actionPictureUpload: function(e, base)
        {
            var files = e.target.files;
            var totalFiles = e.target.files.length;

            var uploadFx = function (fileNo) {

                if (fileNo > totalFiles - 1) {
                    return;
                }

                var file = files[fileNo];

                if (file.type == 'image/jpeg' || file.type == 'image/png') {

                    var reader = new FileReader();
                    reader.readAsDataURL(file);

                    reader.onloadstart = function () {
                        $('#upload-progress').removeClass('failed');
                        $('#upload-status').css("display", "block");
                        $('#upload-status-message').html(MGA_STATUS_UPLOADING);
                    };

                    reader.onload = function () {

                        var formdata = new FormData();
                        formdata.append('Filedata', file);
                        formdata.append('component', base.componentID);
                        formdata.append('group', (typeof base.groupID !== 'undefined') ? base.groupID : 0);

                        $.ajax({
                            url: '/m/gallery-do-upload/',
                            type: 'post',
                            data: formdata,
                            processData: false,
                            contentType: false,
                            xhr: function () {

                                var req = $.ajaxSettings.xhr();

                                if (req) {

                                    req.upload.addEventListener('progress', function (e) {

                                        if (e.lengthComputable) {

                                            var progress = Math.round(e.loaded / e.total * 100);
                                            var message = '';

                                            if (totalFiles == 1) {
                                                message = MGA_STATUS_FILE_UPLOAD_PROGRESS;
                                            }
                                            else {
                                                message = MGA_STATUS_FILES_UPLOAD_PROGRESS;
                                                message = message.replace('{0}', (fileNo + 1).toString());
                                                message = message.replace('{1}', totalFiles.toString());
                                            }

                                            var progressWidth = ((100 / totalFiles) * fileNo + (100 / totalFiles) / 100 * progress).toString() + '%';

                                            $('#upload-status').css("display", "block");
                                            $('#upload-progress').css("width", progressWidth);
                                            $('#upload-status-message').html(message);
                                        }
                                    }, false);
                                }
                                return req;
                            },
                            error: function (xhr, status, error) {
                                fileuploadOnError(error);
                            },
                            success: function (e) {

                                if (e.error == true) {
                                    $('#upload-progress').addClass('failed');
                                    $('#upload-status').css('display', 'block');
                                    if (e.reason == 'size') {
                                        $('#upload-status-message').html(MGA_STATUS_UPLOAD_FAILED_TOO_BIG);
                                    }
                                    else {
                                        $('#upload-status-message').html(MGA_STATUS_UPLOAD_FAILED);
                                    }
                                    return;
                                }

                                if (fileNo < totalFiles - 1) {
                                    uploadFx(fileNo + 1)
                                }
                                else {
                                    window.location.reload();
                                }
                            }
                        });
                    };

                    reader.onerror = function () {
                        $('#upload-progress').addClass('failed');
                        $('#upload-status').css('display', 'block');
                        $('#upload-status-message').html(MGA_STATUS_QUEUE_ERROR);
                    };

                }
                else {
                    alert(MGA_ERROR_UNSUPPOTED_FILE);
                }
            };

            if (totalFiles > 0) {
                uploadFx(0);
            }
        },

        /**
         * Changes the title of the selected picture.
         */
        actionPictureTitle: function(sender, base)
        {
            var pictureID = $(sender).parents('li').data('pid');
            var titleTag = $(sender).parents('li').find('div.title span');

            var title = prompt(MGA_ENTER_TITLE, titleTag.html());

            if (title != null) {
                title = title.substring(0, 90);
                $.ajax({
                    url: '/m/gallery-do-title/',
                    type: 'post',
                    data: {
                        component: base.componentID,
                        picture: pictureID,
                        title: title
                    }
                });
                titleTag.html(title);
            }
        },

        /**
         * Deletes the selected picture.
         */
        actionPictureDelete: function(sender, base)
        {
            var pictureID = $(sender).parents('li').data('pid');

            if (confirm(MGA_FILE_DELETE_CONFIRM) == true) {
                $.ajax({
                    url: '/m/gallery-do-delete/',
                    type: 'post',
                    data: {
                        component: base.componentID,
                        picture: pictureID
                    }
                });
                $(sender).parents('li').first().remove();
            }
        },
    };

    /* Main Entry Point */

    $.fn.mozgallery = function (options) {
        return this.each(function () {
            new MozGallery(this, options).init();
        })
    };

    /* End */

})(window, jQuery);

jQuery.mozgalleryinit = function() {
    $('.mz_gallery').mozgallery({
        phpSessId: $('body').data('phpsessid'),
        status: $('#upload-status')
    });
};