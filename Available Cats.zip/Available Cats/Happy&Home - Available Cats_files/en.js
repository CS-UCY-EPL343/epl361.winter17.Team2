/* Language Data */

var MOZELLO_LANGUAGE = 'en';

// Backend FX

var BFX_UPGRADE = 'Upgrade <br> to Premium';
var BFX_UPGRADE_SWEDBANK = 'Sign <br> a contract';

// MozWysiwyg Component

var MWY_HEADING_TOOLTIP = 'Mark text as heading';
var MWY_HEADING_CAPTION = 'Text Type';
var MWY_FONT_TOOLTIP = 'Text Style';
var MWY_FONT_CAPTION = 'Text Style';
var MWY_FONT_SUBITEM_UNFORMAT = 'Normal';
var MWY_FONT_SUBITEM_PARAGRAPH = 'Normal Paragraph';
var MWY_FONT_SUBITEM_TOPHEADER = 'Heading 1';
var MWY_FONT_SUBITEM_HEADER = 'Heading 2';
var MWY_FONT_SUBITEM_SUBTITLE = 'Heading 3';
var MWY_FONT_SUBITEM_MEGATITLE = 'Top Headline';
var MWY_FONT_SUBITEM_IMPORTANT = 'Important';
var MWY_FONT_SUBITEM_SECONDARY = 'Secondary';
var MWY_FONT_SUBITEM_BLOCKQUOTE = 'Quote';
var MWY_FONT_SUBITEM_CODE = 'Code';
var MWY_FONT_SUBITEM_STRIKE = 'Strikethrough';
var MWY_FONT_SUBITEM_BUTTON = 'Button';
var MWY_FONT_SUBITEM_BUTTON_LARGE = 'Large Button';

var MWY_FONT_SIZE_TOOLTIP = 'Font Size';
var MWY_FONT_SIZE_CAPTION = 'Size';
var MWY_FONT_SIZE_SUBITEM_TINY = 'Tiny';
var MWY_FONT_SIZE_SUBITEM_SMALL = 'Small';
var MWY_FONT_SIZE_SUBITEM_NORMAL = 'Normal';
var MWY_FONT_SIZE_SUBITEM_LARGE = 'Large';
var MWY_FONT_SIZE_SUBITEM_HUGE = 'Huge';
var MWY_FONT_SIZE_SUBITEM_GIGANTIC = 'Gigantic';

var MWY_FONT_COLOR_TOOLTIP = 'Font Color';

var MWY_JUSTIFY_LEFT_TOOLTIP = 'Justify Left';
var MWY_JUSTIFY_CENTER_TOOLTIP = 'Justify Center';
var MWY_JUSTIFY_RIGHT_TOOLTIP = 'Justify Right';
var MWY_JUSTIFY_FULL_TOOLTIP = 'Justify Full';

var MWY_UNDO_TOOLTIP = 'Undo';
var MWY_REDO_TOOLTIP = 'Redo';

var MWY_SPLIT_TOOLTIP = 'Split';
var MWY_MERGE_TOOLTIP = 'Merge';

var MWY_BOLD_TOOLTIP = 'Bold';
var MWY_ITALIC_TOOLTIP = 'Italic';
var MWY_UNDERLINE_TOOLTIP = 'Underline';
var MWY_BULLETS_TOOLTIP = 'Bullets';
var MWY_NUMBERING_TOOLTIP = 'Numbering';
var MWY_LINK_TOOLTIP = 'Hyperlink';
var MWY_LINK_REMOVE_TOOLTIP = 'Remove link';
var MWY_LINK_SPACING_TOOLTIP = 'Add spacing';
var MWY_IMAGE_TOOLTIP = 'Image';

var MWY_FILE_TOOLTIP = 'Insert File';
var MWY_VIDEO_TOOLTIP = 'Insert Video';
var MWY_MAPS_TOOLTIP = 'Insert Map';
var MWY_MAPS_EDIT_TOOLTIP = 'Edit Map';
var MWY_SYMBOL_TOOLTIP = 'Insert Symbol';
var MWY_CODE_TOOLTIP = 'Insert Code';
var MWY_BUTTON_TOOLTIP = 'Insert Button';

var MWY_TABLE_TOOLTIP = 'Table';
var MWY_TABLE_SUBITEM_CREATE = 'Create table';
var MWY_TABLE_SUBITEM_COLUMN_BEFORE = 'Add column before';
var MWY_TABLE_SUBITEM_COLUMN_AFTER = 'Add column after';
var MWY_TABLE_SUBITEM_DELETE_COLUMN = 'Delete column';
var MWY_TABLE_SUBITEM_ROW_BEFORE = 'Add row before';
var MWY_TABLE_SUBITEM_ROW_AFTER = 'Add row after';
var MWY_TABLE_SUBITEM_DELETE_ROW = 'Delete row';
var MWY_TABLE_SUBITEM_HEADER = 'Change row style';

var MWY_HTML_TOOLTIP = 'HTML';
var MWY_CLEARFORMATTING_TOOLTIP = 'Clear formatting';

var MWY_IMG_JUSTIFY_LEFT_TOOLTIP = 'Align Left';
var MWY_IMG_JUSTIFY_CENTER_TOOLTIP = 'Center';
var MWY_IMG_JUSTIFY_RIGHT_TOOLTIP = 'Align Right';
var MWY_IMG_JUSTIFY_FULL_TOOLTIP = 'Align Inline';
var MWY_IMG_RESIZE = 'Resize Image';
var MWY_IMG_PROPERTIES = 'Image Properties';
var MWY_IMG_DELETE = 'Delete Image';

var MWY_IFRAME_RESIZE = 'Resize';
var MWY_IFRAME_DELETE = 'Delete';

var MWY_MAPS_NOT_FOUND = 'Location not found. Please try other or more precise address.';
var MWY_FILE_LINK_TEXT = 'Link text';
var MWY_BUTTON_TEXT = 'Click Here';
var MWY_FILE_EXPLORER_SPACE_STATS = '{used}% of {total} mb';

// MozGallery Component

var MGA_FILE_DELETE_CONFIRM = 'Are you sure you want to delete this file?';
var MGA_GROUP_DELETE_CONFIRM = 'Are you sure you want to delete this picture group?';
var MGA_GROUP_DELETE_WARNING = 'The picture group is not empty. Delete group pictures first.';
var MGA_FILE_TYPE_ALL = 'All files';
var MGA_FILE_TYPE_IMAGES = 'Web Image Files';
var MGA_ENTER_TITLE = 'Enter title:';

var MGA_STATUS_QUEUE_ERROR = 'Queue error...';
var MGA_STATUS_UPLOADING = 'Uploading...';
var MGA_STATUS_FILE_UPLOAD_PROGRESS = 'Uploading file, please wait...';
var MGA_STATUS_FILES_UPLOAD_PROGRESS = 'Uploading file {0} of {1}, please wait...';
var MGA_STATUS_UPLOAD_FAILED = 'Upload failed...';
var MGA_STATUS_UPLOAD_FAILED_TOO_BIG = 'Upload failed, file is too big or your storage space is full.';
var MGA_STATUS_UPLOAD_PREMIUM = 'To upload bigger files and get more storage space, please subscribe for {0}.';
var MGA_ERROR_UNSUPPOTED_FILE = 'Unsupported file type.';
var MGA_ERROR_UNSUPPOTED_FEATURE = 'Your web browser is too old and does not support this feature.\nPlease use Firefox, Chrome, Safari 6+, Opera 12+ or Internet Explorer 10+.';
var MGA_ERROR_PAID_FILE_TYPE = 'Executable files can only be uploaded from paid accounts.';

// SessionFX

var SFX_ERROR_EMAIL_NOT_VALID = 'E-mail address is not valid.';
var SFX_ERROR_WRONG_PASSWORD = 'Wrong password.';
var SFX_ERROR_ACCOUNT_EXISTS = 'An account with this e-mail already exists, but the password is different.';
var SFX_ERROR_ACCOUNT_DISABLED = 'Account is disabled';

// PopupFX

var PFX_ERROR_FREE_ADDRESS_NOT_VALID = 'Free address is not valid.';
var PFX_ERROR_FREE_ADDRESS_TAKEN = 'Free address is already taken.';
var PFX_ERROR_DOMAIN_NOT_VALID = 'Domain name is not valid.';
var PFX_ERROR_PURCHASE_SEPARATELY = 'This domain name can not be registered through {0}. It must be purchased separatelly.';
var PFX_ERROR_UNAVAILABLE_FOR_WIRE = 'This feature is not available for subscriptions paid by wire transfer.';
var PFX_ERROR_EMAIL_NOT_VALID = 'E-mail address is not valid.';
var PFX_ERROR_EMAIL_TAKEN = 'E-mail address is already in use by somebody else.';
var PFX_ERROR_PASSWORD_TOO_SHORT = 'Password is too short.';
var PFX_ERROR_FILL_ALL_BUYER_INFO = 'Fill all information in order to get the invoice.';
var PFX_ERROR_INVALID_VAT = 'Invalid VAT number.';
var PFX_ERROR_UNABLE_CHECK_VAT = 'Unable to check VAT number.';
var PFX_ERROR_GA_NOT_VALID = 'Invalid Google Analytics tracking ID. Please enter the tracking ID from your Google Analytics account.';

var PFX_MESSAGE_WAS_SENT = 'Message was sent.';

var PFX_MESSAGE_SOON = 'This feature is not yet available, but it will be available soon.';
var PFX_MESSAGE_PAID_ONLY = 'To use this feature, please upgrade to Premium account.';

var PFX_MESSAGE_TERMS = 'You must accept the terms of service.';

// Blog

var BLG_PUBLISH = 'Publish';
var BLG_HIDE = 'Hide';
var BLG_ERROR_CONNECTION = 'Ooops! The connection was lost.\nTo continue, you may have to log in again.\n\nDo this now?';

// Customizer

var CUS_BTN_CHOOSE = 'Choose';
var CUS_BTN_CANCEL = 'Cancel';

// Catalog

var CAT_PRODUCT_LIMIT_REACHED = 'Product limit reached. To add more products, please switch to a higher service plan.';

// Layout editor

var LAY_END_EDITING = 'End Layout Editing';
var LAY_ADD_CONTENT_BLOCK = 'Add content block';
var LAY_CHANGE_CONTENT_BLOCK = 'Change content block';
var LAY_CONFIRM_ROW_DELETE = 'Are you sure you want to delete this row?\n\nThe data contained in this row will be permanently lost.';
var LAY_CONFIRM_CHANGE_LAYOUT = 'Are you sure you want to the change layout?\n\nData loss may occur.';

// Variants

var VARIANTS_ERROR_LIMITED_OPTIONS = 'You can have no more than 2 options.';
var VARIANTS_ERROR_OPTIONS_EMPTY = 'Variant options cannot be left empty.';
var VARIANTS_ERROR_EMPTY = 'Variants cannot be empty.';
var VARIANTS_ERROR_PARTIALLY_FILLED = 'Variants cannot be partially filled.';

/* End */