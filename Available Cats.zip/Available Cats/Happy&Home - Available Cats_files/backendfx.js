// Detect if drag operation is happening

var touchStartTimeout;

$(document).ready(function () {

    /* Initialization */

    initializePopups();
    initializeComponents();
    initializeGUI();
    initializeOverlays();
    initializeCustomizer();

    setInterval(function () {
        checkIfBackendIsAlive()
    }, 60000);

    /* Functions */

    function closeAllSubmenus()
    {
        var submenus = $('div#mz_topbar li.has-submenu');
        submenus.find('ul').hide();
        submenus.find('a:first').removeClass('down');
    }

    /**
     * Initializes misc GUIs.
     */
    function initializeGUI()
    {
        /* overlays on mobile devices */

        $("body").on("touchstart", function () {
            window.clearTimeout(touchStartTimeout);
            $("body").addClass('justtouched');
            touchStartTimeout = setTimeout(function () {
                $("body").removeClass('justtouched');
            }, 2000);
        });

        /* tiiny screen menu */

        $("#mz_topbar_opener").on('click touchend', function (e) {
            if (noClicks() || isSwipeTakingPlace) {
                e.stopPropagation();
                return false;
            }
            $("#mz_topbar_opener").hide();
            $("#mz_topbar").show().addClass('floating');
            $("#mz_topbar_closer").show();
            return false;
        });

        $("#mz_topbar_closer").on('click touchend', function () {
            if (noClicks() || isSwipeTakingPlace) {
                e.stopPropagation();
                return false;
            }
            $(this).hide();
            $("#mz_topbar").hide().removeClass('floating');
            closeAllSubmenus();
            $("#mz_topbar_opener").show();
            return false;
        });

        /* handle submenus */

        $('div#mz_topbar li.has-submenu').find('a:first').on('touchend', function () {
            // close all submenus
            if (!$(this).hasClass('down')) {
                closeAllSubmenus();
            }
            var menu = $(this).siblings('ul').toggle();
            if (menu.length == 0)
                menu = $(this).siblings().find('ul').toggle();
            $(this).toggleClass('down');
        });

        // make submenu stick a bit
        var stop_menu = null;

        $('.has-mouse div#mz_topbar li.has-submenu').on('mouseenter', function () {
            stop_menu = this;
            var menu = $(this).find('ul').show();
            $(this).find('a').first().addClass('down');
        });

        $('.has-mouse div#mz_topbar li.has-submenu').on('mouseleave', function () {
            var zis = $(this);
            stop_menu = null;
            setTimeout(function () {
                if (stop_menu == zis.get(0))
                    return false;
                zis.find('a').first().removeClass('down');
                zis.find('ul').hide();
            }, 300);
        });

        /* focus effect */
        if (!$('body').hasClass('touch-mode')) {
            $('.moze-wysiwyg-editor').on('focus', function () {
                execCSS3Animation($(this), 'do-focus-animation');
            });
        }

        $('body.backend .moze-wysiwyg-editor').each(function () {
            execCSS3Animation($(this), 'do-startup-animation', false, 3000);
        });

    }

    /**
     * Initializes template customizer.
     */
    function initializeCustomizer()
    {

        var customFonts = {};
        var howManyFonts = Math.floor(($(window).height() - 300) / 75);

        // if no font-schemes, hide the choice
        if (typeof mozColorSchemes == "undefined" || $.isEmptyObject(mozFontSchemes)) {
            $('a.customize-fonts').hide();
            $('a.customize-fonts').parent('li').hide();
        }

        $("#mz_customizer_back, #mz_font_customizer_back, #mz_font_customizer_more").hide();

        $("#mz_customizer_more").on('click touchend', function () {
            if (noClicks() || isSwipeTakingPlace) {
                e.stopPropagation();
                return false;
            }
            var container = $(this).parent();
            container.find(".general").hide();
            container.find(".more").show();
        });

        $("#mz_customizer_back").on('click touchend', function () {
            if (noClicks() || isSwipeTakingPlace) {
                e.stopPropagation();
                return false;
            }
            var container = $(this).parent();
            container.find(".more").hide();
            container.find(".general").show();

            if (container.hasClass("mz_advanced_colors") && $('#mz_color_schemes .color-scheme').length > 0) {
                $("#mz_customizer_schemes").show();
            }

        });

        // next font schemes display
        $("#mz_font_customizer_more").on('click touchend', function () {
            if (noClicks() || isSwipeTakingPlace) {
                e.stopPropagation();
                return false;
            }
            var container = $(this).parent();
            var last_visible = container.find(".font-scheme:visible").last();
            var first_invisible = last_visible.next('.font-scheme');
            // hide all
            container.find(".font-scheme").hide();
            for (var i = 0; i <= howManyFonts; i++) {
                if (first_invisible.length > 0) {
                    first_invisible.show();
                    first_invisible = first_invisible.next('.font-scheme');
                    $("#mz_font_customizer_back").show();
                } else {
                    break;
                }
            }
            if (first_invisible.length > 0) {
                $("#mz_font_customizer_more").show();
            } else {
                $("#mz_font_customizer_more").hide();
            }

        });

        // previous font schemes display
        $("#mz_font_customizer_back").on('click touchend', function () {
            if (noClicks() || isSwipeTakingPlace) {
                e.stopPropagation();
                return false;
            }
            var container = $(this).parent();
            var first_visible = container.find(".font-scheme:visible").first();
            var last_invisible = first_visible.prev('.font-scheme');
            // hide all
            container.find(".font-scheme").hide();
            for (var i = 0; i <= howManyFonts; i++) {
                if (last_invisible.length > 0) {
                    last_invisible.show();
                    last_invisible = last_invisible.prev('.font-scheme');
                    $("#mz_font_customizer_more").show();
                } else {
                    break;
                }
            }
            if (last_invisible.length > 0) {
                $("#mz_font_customizer_back").show();
            } else {
                $("#mz_font_customizer_back").hide();
            }

        });

        // injects new style code
        function injectStyles(key, rule, classname) {
            var id = 'customizer_' + key;
            var node = document.getElementById(id);
            if (node == null) {
                node = document.createElement('style');
                node.id = 'customizer_' + key;
                node.className = classname;
                node.innerHTML = rule;
                document.body.appendChild(node);
                document.getElementsByTagName("head")[0].appendChild(node);
            } else {
                node.innerHTML = rule;
            }
        }

        // build css code to be injected
        function buildCssCode(key, cssselectors, cssvalue, classname) {
            var code = '';
            var selectors = cssselectors;

            if (typeof selectors == 'undefined') return false;

            for (var i = 0; i < selectors.length; i++) {

                // opening media part
                if (selectors[i].cssmedia != null) {
                    code = code + '@media ' + selectors[i].cssmedia + '{';
                }

                // selector
                code = code + selectors[i].css + '{';

                // css properties + values
                if (typeof cssvalue == 'string') {
                    code = code + selectors[i].cssprop + ':';
                    // value
                    if (selectors[i].cssval == null) {
                        code = code + cssvalue;
                    } else {
                        code = code + selectors[i].cssval;
                    }
                } else {
                    $.each(cssvalue, function (key, value) {
                        if (key == 'font-resize') {
                            if (selectors[i].defaultsize && (selectors[i].defaultsize != '')) {
                                code = code + 'font-size: calc(' + selectors[i].defaultsize + '*' + value + ');';
                            }
                        } else {
                            // selector + property
                            code = code + key + ':' + value + ';';
                        }

                    });
                }

                // close rule
                code = code + '} ';

                // closing media tag
                if (selectors[i].cssmedia != null) {
                    code = code + '}';
                }
            }
            // inject
            injectStyles(key, code, classname);
        }

        // creates custom color result array
        function buildCustomColorArray() {
            var all = $('input.colorSelect');
            var res = new Array();
            all.each(function () {
                var element = {id: $(this).data('name'), value: $(this).val()};
                res.push(element);
            });
            return res;
        }

        // creates custom color result array
        function buildCustomFontArray() {
            var res = new Array();
            // save fonts
            $.each(customFonts, function (key, value) {
                var element = {id: key, value: JSON.stringify(value)};
                res.push(element);
            });
            return res;
        }

        function updateColor(elem, color) {
            var defval = tinycolor($(elem).data('default'));
            // color
            if (color.alpha == 1) {
                var s = color.toHexString();
            } else {
                var s = color.toHslString();
            }
            // build css code
            buildCssCode($(elem).data('name'), mozDesignCustomizer[$(elem).data('name')].selectors, s, 'customizer');
        }

        function saveColorScheme() {
            $.ajax({
                url: '/m/design-do-customizer-save/',
                data: {customizer: buildCustomColorArray(), type: 0},
                type: 'post'
            });
        }

        function saveFontScheme() {
            $.ajax({
                url: '/m/design-do-customizer-save/',
                data: {customizer: buildCustomFontArray(), type: 1},
                type: 'post'
            });
        }

        function reloadSpectrum() {
            //var allcolors = getAllColors();
            $("#mz_customizer .colorSelect").each(function () {
                $(this).spectrum({
                    showInput: true,
                    showAlpha: $(this).hasClass('alpha'),
                    chooseText: CUS_BTN_CHOOSE,
                    cancelText: CUS_BTN_CANCEL,
                    showInitial: true,
                    change: function (color) {
                        updateColor(this, color);
                        saveColorScheme();
                    },
                    move: function (color) {
                        updateColor(this, color);
                    },
                    hide: function (color) {
                        updateColor(this, color);
                    },
                    ///showPalette: true,
                    ///palette: allcolors,
                    preferredFormat: ($(this).hasClass('alpha')) ? "hsl" : "hex"
                });
            });
        }

        $("#mz_customizer a.close").on('click touchend', function () {

            if (noClicks() || isSwipeTakingPlace) {
                e.stopPropagation();
                return false;
            }

            // animate body
            $('body').transition({marginLeft: '95px'}, 100);
            // slide out customizer
            $("#mz_customizer").transition({x: 0}, 200);

            return false;
        });

        $("#mz_customizer a.reset").on('click touchend', function (e) {
            if (noClicks() || isSwipeTakingPlace) {
                e.stopPropagation();
                return false;
            }

            if ($('#mz_font_schemes').is(':visible')) {
                // reset font scheme
                resetFontScheme();
                $.ajax({
                    url: '/m/design-do-customizer-reset/',
                    data: {type: 1},
                    type: 'post'
                });
            } else {
                // reset color scheme
                resetColorScheme();
                $.ajax({
                    url: '/m/design-do-customizer-reset/',
                    data: {type: 0},
                    type: 'post'
                });
            }

            return false;
        });

        function resetColorScheme() {
            $('style.customizer').remove();
            $('input.colorSelect').each(function () {
                $(this).spectrum("set", $(this).data('default'));
            });
        }

        function resetFontScheme() {
            $('style.customizer-fonts').remove();
        }

        // used by admin to quickly add new schemes
        $('#mz_btn_save_colors').on('click', function () {
            var all = $('input.colorSelect');
            if (typeof mozColorSchemes !== "undefined") {
                var allSchemes = mozColorSchemes.slice();
            } else {
                var allSchemes = new Array();
            }
            var scheme = {};
            all.each(function () {
                var element = {id: $(this).data('name'), value: $(this).val()};
                scheme[$(this).data('name')] = $(this).val();
            });
            allSchemes.push(scheme);
            var theClipboard = new TrelloClipboard();
            theClipboard.setValue(JSON.stringify(allSchemes, undefined, 4));
            return res;
        });

        $("#mz_topbar a.customize, #mz_topbar a.customize-fonts").on('click touchend', function () {

            if (noClicks() || isSwipeTakingPlace) {
                e.stopPropagation();
                return false;
            }

            // hide popup menu
            $(this).parent().parent().hide();

            if ($("#mz_topbar").hasClass('floating')) {
                $("#mz_topbar").removeClass('floating').hide();
                closeAllSubmenus();
            }

            // hide all panels
            $('.customizer-panel').hide();

            if ($(this).hasClass('customize-fonts')) {

                // font customization mode
                loadFontSchemes();

            } else {

                // color customization mode
                // add color schemes
                loadColorSchemes();

            }

            // slide in customizer
            $("#mz_customizer").show();
            $("#mz_customizer").transition({x: 200}, 200);

            // animate body
            $('body').transition({marginLeft: '200px', delay: 100}, 100);

            return false;
        });

        function loadFontSchemes() {

            function getPrettyFontName(font) {
                font = font.split(',')[0];
                font = font.replace(/["']/g, "");
                return font;
            }

            function loadCssFile(url)
            {
                var fileref = document.createElement("link");
                fileref.rel = "stylesheet";
                fileref.type = "text/css";
                fileref.href = url;
                document.getElementsByTagName("head")[0].appendChild(fileref);
            }

            function applyFontScheme(e) {
                if (noClicks() || isSwipeTakingPlace) {
                    e.stopPropagation();
                    return false;
                }
                var scheme = mozFontSchemes[$(this).data('index')];
                resetFontScheme();
                $.each(scheme, function (key, value) {
                    customFonts[key] = value;
                    if (typeof mozDesignCustomizer[key] !== 'undefined') {
                        buildCssCode(key, mozDesignCustomizer[key].selectors, value, 'customizer-fonts');
                    }
                });
                saveFontScheme();

            }

            if ((typeof mozFontSchemes !== 'undefined') && ($('#mz_font_schemes .font-scheme').length == 0)) {
                var buffer = $(document.createDocumentFragment());
                var totalAvailableFonts = 0;
                for (var i = 0; i < mozFontSchemes.length; i++) {
                    var font_settings = mozFontSchemes[i]['settings'];
                    var supports_hebrew = false;
                    var supports_latin = true;
                    var is_hebrew = $('body').hasClass('mz_rtl');
                    if (typeof font_settings !== 'undefined') {
                        if (font_settings['supports-hebrew'] === true) {
                            supports_hebrew = true;
                        }
                        if (font_settings['supports-latin'] === false) {
                            supports_latin = false;
                        }
                    }

                    if ((!is_hebrew && supports_latin) || (is_hebrew && supports_hebrew)) {
                        var item = $('<div>').addClass('font-scheme').data('index', i).on('click touchend', applyFontScheme);

                        // show limited number at once
                        if (totalAvailableFonts > howManyFonts) {
                            item.hide();
                            $('#mz_font_customizer_more').show();
                        }

                        // Get font strings
                        var font_body = mozFontSchemes[i]['font_body'];
                        var font_header = mozFontSchemes[i]['font_h1'];

                        if (typeof font_body !== 'undefined' || typeof font_header !== 'undefined') {

                            var header_preview = $('<div>').addClass('header-preview').html(getPrettyFontName(font_header['font-family']));
                            var body_preview = $('<div>').addClass('body-preview').html('& ' + getPrettyFontName(font_body['font-family']));

                            // generate preview, use only applicable values
                            $.each(font_header, function (key, value) {
                                if ($.inArray(key, 'font-family', 'font-weight', 'letter-spacing')) {
                                    header_preview.css(key, value);
                                }
                            });
                            $.each(font_body, function (key, value) {
                                if ($.inArray(key, 'font-family', 'font-weight', 'letter-spacing')) {
                                    body_preview.css(key, value);
                                }
                            });

                            item.append(header_preview).append(body_preview);
                            buffer.append(item);

                            // load external font urls
                            var font_loaders = mozFontSchemes[i]['font_loaders'];
                            if (typeof font_loaders !== 'undefined') {
                                if (typeof font_loaders.googlefonts !== 'undefined') {
                                    loadCssFile('https://fonts.googleapis.com/css?family=' + font_loaders.googlefonts + '&subset=latin,latin-ext,cyrillic');
                                }
                                if (typeof font_loaders.mozellofonts !== 'undefined') {
                                    loadCssFile(MOZELLO_CDN + '/designs/_shared/fonts/?family=' + font_loaders.mozellofonts + '&v=' + MOZELLO_VERSION);
                                }
                                /*for (var j = 0; j < font_loaders.length; j++) {
                                    loadCssFile(font_loaders[j]);
                                }*/
                            }
                        }
                        totalAvailableFonts++;
                    }
                }

                $("#mz_font_customizer_more").before(buffer);

            }

            $("#mz_font_schemes").show();

        }

        function loadAdvancedColorCustomizer() {
            // load advanced color customization gui later in the background
            if ((typeof mozDesignCustomizer !== 'undefined') && ($('#mz_advanced_colors .colorSelect').length == 0)) {
                var buffer = $(document.createDocumentFragment());
                $.each(mozDesignCustomizer, function (key, value) {
                    var csutomizerItem = value;
                    if (csutomizerItem['type'] == 'color') {
                        var item = $('<div>').addClass(csutomizerItem['group']);
                        var input = $('<input>')
                                        .addClass('colorSelect')
                                        .attr('type', 'text')
                                        .attr('value', csutomizerItem['value'])
                                        .attr('data-default', csutomizerItem['default'])
                                        .attr('data-name', key);
                        if (csutomizerItem['transparency']) {
                            input.addClass('alpha');
                        }
                        // finalize item
                        item.append(input).append($('<label>').text(csutomizerItem['caption']));
                        // add item to panel
                        buffer.append(item);
                    }
                });

                $("#mz_customizer_more").before(buffer);
                reloadSpectrum();
            }
        }

        function loadColorSchemes() {


            function reduceColors(cols, num) {

                function calcHueDiff(hue1, hue2) {
                    var minh = Math.min(hue1, hue2);
                    var maxh = Math.max(hue1, hue2);
                    var diff1 = maxh - minh;
                    var diff2 = minh - (maxh - 360);
                    var diff = Math.min(diff1, diff2);
                    return diff;
                }

                function farthestHue(a, pickedcols) {
                    var i = -1;
                    var maxdiff = -2;
                    for (var n = 0; n < a.length; n++) {
                        var cand_h = a[n].toHsl().h;
                        var mincanddiff = 361;
                        for (var k = 0; k < pickedcols.length; k++) {
                            var ref_h = pickedcols[k].toHsl().h;
                            var diff = calcHueDiff(cand_h, ref_h);
                            if (diff < mincanddiff) {
                                mincanddiff = diff;
                            }
                        }
                        if (mincanddiff > maxdiff) {
                            maxdiff = mincanddiff;
                            i = n;
                        }
                    }
                    return i;
                }

                var tca = [];
                var graycolors = [];
                var saturedcolors = [];
                var diffcolors = [];
                var diffcolors_print = [];

                //convert to tinycolor
                for (var i = 0; i < cols.length; i++) {
                    tca[tca.length] = tinycolor(cols[i]);
                }

                //filter out grayscale colors
                for (var i = 0; i < tca.length; i++) {
                    var hsl = tca[i].toHsl();
                    if (hsl.s < 0.3) {
                        graycolors[graycolors.length] = tca[i];
                    } else {
                        saturedcolors[saturedcolors.length] = tca[i];
                    }
                }

                //pick different colors from saturated colors
                for (var i = 0; i < num && saturedcolors.length > 0; i++) {
                    var n = farthestHue(saturedcolors, diffcolors);
                    var chosenhsl = saturedcolors[n].toHsl();
                    diffcolors[diffcolors.length] = saturedcolors[n];
                    diffcolors_print[diffcolors_print.length] = saturedcolors[n].toRgbString();
                    saturedcolors.splice(n, 1);
                }

                //if not enough colors, add some from grayscale colors
                for (var i = 0; i < graycolors.length && diffcolors_print.length < num; i++) {
                    diffcolors_print[diffcolors_print.length] = graycolors[i].toRgbString();
                }

                return diffcolors_print;

            }


            function applyColorScheme() {
                if (noClicks() || isSwipeTakingPlace) {
                    e.stopPropagation();
                    return false;
                }
                resetColorScheme();
                var scheme = mozColorSchemes[$(this).data('index')];
                $.each(scheme, function (key, value) {
                    if (key != 'color') {
                        var input_elem = $('#mz_customizer').find(".colorSelect[data-name='" + key + "']");
                        if (input_elem.length > 0) {
                            input_elem.spectrum("set", value);
                            updateColor(input_elem.get(0), input_elem.spectrum("get"));
                        }
                    }
                });
                saveColorScheme();
            }

            $("#mz_customizer_schemes").hide();

            loadAdvancedColorCustomizer();

            $("#mz_advanced_colors").show();

            // load color schemes first
            if ((typeof mozColorSchemes !== 'undefined') && ($('#mz_color_schemes .color-scheme').length == 0)) {
                var buffer = $(document.createDocumentFragment());
                for (var i = 0; i < mozColorSchemes.length; i++) {
                    var item = $('<div>').addClass('color-scheme').data('index', i).on('click touchend', applyColorScheme);
                    var color_count = Object.keys(mozColorSchemes[i]).length;
                    var previewSet = new Array();
                    for (var key in mozColorSchemes[i]) {
                        if (mozColorSchemes[i].hasOwnProperty(key)) {
                            previewSet.push(tinycolor(mozColorSchemes[i][key]).toRgbString());
                        }
                    }
                    var uniquePreviewSet = previewSet.filter(onlyUnique);
                    uniquePreviewSet = reduceColors(uniquePreviewSet, 6);
                    for (var j = 0; j < uniquePreviewSet.length; j++) {
                        item.append($('<div>').css({'background-color': uniquePreviewSet[j], 'width': 100 / uniquePreviewSet.length + '%'}));
                    }
                    buffer.append(item);
                }
                $("#mz_customizer_advanced").before(buffer);
            }

            // if schemes exist, show schemes
            if ($('#mz_color_schemes .color-scheme').length > 0) {
                $("#mz_customizer_schemes").show();
                $("#mz_color_schemes").show();
            } else {
                $("#mz_advanced_colors").css({x: -200});
            }

        }

        $("#mz_customizer_advanced").on('click touchend', function () {
            if (noClicks() || isSwipeTakingPlace) {
                e.stopPropagation();
                return false;
            }

            // prepare custom color grid
            $("#mz_advanced_colors .more").hide();
            $("#mz_advanced_colors .general").show();

            // slide out schemes
            $("#mz_color_schemes").transition({x: -200}, 200); // hide
            // slide in custom colors
            $("#mz_advanced_colors").show().transition({x: -200}, 200); // show

            return false;
        });

        $("#mz_customizer_schemes").on('click touchend', function () {
            if (noClicks() || isSwipeTakingPlace) {
                e.stopPropagation();
                return false;
            }
            // slide out advanced colors
            $("#mz_advanced_colors").transition({x: 0}, 200); // show
            // slide in schemes
            $("#mz_color_schemes").transition({x: 0}, 200); // hide
        });

        // fixes usability problem with long descriptions of colors

        $('#mz_advanced_colors div').on('mouseenter', function () {
            $('#mz_customizer').css({'overflow': 'visible'});
        });

        $('#mz_advanced_colors div').on('mouseleave', function () {
            $('#mz_customizer').css({'overflow': 'hidden'});
        });

    }

    /**
     * Initializes Popup windows.
     */
    function initializePopups()
    {
        // Displays Add / Remove Pages in a Popup window.

        $('div#mz_topbar a.pages, a.moze-pages').on('click touchend', function (e) {
            if (noClicks() || isSwipeTakingPlace) {
                e.stopPropagation();
                return false;
            }
            /*if (doNotUsePopups()) {
                window.location = '/m/pages/';
                return false;
            }*/
            $.smartModalWindow({
                href: '/m/pages/',
                innerWidth: 750,
                innerHeight: 750,
                onClosed: function () {
                    document.location = '/m/refresh/';
                },
                onCleanup: showLoadingScreen
            });
            return false;
        });

        // Menu links

        $('div#mz_topbar a.catalog, div#mz_topbar a.blogs, div#mz_topbar a.design, div#mz_topbar a.view, div#mz_topbar a.logout, div#mz_topbar a.site').on('click touchend', function () {
            if (noClicks() || isSwipeTakingPlace) {
                e.stopPropagation();
                return false;
            }

            if ($(this).data('href') != null) {
                // beauty first
                if ($(this).is('a.logout.animate')) {
                    $('body').addClass('transition-go-away');
                } else {
                    $('body').addClass('transition-fade-out');
                }
                window.location = $(this).data('href');
            }
            return false;
        });

        // Transition out animations

        $('a.moze-the-button, .mz_overlay_bar a').on('click touchend', function () {
            if (isSwipeTakingPlace) {
                return false;
            }
            if ($(this).attr('href') != null) {
                $('body').addClass('transition-fade-out');
            }
        });

        // Displays Website Address in a Popup window.

        $('div#mz_topbar a.address').on('click touchend', function () {
            if (noClicks() || isSwipeTakingPlace) {
                e.stopPropagation();
                return false;
            }
            /*if (doNotUsePopups()) {
                window.location = '/m/address/';
                return false;
            }*/
            $.smartModalWindow({
                href: '/m/address/',
                innerWidth: 650,
                innerHeight: 400,
                title: ' '
            });
            return false;
        });

        // Displays Settings in a Popup window.

        /*
        $('div#mz_topbar a.settings').on('click touchend', function () {
            if (noClicks() || isSwipeTakingPlace) {
                e.stopPropagation();
                return false;
            }
            if (doNotUsePopups()) {
                window.location = '/m/settings/';
                return false;
            }
            $.smartModalWindow({
                href: '/m/settings/',
                innerWidth: 735,
                innerHeight: 545,
                onClosed: function () {
                    $.ajax({
                        url: '/m/settings-do-favicon-deltemp/',
                        method: 'post'
                    });
                }
            });
            return false;
        });
        */

        // Displays Publish in a Popup window.

        $('div#mz_topbar a.publish').on('click touchend', function () {
            if (noClicks() || isSwipeTakingPlace) {
                e.stopPropagation();
                return false;
            }
            /*if (doNotUsePopups()) {
                window.location = '/m/publish/';
                return false;
            }*/
            $.smartModalWindow({
                href: '/m/publish/',
                innerWidth: 620,
                innerHeight: 270,
                onClosed: function () {
                    document.location = '/m/refresh/';
                }
            });
            return false;
        });

        // Displays Add Page in a Popup window.

        $('a.moze-add-page').on('click touchend', function () {
            if (noClicks() || isSwipeTakingPlace) {
                e.stopPropagation();
                return false;
            }
            /*if (doNotUsePopups()) {
                window.location = '/m/pages-settype/params/parent/0/';
                return false;
            }*/
            $.smartModalWindow({
                href: '/m/pages-settype/params/parent/0/',
                innerWidth: 580,
                innerHeight: 535,
                onClosed: function () {
                    document.location = '/m/refresh/';
                }
            });
            return false;
        });

        // Displays Add Language in a Popup window.

        $('a.moze-add-language').on('click touchend', function () {
            if (noClicks() || isSwipeTakingPlace) {
                e.stopPropagation();
                return false;
            }
            /*if (doNotUsePopups()) {
                window.location = '/m/languages/';
                return false;
            }*/
            $.smartModalWindow({
                href: '/m/languages/',
                innerWidth: 580,
                innerHeight: 450,
                onCleanup: showLoadingScreen,
                onClosed: function () {
                    document.location = '/m/refresh/';
                }
            });
            return false;
        });

        // Displays Social Network edit in a Popup window.

        $('a.moze-social-edit').on('click touchend', function () {
            if (noClicks() || isSwipeTakingPlace) {
                e.stopPropagation();
                return false;
            }
            /*if (doNotUsePopups()) {
                window.location = $(this).data('href');
                return false;
            }*/
            $.smartModalWindow({
                href: $(this).data('href'),
                innerWidth: '730px',
                innerHeight: '470px',
                title: ' ' // blank
            });
            return false;
        });

    }

    /**
     * Initializes Mozello components.
     */
    function initializeComponents()
    {
        // Loads MozWysiwyg component.

        rangy.init();

        $.mozbannerinit();
        $.mozgalleryinit();
        $.mozwysiwyginit();

        $.mozgridinit();

        // Shows startup alerts.

        $.ajax({
            url: '/m/ajax-check-startup-alerts/',
            type: 'post',
            success: function (data) {
                try
                {
                    var response = $.parseJSON(data);
                }
                catch (e)
                {
                    return;
                }

                // Premium triangle.

                if (response.premium_triangle == true)
                {
                    if (!isSmallMobileDevice()) {
                        createPremiumTriangleAdvert(response.reseller, response.reseller_buy_link, response.premium_triangle_swedbank);
                    }
                }

                // E-mail confirmation alert.

                if (response.email_confirm_alert == true)
                {
                    $.smartModalWindow({
                        href: '/m/alert-email-confirm/',
                        innerWidth: '600px',
                        innerHeight: '350px',
                        onClosed: function ()
                        {
                            $.ajax({
                                url: '/m/ajax-close-startup-alert/',
                                type: 'post',
                                data: {alert: 'email_confirm_alert'}
                            });
                        }
                    });
                }
            }
        });

        // Blog

        $('a.moze-blog-delete').click(function () {
            if (confirm($(this).data('confirmation')) == true)
            {
                var div = $(this).parents('.moze-post');
                div.fadeTo(400, 0).slideUp(function () {
                    $.ajax({
                        url: '/m/blog-post-delete/',
                        type: 'post',
                        data: {
                            blog: div.data('blog'),
                            post: div.data('pid')
                        },
                        success: function (data) {
                            div.remove();
                        },
                        error: function (data) {
                            div.show();
                        }
                    });
                });
            }
            return false;
        });

        function togglePublished(div, a) {
            if (a.hasClass('hide')) {
                a.html(BLG_PUBLISH);
            } else {
                a.html(BLG_HIDE);
            }
            a.toggleClass('hide').toggleClass('show');
            div.find('.unpublished').toggle();
        }

        $('a.moze-blog-publish').click(function () {
            var div = $(this).parents('.moze-post');
            if (div.length == 0) {
                div = $(this).parents('.moze-post-container');
            }
            var link = $(this);
            if (link.hasClass('hide')) {
                var action = '/m/blog-post-hide/';
            } else {
                var action = '/m/blog-post-publish/';
            }
            togglePublished(div, link);
            $.ajax({
                url: action,
                type: 'post',
                data: {
                    blog: div.data('blog'),
                    post: div.data('pid')
                },
                success: function (data) {
                    // additional success
                },
                error: function (xhr, status, error) {
                    togglePublished(div, link); // toggle back
                }
            });
            return false;
        });


    }


    /**
     * Initializes GUI action overlays
     */
    function initializeOverlays()
    {

        // Shows and hides banner component buttons, special processing since banner may be behind other elements

        var overlays = ".mz_banner, .over-bigbar";
        var show_banner_buttons = false;

        $(overlays).mouseenter(function (e) {
            show_banner_buttons = true;
            $('.mz_banner .mz_overlay_bar, .mz_floating_bar').show();
        });

        $(overlays).mouseleave(function (e) {
            if (!$(e.relatedTarget).is(overlays) &&
                ($(e.relatedTarget).parents('.mz_overlay_bar').length == 0) &&
                ($(e.relatedTarget).parents('.over-bigbar').length == 0)) {
                show_banner_buttons = false;
                setTimeout(function doSomething() {
                    if (!show_banner_buttons) {
                        $('.mz_banner .mz_overlay_bar, .mz_floating_bar').hide();
                    }
                }, 1500);
            }
        });

        // Attempt to setup JS-driven overlay operation

        /*

        var overlays = ".mz_menu"; // add compatible components here

        $(overlays).mouseenter(function (e) {
            $(this).find('.mz_overlay_bar').removeClass('hiding').show();
        });

        $(overlays).mouseleave(function (e) {
            var component = $(this);
            component.find('.mz_overlay_bar').addClass('hiding');
            setTimeout(function doSomething() {
                component.find('.mz_overlay_bar.hiding').removeClass('hiding').hide();
            }, 1500);
        });

        */

        // calculate menu overlay size
        // menu might not exist at all (if one page per language)

        var menu_offset = $('.mz_menu > ul').offset();
        var menu_position = $('.mz_menu > ul').position();

        if (typeof menu_offset != 'undefined') {

            // fix width on short menu containers, +2px is there to fix FF bug with returning wrong widths when using Open Sans
            $('.mz_menu .mz_overlay_bar').css('width', $('.mz_overlay_bar .moze-pages').outerWidth() + $('.mz_overlay_bar .moze-add-page').outerWidth() + 5 + 'px');

            if (menu_offset.top < 32) {
                $('.mz_menu .mz_overlay_bar').css('top', '-' + menu_offset.top + 'px')/*.css('left', '-' + ($('.mz_menu .mz_overlay_bar').outerWidth() - 10) + 'px')*/;
            } else if ($('body').hasClass('mz_rtl')) {
                $('.mz_menu .mz_overlay_bar').css('right', menu_position.left + 'px');
            } else {
                $('.mz_menu .mz_overlay_bar').css('left', menu_position.left + 'px');
            }

        }
    }

    /**
     * Creates a Premium Website triangle advert at the specified position.
     */
    function createPremiumTriangleAdvert(reseller, resellerBuyLink, isSwedbank)
    {
        var triStartX = $('#mz_topbar').outerWidth();

        $('body')
            .append($('<div>')
            .addClass('mz_corner_triangle')
            .append($('<div>').html(!isSwedbank ? BFX_UPGRADE : BFX_UPGRADE_SWEDBANK))
            .on('click touchstart', function(e) {
                if (noClicks()) {
                    e.stopPropagation();
                    return false;
                }
                if (reseller && !isSwedbank) {
                    if (resellerBuyLink != '') {
                        window.open(resellerBuyLink, '_blank');
                    }
                }
                else {
                    $.smartModalWindow({
                        innerHeight: 580,
                        href: '/m/premium/',
                        innerWidth: 1100
                    });
                }
                return false;
            }));

        var triangleCloseBtn = $('<div>')
            .addClass('mz_premium_triangle_close')
            .css('background', 'url("/backend/css/premium-triangle-close.png") no-repeat 0px 0px')
            .css('height', '12px')
            .css('width', '12px')
            .css('position', 'fixed')
            .css('left', (triStartX + 10).toString() + 'px')
            .css('overflow', 'hidden')
            .css('cursor', 'pointer')
            .html('')
            .click(function () {
                $.ajax({
                    url: '/m/ajax-close-startup-alert/',
                    type: 'post',
                    data: {alert: 'premium_triangle'},
                    success: function () {
                        $('div.mz_corner_triangle').remove();
                        $('div.mz_premium_triangle_close').remove();
                    }
                });
            });

        if (isSwedbank) {
            $('.mz_corner_triangle').addClass('swedbank');
        }

        $('body').append(triangleCloseBtn);
    }

    function checkIfBackendIsAlive()
    {
        $.ajax({
            url: '/m/ajax-is-alive/',
            type: 'post',
            success: function(data) {
                if (data !== 'alive') {
                    window.location.href = '/';
                }
            },
            statusCode: {
                404: function() {
                    window.location.href = '/';
                }
            }
        });
    }

    // Workaround for mobile CSS fixed bug

    if (isMobileDevice()) {

        $(window).scroll(function () {

            var nav = $(".touch-mode #mz_topbar:visible");
            if (nav.length) {
                var scrollTop = $(window).scrollTop();
                var offsetTop = nav.offset().top;

                if (Math.abs(scrollTop - offsetTop) > 1) {
                    nav.css('position', 'absolute');
                    setTimeout(function () {
                        nav.css('position', 'fixed');
                    }, 100);
                }
            }

        });

    }

    var olay = $('#bigbar-overlay');

    function updateOverlayVisibility() {
        if ($.trim(olay.find('.moze-wysiwyg-editor:visible').text()) == '') {
            olay.css('background-color', 'transparent');
        } else {
            olay.css('background-color', '');
        }
    }

    if (olay.length) {
        updateOverlayVisibility();
        olay.keyup(updateOverlayVisibility);
    }

    /* End */
});