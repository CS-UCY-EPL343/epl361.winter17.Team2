package prototype;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.BorderLayout;
import javax.swing.JLabel;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.ImageIcon;

public class ChangeUsername {

	private JFrame frame;
	private JPasswordField passwordField;
	private JTextField textField;
	private JTextField textField_1;

	/**
	 * Launch the application.
	 */
	public static void username() {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ChangeUsername window = new ChangeUsername();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public ChangeUsername() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 567, 406);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		JPanel panel = new JPanel();
		frame.getContentPane().add(panel, BorderLayout.CENTER);
		panel.setLayout(null);
		
		JLabel lblUsername = new JLabel("Username: ");
		lblUsername.setFont(new Font("Times New Roman", Font.BOLD, 14));
		lblUsername.setForeground(Color.WHITE);
		lblUsername.setBounds(78, 116, 105, 25);
		panel.add(lblUsername);
		
		JLabel lblPassword = new JLabel("Password: ");
		lblPassword.setForeground(Color.WHITE);
		lblPassword.setFont(new Font("Times New Roman", Font.BOLD, 14));
		lblPassword.setBounds(80, 189, 121, 27);
		panel.add(lblPassword);
		
		JLabel lblNewLabel = new JLabel("New Username: ");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblNewLabel.setForeground(Color.WHITE);
		lblNewLabel.setBounds(78, 152, 105, 26);
		panel.add(lblNewLabel);
		
		passwordField = new JPasswordField();
		passwordField.setBounds(254, 193, 121, 20);
		panel.add(passwordField);
		
		textField = new JTextField();
		textField.setBounds(254, 154, 121, 23);
		panel.add(textField);
		textField.setColumns(10);
		
		textField_1 = new JTextField();
		textField_1.setBounds(254, 119, 121, 20);
		panel.add(textField_1);
		textField_1.setColumns(10);
		
		JButton btnConfirm = new JButton("Confirm");
		btnConfirm.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				general fr=new general();
				fr.GeneralSite();;
			}
		});
		btnConfirm.setBackground(Color.WHITE);
		btnConfirm.setFont(new Font("Tempus Sans ITC", Font.BOLD, 14));
		btnConfirm.setForeground(Color.RED);
		btnConfirm.setBounds(166, 255, 105, 25);
		panel.add(btnConfirm);
		
		JLabel lblNewLabel_1 = new JLabel("");
		lblNewLabel_1.setIcon(new ImageIcon(ChangeUsername.class.getResource("/prototype/ugo-s-cafe-bar.jpg")));
		lblNewLabel_1.setBounds(10, 0, 550, 367);
		panel.add(lblNewLabel_1);
		
		JButton btnGoBack = new JButton("Go Back");
		btnGoBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ManageAccount manage= new ManageAccount();
				String[] args = null;
				ManageAccount.main(args);
			}
		});
		btnGoBack.setFont(new Font("Tempus Sans ITC", Font.BOLD, 11));
		btnGoBack.setForeground(Color.RED);
		btnGoBack.setBackground(Color.WHITE);
		btnGoBack.setBounds(10, 0, 89, 23);
		panel.add(btnGoBack);
	}
}
