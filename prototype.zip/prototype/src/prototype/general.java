package prototype;

import java.awt.EventQueue;

import javax.swing.JFrame;
import java.awt.Color;
import javax.swing.JButton;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.Image;

import javax.swing.ImageIcon;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.UIManager;
import javax.swing.JScrollBar;

public class general {

	private JFrame frame;

	/**
	 * Launch the application.
	 */
	public static void GeneralSite() {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					general window = new general();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public general() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.getContentPane().setBackground(Color.WHITE);
		frame.getContentPane().setLayout(null);
		
		JButton btnManageWebsite = new JButton("Manage Website");
		btnManageWebsite.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnManageWebsite.setBackground(Color.LIGHT_GRAY);
		btnManageWebsite.setForeground(Color.RED);
		btnManageWebsite.setFont(new Font("Comic Sans MS", Font.BOLD | Font.ITALIC, 14));
		btnManageWebsite.setBounds(52, 95, 182, 29);
		frame.getContentPane().add(btnManageWebsite);
		
		JButton btnManageDatabase = new JButton("Manage Database");
		btnManageDatabase.setBackground(Color.LIGHT_GRAY);
		btnManageDatabase.setFont(new Font("Comic Sans MS", Font.BOLD | Font.ITALIC, 14));
		btnManageDatabase.setForeground(Color.RED);
		btnManageDatabase.setBounds(284, 95, 182, 29);
		frame.getContentPane().add(btnManageDatabase);
		
		JButton btnManageAccount = new JButton("Manage Account");
		btnManageAccount.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ManageAccount mg=new ManageAccount();
				String[] st=null;
				mg.main(st);
			}
		});
		btnManageAccount.setBackground(Color.LIGHT_GRAY);
		btnManageAccount.setForeground(Color.RED);
		btnManageAccount.setFont(new Font("Comic Sans MS", Font.BOLD | Font.ITALIC, 14));
		btnManageAccount.setBounds(167, 152, 182, 29);
		frame.getContentPane().add(btnManageAccount);
		
		JLabel lblWelcomeToYour = new JLabel("Welcome to your account\r\n\r\n");
		lblWelcomeToYour.setFont(new Font("Comic Sans MS", Font.BOLD | Font.ITALIC, 18));
		lblWelcomeToYour.setForeground(Color.RED);
		lblWelcomeToYour.setBounds(151, 11, 258, 29);
		frame.getContentPane().add(lblWelcomeToYour);
		
		JLabel lblPleaseChooseThe = new JLabel("Please choose the action you want to execute:");
		lblPleaseChooseThe.setFont(new Font("Comic Sans MS", Font.BOLD | Font.ITALIC, 14));
		lblPleaseChooseThe.setForeground(Color.GRAY);
		lblPleaseChooseThe.setBounds(10, 59, 327, 21);
		frame.getContentPane().add(lblPleaseChooseThe);
		
		JLabel label = new JLabel("");
		ImageIcon im;
		label.setIcon(new ImageIcon(general.class.getResource("/prototype/cat_n_dog.gif")));
		label.setBounds(40, 192, 473, 144);
		frame.getContentPane().add(label);
		
		JButton button = new JButton("Go Back");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String[] k=null;
				frame f=new frame();
				f.main(k);
			}
		});
		button.setFont(new Font("Comic Sans MS", Font.BOLD, 12));
		button.setBounds(0, 0, 89, 23);
		frame.getContentPane().add(button);
		frame.setBackground(Color.WHITE);
		frame.setBounds(100, 100, 566, 375);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}

}
