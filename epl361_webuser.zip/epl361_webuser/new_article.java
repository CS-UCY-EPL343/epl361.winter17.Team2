package epl361_webuser;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JComboBox;
import javax.swing.SwingConstants;
import javax.swing.JEditorPane;

public class new_article extends JFrame {

	private JPanel contentPane;
	private JEditorPane textField;
	private JButton btnUploadVideo;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					new_article frame = new new_article();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public new_article() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100,800, 411);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		textField = new JEditorPane();
		textField.setToolTipText("");
		textField.setBounds(55, 23, 275, 228);
		contentPane.add(textField);
		
		JButton btnUploadPhoto = new JButton("+ Upload Photo");
		btnUploadPhoto.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			}
		});
		btnUploadPhoto.setBounds(377, 23, 164, 23);
		contentPane.add(btnUploadPhoto);
		
		btnUploadVideo = new JButton("+ Upload Video");
		btnUploadVideo.setBounds(379, 68, 162, 23);
		contentPane.add(btnUploadVideo);
		
		JButton btnSaveAndPublish = new JButton("Save and Publish");
		btnSaveAndPublish.setBounds(102, 262, 164, 23);
		contentPane.add(btnSaveAndPublish);
	}
}
