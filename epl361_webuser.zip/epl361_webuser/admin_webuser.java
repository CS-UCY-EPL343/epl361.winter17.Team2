package epl361_webuser;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.BorderLayout;
import javax.swing.ImageIcon;
import java.awt.Font;
import javax.swing.SwingConstants;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.JButton;
import javax.swing.JComboBox;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class admin_webuser {

	private JFrame frame;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					admin_webuser window = new admin_webuser();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public admin_webuser() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 769, 506);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setIcon(new ImageIcon(admin_webuser.class.getResource("/epl361_webuser/happy&home.jpg")));
		lblNewLabel.setBounds(0, 0, 113, 101);
		frame.getContentPane().add(lblNewLabel);
		
		JLabel lblAdminPanel = new JLabel("Admin Panel ");
		lblAdminPanel.setHorizontalAlignment(SwingConstants.CENTER);
		lblAdminPanel.setFont(new Font("Tahoma", Font.ITALIC, 16));
		lblAdminPanel.setBounds(303, 47, 113, 28);
		frame.getContentPane().add(lblAdminPanel);
		
		    
		
		String tabs[] ={"Home","Successful Stories", "Report for stray animal", "Events","About us","Contanct","Adoptions","Animal's Gallery","Advices&Tips","Donation"};		
		JComboBox comboBox = new JComboBox(tabs);
		
		comboBox.setBounds(511, 146, 169, 38);
		frame.getContentPane().add(comboBox);
		
		JButton btnEdit = new JButton("Edit ");
		btnEdit.addActionListener(new ActionListener() {	
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				comboBox.setVisible(!comboBox.isVisible());}
						
		});
		comboBox.setVisible(Boolean.FALSE);
		frame.getContentPane().add(comboBox);
		frame.getContentPane().add(comboBox);
		
		btnEdit.setBounds(256, 141, 199, 48);
		frame.getContentPane().add(btnEdit);
		
		JButton btnView = new JButton("View");
		btnView.setBounds(256, 227, 199, 48);
		frame.getContentPane().add(btnView);

		btnView.addActionListener(new ActionListener() {	
			@Override
			public void actionPerformed(ActionEvent e) {
				try { 
			         String url = "http://eriakouppari97.mozello.com/";
			         java.awt.Desktop.getDesktop().browse(java.net.URI.create(url));
			       }
			       catch (java.io.IOException ex) {
			           System.out.println(ex.getMessage());
			       }}
						
		});
		
		
	
	}
}
