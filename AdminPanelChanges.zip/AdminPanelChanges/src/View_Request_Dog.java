import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTable;
import javax.swing.SwingConstants;
import javax.swing.table.DefaultTableModel;
import java.awt.Color;

public class View_Request_Dog {

	private JFrame frame;
	private JTable table;

	/**
	 * Launch the application.
	 */
	public static void view() {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					View_Request_Dog window = new View_Request_Dog();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public View_Request_Dog() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 800, 455);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblViewRequestDogTable = new JLabel("View 'Request for a Dog' Table");
		lblViewRequestDogTable.setForeground(Color.RED);
		lblViewRequestDogTable.setHorizontalAlignment(SwingConstants.CENTER);
		lblViewRequestDogTable.setFont(new Font("Times New Roman", Font.PLAIN, 20));
		lblViewRequestDogTable.setBounds(10, 31, 714, 37);
		frame.getContentPane().add(lblViewRequestDogTable);
		
		table = new JTable();
		table.setModel(new DefaultTableModel(
			new Object[][] {
				{"S/N", "Adopter's Fullname", "Adopter's Address", "Adopter's Phone", "Adopter's Email", "Adopter's Age", "Family Members", "Discussed with Family", "Dog's Number", "Dog's Name", "Dog's Breed", "Dog's Gender", "Dog's Age", "Activities Planned", "Employeed"},
				{null, null, null, null, null, null, null, null, null, null, null, null, null, null, null},
				{"1", "Vasos Ioannou", "Galinis 15, Aglantzia, Nicosia", "96525265", "vasos_ioan@gmail.com", "20", null, null, "152", "Ellie", "Other", "Female", "2", "Don't Know", "NO"},
				{"2", "Eleftherios Andreou", "Georgiou Nikolaidi 8, Livadia, Larnaca", "97215653", "eleftherios_andreou@gmail.com", "36", "Wife, 1 Child", "YES", "96", null, null, "Male", "1", "Obidience", "YES"},
				{"3", "Natalia Venizelou", "Agiou Savva 62, Livadia, Larnaca", "99315315", null, "27", "Husband", "NO", null, null, null, "Male", "3", "Obidience", "YES"},
				{"4", "Ermioni Vasileiou", "Panepistimiou 13, Aglantzia, Nicosia", "97321315", null, "19", "Mother, Father", "YES", "75", "Ellie", null, "Male", "", "Don't Know", "NO"},
				{"5", "Maria Papa", "Agias Sofias 154, Aradipou, Larnaca", "99316516", "papa.mar54@yahoo.gr", "54", "Husband", "YES", "168", null, null, "Female", "2", "Obidience", "YES"},
				{"6", "Antigoni Theodoulou", "Markou Drakou 23, Aglantzia, Nicosia", "96365165", null, "49", "Husband", "NO", "358", "Charls", "Chihuahua", "Male", "1", "Other", "YES"},
				{"7", "Magda Tofari", "Chrysanthou Mylona 7, Strovolos, Nicosia", "96514635", null, "40", "Husband", "YES", null, null, null, "Female", "1", "Don't Know", "YES"},
				{"8", "Persefoni Panagiotou", "Tilepikoinonion 18, Strovolos, Nicosia", "99202552", null, "36", "Sister", "NO", "245", null, null, "Female", "3", "Gundog Training", "YES"},
				{"9", "Costas Christou", "Irinis 15, Limassol", "96462213", null, "28", "Brother", "NO", null, null, null, "Female", "1", "Obidience", "YES"},
				{"10", "Christos Antoniou", "Ellados 35, Limassol", "99863316", "antonchristos@outlook.com", "20", "Mother, Father, Sister", "YES", "149", null, "Labrador", "Male", "2", "Obidience", "NO"},
				{"11", "Maria Michael", "Kalamatas 24, Paphos", "99316353", "marmichael@hotmail.com", "36", null, null, "364", "Adison", null, "Female", null, "Gundog Work", "YES"},
				{"12", "Petros Hlia", "Michael Kyprianou 8, Paphos", "96215233", null, "60", null, null, null, "Elvis", "Other", "Male", null, "Don't Know", "NO"},
				{"13", "Antonia Georgiou", "Nicolaou P. Laniti 3, Limassol", "97326333", "ageorg@yahoo.com", "57", null, null, "34", null, null, "Male", "2", "Don't Know", "YES"},
			},
			new String[] {
				"S/N", "Adopter's Fullname", "Adopter's Address", "Adopter's Phone", "Adopter's Email", "Adopter's Age", "Family Members", "Discussed with Family", "Dog's Number", "Dog's Name", "Dog's Breed", "Dog's Gender", "Dog's Age", "Activities Planned", "Employeed"
			}
		));
		table.getColumnModel().getColumn(0).setPreferredWidth(30);
		table.getColumnModel().getColumn(1).setPreferredWidth(105);
		table.getColumnModel().getColumn(2).setPreferredWidth(206);
		table.getColumnModel().getColumn(3).setPreferredWidth(90);
		table.getColumnModel().getColumn(4).setPreferredWidth(158);
		table.getColumnModel().getColumn(6).setPreferredWidth(113);
		table.getColumnModel().getColumn(13).setPreferredWidth(84);
		table.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		table.setBounds(10, 87, 764, 241);
		frame.getContentPane().add(table);
		
		JButton btnClose = new JButton("Close");
		btnClose.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.exit(0);
			}
		});
		btnClose.setFont(new Font("Times New Roman", Font.PLAIN, 14));
		btnClose.setBounds(589, 370, 89, 23);
		frame.getContentPane().add(btnClose);
		
		JButton btnInsertData = new JButton("Insert Data");
		btnInsertData.setForeground(Color.RED);
		btnInsertData.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Insert_Request_Dog.InsertRequestDog();
				frame.setVisible(false);
			}
		});
		btnInsertData.setFont(new Font("Times New Roman", Font.PLAIN, 14));
		btnInsertData.setBounds(404, 370, 107, 23);
		frame.getContentPane().add(btnInsertData);
		
		JButton btnSearch = new JButton("Search");
		btnSearch.setForeground(Color.RED);
		btnSearch.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e) {
				Search_Request_Dog.SearchRequestDog();
				frame.setVisible(false);
			}
		});
		btnSearch.setFont(new Font("Times New Roman", Font.PLAIN, 14));
		btnSearch.setBounds(89, 370, 89, 23);
		frame.getContentPane().add(btnSearch);
		
		JButton btnEditData = new JButton("Edit Data");
		btnEditData.setForeground(Color.RED);
		btnEditData.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Edit_Request_Dog.EditRequestDog();
				frame.setVisible(false);
			}
		});
		btnEditData.setFont(new Font("Times New Roman", Font.PLAIN, 14));
		btnEditData.setBounds(245, 370, 89, 23);
		frame.getContentPane().add(btnEditData);
		
		JButton button = new JButton("<-Back");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Select_Table.selectTable();
				frame.setVisible(false);

			}
		});
		button.setBounds(0, -3, 89, 23);
		frame.getContentPane().add(button);
	}

}
