import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.BorderLayout;
import java.awt.Button;

import javax.swing.JButton;
import java.awt.Color;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class AcceptSelectTable {

	private JFrame frame;

	/**
	 * Launch the application.
	 */
	public static void accept() {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					AcceptSelectTable window = new AcceptSelectTable();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public AcceptSelectTable() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel label = new JLabel("");
		label.setBounds(0, 0, 434, 0);
		frame.getContentPane().add(label);
		
		JButton btnNewButton = new JButton("Dogs Requests");
		btnNewButton.setForeground(Color.RED);
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				AcceptDogRequests.accept();
				frame.setVisible(false);
			}
		});
		btnNewButton.setBounds(154, 102, 125, 23);
		frame.getContentPane().add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("Cats Requests");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				AcceptCatRequest.accept();
				frame.setVisible(false);
			}
		});
		btnNewButton_1.setForeground(Color.RED);
		btnNewButton_1.setBounds(154, 158, 125, 23);
		frame.getContentPane().add(btnNewButton_1);
		
		JLabel lblSelectATable = new JLabel("Select A Table From Were You would Like to Accept a request");
		lblSelectATable.setForeground(Color.RED);
		lblSelectATable.setBounds(81, 44, 305, 14);
		frame.getContentPane().add(lblSelectATable);
		
		JButton button = new JButton("<-Go Back");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				DB_initialView.main(null);
				frame.setVisible(false);
			}
		});
		button.setBounds(0, 0, 89, 23);
		frame.getContentPane().add(button);
		
	}
}
