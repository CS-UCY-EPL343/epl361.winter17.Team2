import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JSpinner;
import javax.swing.JTextField;
import javax.swing.SpinnerNumberModel;
import javax.swing.SwingConstants;
import java.awt.Color;

public class Edit_Request_Cat {

	private JFrame frame;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;
	private JTextField textField_4;
	private JTextField textField_5;
	private JTextField textField_6;
	private JTextField textField_7;

	/**
	 * Launch the application.
	 */
	public static void EditRequestCat() {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Edit_Request_Cat window = new Edit_Request_Cat();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Edit_Request_Cat() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 486, 499);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblInsertData = new JLabel("Edit/Update a Table's Record");
		lblInsertData.setForeground(Color.RED);
		lblInsertData.setHorizontalAlignment(SwingConstants.CENTER);
		lblInsertData.setFont(new Font("Times New Roman", Font.PLAIN, 20));
		lblInsertData.setBounds(10, 11, 450, 24);
		frame.getContentPane().add(lblInsertData);
		
		JLabel lblAdoptersName = new JLabel("Adopter's Name:");
		lblAdoptersName.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		lblAdoptersName.setBounds(104, 61, 92, 14);
		frame.getContentPane().add(lblAdoptersName);
		
		textField = new JTextField();
		textField.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		textField.setBounds(206, 58, 67, 20);
		frame.getContentPane().add(textField);
		textField.setColumns(10);
		
		JLabel lblAdoptersAddress = new JLabel("Adopter's Address:");
		lblAdoptersAddress.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		lblAdoptersAddress.setBounds(283, 61, 100, 14);
		frame.getContentPane().add(lblAdoptersAddress);
		
		textField_1 = new JTextField();
		textField_1.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		textField_1.setColumns(10);
		textField_1.setBounds(393, 58, 67, 20);
		frame.getContentPane().add(textField_1);
		
		JLabel lblAdoptersPhone = new JLabel("Adopter's Phone:");
		lblAdoptersPhone.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		lblAdoptersPhone.setBounds(26, 106, 92, 14);
		frame.getContentPane().add(lblAdoptersPhone);
		
		textField_2 = new JTextField();
		textField_2.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		textField_2.setColumns(10);
		textField_2.setBounds(128, 103, 86, 20);
		frame.getContentPane().add(textField_2);
		
		JLabel lblAdoptersEmail = new JLabel("Adopter's Email:");
		lblAdoptersEmail.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		lblAdoptersEmail.setBounds(232, 106, 100, 14);
		frame.getContentPane().add(lblAdoptersEmail);
		
		textField_3 = new JTextField();
		textField_3.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		textField_3.setColumns(10);
		textField_3.setBounds(342, 103, 86, 20);
		frame.getContentPane().add(textField_3);
		
		JLabel lblAdoptersAge = new JLabel("Adopter's Age:");
		lblAdoptersAge.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		lblAdoptersAge.setBounds(26, 152, 92, 14);
		frame.getContentPane().add(lblAdoptersAge);
		
		JSpinner spinner = new JSpinner();
		spinner.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		spinner.setModel(new SpinnerNumberModel(18, 18, 66, 1));
		spinner.setBounds(128, 149, 46, 20);
		frame.getContentPane().add(spinner);
		
		JLabel lblFamilyMembers = new JLabel("Family Members:");
		lblFamilyMembers.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		lblFamilyMembers.setBounds(26, 345, 100, 14);
		frame.getContentPane().add(lblFamilyMembers);
		
		JLabel lblDiscussedWithFamilly = new JLabel("Discussed with Familly:");
		lblDiscussedWithFamilly.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		lblDiscussedWithFamilly.setBounds(26, 198, 126, 23);
		frame.getContentPane().add(lblDiscussedWithFamilly);
		
		JCheckBox chckbxNewCheckBox = new JCheckBox("");
		chckbxNewCheckBox.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		chckbxNewCheckBox.setBounds(171, 198, 21, 23);
		frame.getContentPane().add(chckbxNewCheckBox);
		
		JLabel lblCatsNumber = new JLabel("Cat's Number:");
		lblCatsNumber.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		lblCatsNumber.setBounds(232, 152, 100, 14);
		frame.getContentPane().add(lblCatsNumber);
		
		textField_4 = new JTextField();
		textField_4.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		textField_4.setColumns(10);
		textField_4.setBounds(342, 149, 86, 20);
		frame.getContentPane().add(textField_4);
		
		JLabel lblCatsName = new JLabel("Cat's Name:");
		lblCatsName.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		lblCatsName.setBounds(232, 202, 100, 14);
		frame.getContentPane().add(lblCatsName);
		
		textField_5 = new JTextField();
		textField_5.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		textField_5.setColumns(10);
		textField_5.setBounds(342, 199, 86, 20);
		frame.getContentPane().add(textField_5);
		
		JLabel lblCatsBreed = new JLabel("Cat's Breed:");
		lblCatsBreed.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		lblCatsBreed.setBounds(232, 249, 100, 14);
		frame.getContentPane().add(lblCatsBreed);
		
		textField_6 = new JTextField();
		textField_6.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		textField_6.setColumns(10);
		textField_6.setBounds(342, 246, 86, 20);
		frame.getContentPane().add(textField_6);
		
		JLabel lblCatsGender = new JLabel("Cat's Gender:");
		lblCatsGender.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		lblCatsGender.setBounds(26, 294, 100, 14);
		frame.getContentPane().add(lblCatsGender);
		
		JComboBox comboBox = new JComboBox();
		comboBox.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		comboBox.setModel(new DefaultComboBoxModel(new String[] {"Select...", "Male", "Female"}));
		comboBox.setBounds(128, 291, 86, 20);
		frame.getContentPane().add(comboBox);
		
		JLabel lblCats = new JLabel("Cat's Age:");
		lblCats.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		lblCats.setBounds(26, 249, 100, 14);
		frame.getContentPane().add(lblCats);
		
		JSpinner spinner_1 = new JSpinner();
		spinner_1.setModel(new SpinnerNumberModel(1, 1, 15, 1));
		spinner_1.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		spinner_1.setBounds(128, 246, 46, 20);
		frame.getContentPane().add(spinner_1);
		
		JLabel lblDayCompleted = new JLabel("Day Completed:");
		lblDayCompleted.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		lblDayCompleted.setBounds(232, 294, 100, 14);
		frame.getContentPane().add(lblDayCompleted);
		
		textField_7 = new JTextField();
		textField_7.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		textField_7.setColumns(10);
		textField_7.setBounds(342, 291, 86, 20);
		frame.getContentPane().add(textField_7);
		
		JButton btnSave = new JButton("Save");
		btnSave.setForeground(Color.RED);
		btnSave.setFont(new Font("Times New Roman", Font.PLAIN, 14));
		btnSave.setBounds(26, 426, 89, 23);
		frame.getContentPane().add(btnSave);
		
		JButton btnNewButton = new JButton("Exit");
		btnNewButton.setForeground(Color.RED);
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.exit(0);
			}
		});
		btnNewButton.setFont(new Font("Times New Roman", Font.PLAIN, 14));
		btnNewButton.setBounds(339, 426, 89, 23);
		frame.getContentPane().add(btnNewButton);
		
		JButton btnBack = new JButton("Back");
		btnBack.setForeground(Color.RED);
		btnBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				View_Request_Cat.view();
				frame.setVisible(false);
			}
		});
		btnBack.setFont(new Font("Times New Roman", Font.PLAIN, 14));
		btnBack.setBounds(187, 426, 89, 23);
		frame.getContentPane().add(btnBack);
		
		JCheckBox chckbxNewCheckBox_1 = new JCheckBox("Mother/Father");
		chckbxNewCheckBox_1.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		chckbxNewCheckBox_1.setBounds(128, 341, 97, 23);
		frame.getContentPane().add(chckbxNewCheckBox_1);
		
		JCheckBox chckbxSisterbrother = new JCheckBox("Sister/Brother");
		chckbxSisterbrother.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		chckbxSisterbrother.setBounds(342, 341, 97, 23);
		frame.getContentPane().add(chckbxSisterbrother);
		
		JCheckBox chckbxSondaughter = new JCheckBox("Son/Daughter");
		chckbxSondaughter.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		chckbxSondaughter.setBounds(232, 341, 97, 23);
		frame.getContentPane().add(chckbxSondaughter);
		
		JCheckBox chckbxHusbandwife = new JCheckBox("Husband/Wife");
		chckbxHusbandwife.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		chckbxHusbandwife.setBounds(128, 382, 97, 23);
		frame.getContentPane().add(chckbxHusbandwife);
		
		JCheckBox chckbxFriend = new JCheckBox("Friend");
		chckbxFriend.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		chckbxFriend.setBounds(232, 382, 97, 23);
		frame.getContentPane().add(chckbxFriend);
		
		JCheckBox chckbxOther = new JCheckBox("Other");
		chckbxOther.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		chckbxOther.setBounds(342, 382, 97, 23);
		frame.getContentPane().add(chckbxOther);
		
		JLabel lblSn = new JLabel("S/N :");
		lblSn.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		lblSn.setBounds(10, 61, 32, 14);
		frame.getContentPane().add(lblSn);
		
		JSpinner spinner_2 = new JSpinner();
		spinner_2.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		spinner_2.setModel(new SpinnerNumberModel(new Integer(1), new Integer(1), null, new Integer(1)));
		spinner_2.setBounds(52, 58, 42, 20);
		frame.getContentPane().add(spinner_2);
	}

}
