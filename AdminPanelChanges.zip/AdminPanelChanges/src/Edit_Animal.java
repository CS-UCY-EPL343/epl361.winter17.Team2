import java.awt.EventQueue;

import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;

import javax.swing.SwingConstants;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.JSpinner;
import javax.swing.JTextField;
import javax.swing.SpinnerNumberModel;
import java.awt.Color;

public class Edit_Animal {

	private JFrame frame;
	private JTextField textField;
	private JTextField textField_1;
	private final JFileChooser openFileChooser;
	private JTextField textField_2;
	private JTextField textField_3;
	private JTextField textField_4;
	private JTextField textField_5;
	private JTextField textField_6;

	/**
	 * Launch the application.
	 */
	public static void EditAnimal() {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Edit_Animal window = new Edit_Animal();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Edit_Animal() {
		initialize();
		openFileChooser = new JFileChooser();
		openFileChooser.setCurrentDirectory(new File ("C:\\temp"));
		openFileChooser.setFileFilter(new FileNameExtensionFilter("PNG images", "png"));
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 482, 450);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblEditupdateTable = new JLabel("Edit/Update a Table's Record");
		lblEditupdateTable.setForeground(Color.RED);
		lblEditupdateTable.setHorizontalAlignment(SwingConstants.CENTER);
		lblEditupdateTable.setFont(new Font("Times New Roman", Font.PLAIN, 20));
		lblEditupdateTable.setBounds(10, 11, 446, 24);
		frame.getContentPane().add(lblEditupdateTable);
		
		JLabel lblSn = new JLabel("S/N : ");
		lblSn.setForeground(Color.BLACK);
		lblSn.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		lblSn.setBounds(20, 51, 27, 14);
		frame.getContentPane().add(lblSn);
		
		JSpinner spinner = new JSpinner();
		spinner.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		spinner.setModel(new SpinnerNumberModel(new Integer(1), new Integer(1), null, new Integer(1)));
		spinner.setBounds(57, 48, 40, 20);
		frame.getContentPane().add(spinner);
		
		JLabel lblAnimalsNumber = new JLabel("Animal's Number:");
		lblAnimalsNumber.setForeground(Color.BLACK);
		lblAnimalsNumber.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		lblAnimalsNumber.setBounds(107, 46, 89, 24);
		frame.getContentPane().add(lblAnimalsNumber);
		
		textField = new JTextField();
		textField.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		textField.setBounds(202, 48, 86, 20);
		frame.getContentPane().add(textField);
		textField.setColumns(10);
		
		JLabel lblNewLabel = new JLabel("Animal's Age");
		lblNewLabel.setForeground(Color.BLACK);
		lblNewLabel.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		lblNewLabel.setBounds(298, 48, 86, 20);
		frame.getContentPane().add(lblNewLabel);
		
		JSpinner spinner1 = new JSpinner();
		spinner1.setModel(new SpinnerNumberModel(new Short((short) 1), new Short((short) 1), new Short((short) 15), new Short((short) 1)));
		spinner1.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		spinner1.setBounds(394, 48, 40, 20);
		frame.getContentPane().add(spinner1);
		
		JLabel lblAnimalType = new JLabel("Animal Type:");
		lblAnimalType.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		lblAnimalType.setBounds(20, 92, 86, 24);
		frame.getContentPane().add(lblAnimalType);
		
		JComboBox comboBox = new JComboBox();
		comboBox.setModel(new DefaultComboBoxModel(new String[] {"Please Select...", "Bird", "Dog", "Cat", "Other"}));
		comboBox.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		comboBox.setBounds(116, 94, 97, 20);
		frame.getContentPane().add(comboBox);
		
		JLabel lblNewLabel_1 = new JLabel("Picture:");
		lblNewLabel_1.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		lblNewLabel_1.setBounds(20, 327, 47, 19);
		frame.getContentPane().add(lblNewLabel_1);
		
		textField_1 = new JTextField();
		textField_1.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		textField_1.setBounds(77, 324, 261, 24);
		frame.getContentPane().add(textField_1);
		textField_1.setColumns(10);
		
		JButton btnNewButton = new JButton("Browse");
		btnNewButton.setForeground(Color.RED);
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JFileChooser file = new JFileChooser();
				file.setCurrentDirectory(new File(System.getProperty("user.home")));
				FileNameExtensionFilter filter = new FileNameExtensionFilter("*.Images","png","gif","jpg");
				file.addChoosableFileFilter(filter);
				int result = file.showSaveDialog(null);
				if(result == JFileChooser.APPROVE_OPTION){
					File selectedFile=file.getSelectedFile();
					String path = selectedFile.getAbsolutePath();
					textField_1.setText(path);
				}
				else if(result == JFileChooser.CANCEL_OPTION){
					System.out.println("No File Selected");
				}
			}
		});
		btnNewButton.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		btnNewButton.setBounds(348, 324, 86, 24);
		frame.getContentPane().add(btnNewButton);
		
		JLabel lblDateOfAdoption = new JLabel("Date of Adoption:");
		lblDateOfAdoption.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		lblDateOfAdoption.setBounds(20, 140, 97, 20);
		frame.getContentPane().add(lblDateOfAdoption);
		
		textField_2 = new JTextField();
		textField_2.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		textField_2.setBounds(116, 140, 97, 20);
		frame.getContentPane().add(textField_2);
		textField_2.setColumns(10);
		
		JLabel lblMicrochip = new JLabel("Microchip:");
		lblMicrochip.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		lblMicrochip.setBounds(241, 97, 86, 19);
		frame.getContentPane().add(lblMicrochip);
		
		JComboBox comboBox_1 = new JComboBox();
		comboBox_1.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		comboBox_1.setModel(new DefaultComboBoxModel(new String[] {"Please Select...", "YES", "NO"}));
		comboBox_1.setBounds(328, 93, 106, 22);
		frame.getContentPane().add(comboBox_1);
		
		JLabel lblAdoptersName = new JLabel("Adopter's Name:");
		lblAdoptersName.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		lblAdoptersName.setBounds(241, 143, 86, 14);
		frame.getContentPane().add(lblAdoptersName);
		
		textField_3 = new JTextField();
		textField_3.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		textField_3.setBounds(328, 140, 106, 20);
		frame.getContentPane().add(textField_3);
		textField_3.setColumns(10);
		
		JLabel lblAdoptersPhone = new JLabel("Adopter's Phone:");
		lblAdoptersPhone.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		lblAdoptersPhone.setBounds(20, 193, 86, 14);
		frame.getContentPane().add(lblAdoptersPhone);
		
		textField_4 = new JTextField();
		textField_4.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		textField_4.setBounds(116, 190, 97, 20);
		frame.getContentPane().add(textField_4);
		textField_4.setColumns(10);
		
		JLabel lblAdoptersEmail = new JLabel("Adopter's Email:");
		lblAdoptersEmail.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		lblAdoptersEmail.setBounds(241, 193, 86, 14);
		frame.getContentPane().add(lblAdoptersEmail);
		
		textField_5 = new JTextField();
		textField_5.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		textField_5.setColumns(10);
		textField_5.setBounds(328, 190, 106, 20);
		frame.getContentPane().add(textField_5);
		
		JLabel lblComments = new JLabel("Comments:");
		lblComments.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		lblComments.setBounds(21, 235, 85, 20);
		frame.getContentPane().add(lblComments);
		
		textField_6 = new JTextField();
		textField_6.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		textField_6.setBounds(20, 266, 414, 42);
		frame.getContentPane().add(textField_6);
		textField_6.setColumns(10);
		
		JButton btnExit = new JButton("Exit");
		btnExit.setForeground(Color.RED);
		btnExit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.exit(0);
			}
		});
		btnExit.setFont(new Font("Times New Roman", Font.PLAIN, 14));
		btnExit.setBounds(345, 378, 89, 23);
		frame.getContentPane().add(btnExit);
		
		JButton btnSave = new JButton("Save");
		btnSave.setForeground(Color.RED);
		btnSave.setFont(new Font("Times New Roman", Font.PLAIN, 14));
		btnSave.setBounds(28, 379, 89, 23);
		frame.getContentPane().add(btnSave);
		
		JButton btnBack = new JButton("Back");
		btnBack.setForeground(Color.RED);
		btnBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				View_Animals_Table.view();;
				frame.setVisible(false);
			}
		});
		btnBack.setFont(new Font("Times New Roman", Font.PLAIN, 14));
		btnBack.setBounds(190, 379, 89, 23);
		frame.getContentPane().add(btnBack);
	}
}
