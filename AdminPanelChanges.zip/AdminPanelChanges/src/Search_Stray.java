import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JSpinner;
import javax.swing.JTextField;
import javax.swing.SpinnerNumberModel;
import javax.swing.SwingConstants;
import java.awt.Color;

public class Search_Stray {

	private JFrame frame;
	private JTextField textField;
	private JTextField textField_2;
	private JTextField textField_3;
	private JTextField textField_4;

	/**
	 * Launch the application.
	 */
	public static void SearchStray() {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Search_Stray window = new Search_Stray();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Search_Stray() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 224, 658);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblSearchData = new JLabel("Search Data");
		lblSearchData.setForeground(Color.RED);
		lblSearchData.setHorizontalAlignment(SwingConstants.CENTER);
		lblSearchData.setFont(new Font("Times New Roman", Font.PLAIN, 20));
		lblSearchData.setBounds(10, 11, 188, 24);
		frame.getContentPane().add(lblSearchData);
		
		JLabel lblAnimalNumber = new JLabel("Name:");
		lblAnimalNumber.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		lblAnimalNumber.setBounds(23, 64, 80, 14);
		frame.getContentPane().add(lblAnimalNumber);
		
		textField = new JTextField();
		textField.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		textField.setBounds(113, 61, 86, 20);
		frame.getContentPane().add(textField);
		textField.setColumns(10);
		
		JComboBox comboBox = new JComboBox();
		comboBox.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		comboBox.setModel(new DefaultComboBoxModel(new String[] {"...", "AND", "OR"}));
		comboBox.setBounds(79, 89, 54, 20);
		frame.getContentPane().add(comboBox);
		
		JLabel lblAnimalAge = new JLabel("Surname:");
		lblAnimalAge.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		lblAnimalAge.setBounds(35, 120, 68, 14);
		frame.getContentPane().add(lblAnimalAge);
		
		JSpinner spinner = new JSpinner();
		spinner.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		spinner.setModel(new SpinnerNumberModel(1, 1, 15, 1));
		spinner.setBounds(123, 118, 43, 20);
		frame.getContentPane().add(spinner);
		
		JComboBox comboBox_1 = new JComboBox();
		comboBox_1.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		comboBox_1.setModel(new DefaultComboBoxModel(new String[] {"...", "AND", "OR"}));
		comboBox_1.setBounds(79, 146, 54, 20);
		frame.getContentPane().add(comboBox_1);
		
		JLabel lblTypeOfAnimal = new JLabel("Type of Animal:");
		lblTypeOfAnimal.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		lblTypeOfAnimal.setBounds(10, 345, 92, 14);
		frame.getContentPane().add(lblTypeOfAnimal);
		
		JComboBox comboBox_2 = new JComboBox();
		comboBox_2.setModel(new DefaultComboBoxModel(new String[] {"...", "AND", "OR"}));
		comboBox_2.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		comboBox_2.setBounds(79, 202, 54, 20);
		frame.getContentPane().add(comboBox_2);
		
		JLabel lblDateOfAdoption = new JLabel("Location Found:");
		lblDateOfAdoption.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		lblDateOfAdoption.setBounds(10, 289, 92, 14);
		frame.getContentPane().add(lblDateOfAdoption);
		
		textField_2 = new JTextField();
		textField_2.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		textField_2.setColumns(10);
		textField_2.setBounds(113, 230, 86, 20);
		frame.getContentPane().add(textField_2);
		
		JComboBox comboBox_3 = new JComboBox();
		comboBox_3.setModel(new DefaultComboBoxModel(new String[] {"Select...", "Bird", "Dog", "Cat", "Other"}));
		comboBox_3.setBounds(112, 342, 86, 20);
		frame.getContentPane().add(comboBox_3);
		
		JComboBox comboBox_4 = new JComboBox();
		comboBox_4.setModel(new DefaultComboBoxModel(new String[] {"...", "AND", "OR"}));
		comboBox_4.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		comboBox_4.setBounds(79, 258, 54, 20);
		frame.getContentPane().add(comboBox_4);
		
		JLabel lblMicrochip = new JLabel("Microchip:");
		lblMicrochip.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		lblMicrochip.setBounds(35, 517, 68, 23);
		frame.getContentPane().add(lblMicrochip);
		
		JCheckBox chckbxNewCheckBox = new JCheckBox("");
		chckbxNewCheckBox.setBounds(123, 517, 32, 23);
		frame.getContentPane().add(chckbxNewCheckBox);
		
		JComboBox comboBox_5 = new JComboBox();
		comboBox_5.setModel(new DefaultComboBoxModel(new String[] {"...", "AND", "OR"}));
		comboBox_5.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		comboBox_5.setBounds(79, 314, 54, 20);
		frame.getContentPane().add(comboBox_5);
		
		JLabel lblAdoptersName = new JLabel("Animal's Gender:");
		lblAdoptersName.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		lblAdoptersName.setBounds(10, 408, 93, 14);
		frame.getContentPane().add(lblAdoptersName);
		
		JComboBox comboBox_6 = new JComboBox();
		comboBox_6.setModel(new DefaultComboBoxModel(new String[] {"...", "AND", "OR"}));
		comboBox_6.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		comboBox_6.setBounds(79, 377, 54, 20);
		frame.getContentPane().add(comboBox_6);
		
		JLabel lblAdoptersPhone = new JLabel("Phone Number:");
		lblAdoptersPhone.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		lblAdoptersPhone.setBounds(10, 177, 93, 14);
		frame.getContentPane().add(lblAdoptersPhone);
		
		textField_3 = new JTextField();
		textField_3.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		textField_3.setColumns(10);
		textField_3.setBounds(112, 171, 86, 20);
		frame.getContentPane().add(textField_3);
		
		JComboBox comboBox_7 = new JComboBox();
		comboBox_7.setModel(new DefaultComboBoxModel(new String[] {"...", "AND", "OR"}));
		comboBox_7.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		comboBox_7.setBounds(79, 439, 54, 20);
		frame.getContentPane().add(comboBox_7);
		
		JLabel lblAdoptersEmail = new JLabel("Adopter's Email:");
		lblAdoptersEmail.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		lblAdoptersEmail.setBounds(10, 233, 93, 14);
		frame.getContentPane().add(lblAdoptersEmail);
		
		textField_4 = new JTextField();
		textField_4.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		textField_4.setColumns(10);
		textField_4.setBounds(112, 286, 86, 20);
		frame.getContentPane().add(textField_4);
		
		JButton btnSearch = new JButton("Search");
		btnSearch.setForeground(Color.RED);
		btnSearch.setFont(new Font("Times New Roman", Font.PLAIN, 14));
		btnSearch.setBounds(10, 551, 89, 23);
		frame.getContentPane().add(btnSearch);
		
		JButton btnBack = new JButton("Back");
		btnBack.setForeground(Color.RED);
		btnBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				View_Animals_Table.view();
				frame.setVisible(false);
			}
		});
		btnBack.setFont(new Font("Times New Roman", Font.PLAIN, 14));
		btnBack.setBounds(109, 551, 89, 23);
		frame.getContentPane().add(btnBack);
		
		JButton btnExit = new JButton("Exit");
		btnExit.setForeground(Color.RED);
		btnExit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.exit(0);
			}
		});
		btnExit.setFont(new Font("Times New Roman", Font.PLAIN, 14));
		btnExit.setBounds(63, 585, 80, 23);
		frame.getContentPane().add(btnExit);
		
		JComboBox comboBox_8 = new JComboBox();
		comboBox_8.setModel(new DefaultComboBoxModel(new String[] {"Select...", "Male", "Female", "Don't Know"}));
		comboBox_8.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		comboBox_8.setBounds(113, 405, 85, 20);
		frame.getContentPane().add(comboBox_8);
		
		JLabel lblEstimatedAnimalAge = new JLabel("Estimated Animal Age:");
		lblEstimatedAnimalAge.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		lblEstimatedAnimalAge.setBounds(10, 473, 123, 14);
		frame.getContentPane().add(lblEstimatedAnimalAge);
		
		JSpinner spinner_1 = new JSpinner();
		spinner_1.setModel(new SpinnerNumberModel(1, 1, 15, 1));
		spinner_1.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		spinner_1.setBounds(155, 471, 43, 20);
		frame.getContentPane().add(spinner_1);
		
		JComboBox comboBox_9 = new JComboBox();
		comboBox_9.setModel(new DefaultComboBoxModel(new String[] {"...", "AND", "OR"}));
		comboBox_9.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		comboBox_9.setBounds(79, 490, 54, 20);
		frame.getContentPane().add(comboBox_9);
	}

}
