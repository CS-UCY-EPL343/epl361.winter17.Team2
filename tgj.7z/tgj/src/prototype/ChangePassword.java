package prototype;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.BorderLayout;
import javax.swing.JLabel;
import java.awt.Color;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.JButton;
import javax.swing.ImageIcon;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class ChangePassword {

	private JFrame frame;
	private JTextField textField;
	private JPasswordField passwordField;
	private JPasswordField passwordField_1;

	/**
	 * Launch the application.
	 */
	public static void ChangePass() {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ChangePassword window = new ChangePassword();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public ChangePassword() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 512, 358);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		JPanel panel = new JPanel();
		panel.setBackground(Color.WHITE);
		frame.getContentPane().add(panel, BorderLayout.CENTER);
		panel.setLayout(null);
		
		JLabel lblUsername = new JLabel("Username :");
		lblUsername.setFont(new Font("Times New Roman", Font.BOLD, 14));
		lblUsername.setForeground(Color.WHITE);
		lblUsername.setBounds(102, 45, 99, 28);
		panel.add(lblUsername);
		
		JLabel lblPassword = new JLabel("Password :");
		lblPassword.setForeground(Color.WHITE);
		lblPassword.setFont(new Font("Times New Roman", Font.BOLD, 14));
		lblPassword.setBounds(102, 102, 73, 14);
		panel.add(lblPassword);
		
		JLabel lblNewPassword = new JLabel("New Password :");
		lblNewPassword.setFont(new Font("Times New Roman", Font.BOLD, 14));
		lblNewPassword.setForeground(Color.WHITE);
		lblNewPassword.setBounds(102, 143, 99, 14);
		panel.add(lblNewPassword);
		
		textField = new JTextField();
		textField.setBounds(260, 50, 111, 20);
		panel.add(textField);
		textField.setColumns(10);
		
		passwordField = new JPasswordField();
		passwordField.setBounds(260, 100, 111, 20);
		panel.add(passwordField);
		
		passwordField_1 = new JPasswordField();
		passwordField_1.setBounds(260, 141, 111, 20);
		panel.add(passwordField_1);
		
		JButton btnNewButton = new JButton("Confirm");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				general g=new general();
				g.GeneralSite();
				frame.setVisible(false);
			}
		});
		btnNewButton.setFont(new Font("Tempus Sans ITC", Font.BOLD, 14));
		btnNewButton.setForeground(Color.RED);
		btnNewButton.setBounds(192, 214, 111, 28);
		panel.add(btnNewButton);
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setBackground(Color.BLACK);
		lblNewLabel.setForeground(Color.RED);
		lblNewLabel.setIcon(new ImageIcon(ChangePassword.class.getResource("/prototype/right.jpg")));
		lblNewLabel.setBounds(0, 11, 505, 310);
		panel.add(lblNewLabel);
		
		JButton btnGoBack = new JButton("Go Back");
		btnGoBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ManageAccount manage= new ManageAccount();
				String[] args = null;
				ManageAccount.main(args);
				frame.setVisible(false);
			}
		});
		btnGoBack.setFont(new Font("Tempus Sans ITC", Font.BOLD, 11));
		btnGoBack.setBackground(Color.BLACK);
		btnGoBack.setForeground(Color.RED);
		btnGoBack.setBounds(0, 21, 89, 23);
		panel.add(btnGoBack);
	}
}
