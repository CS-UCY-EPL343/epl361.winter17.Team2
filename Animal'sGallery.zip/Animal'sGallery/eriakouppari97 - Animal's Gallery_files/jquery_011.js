/**
 *
 * MozWysiwyg
 * Represents the Mozello WYSIWYG component.
 * Copyright © Mozello SIA, All Rights Reserved
 *
 */

/* Initialization. */

$(document).ready(function () {

    if (isMobileDevice()) {

        var isWysCurrentlyScrolling = false;

        // create exit button
        var btn_blur = $('<div>');
        btn_blur
            .attr('id', 'mz_blur');

        // create WYS toolbar container
        var tb_container = $('<div>');
        tb_container
            .attr('id', 'mz_sidebar')
            .addClass('mz_editable')
            .append(btn_blur);

        // append container to body
        $('body').append(tb_container);

    }

});

(function (window, $) {

    /* Plugin Constructor */

    var MozWysiwyg = function (element, options) {
        this.element = $(element);
        this.editor = $(element).find('div.moze-wysiwyg-editor');
        this.options = options;
    };

    var MozWysiwygGlobal = {
        isResizeModeOn: false,
        baseOfResizeMode: null,
        imageOfResizeMode: null
    };

    /* Plugin Prototype */

    MozWysiwyg.prototype = {
        defaults: {
            toolbar: {
                topStrip: {
                    heading: {
                        tooltip: MWY_HEADING_TOOLTIP,
                        type: 'combo',
                        role: 'editor blog',
                        caption: MWY_HEADING_CAPTION,
                        subitems: {
                            paragraph: {caption: MWY_FONT_SUBITEM_PARAGRAPH, theclass: '', htmltag: 'p'},
                            megatitle: {caption: MWY_FONT_SUBITEM_MEGATITLE, theclass: 'moze-megatitle', htmltag: 'h1'},
                            topheader: {caption: MWY_FONT_SUBITEM_TOPHEADER, theclass: '', htmltag: 'h1'},
                            header: {caption: MWY_FONT_SUBITEM_HEADER, theclass: '', htmltag: 'h2'},
                            subtitle: {caption: MWY_FONT_SUBITEM_SUBTITLE, theclass: '', htmltag: 'h3'}
                        }

                    },
                    font: {
                        tooltip: MWY_FONT_TOOLTIP,
                        type: 'combo',
                        role: 'editor blog',
                        caption: MWY_FONT_CAPTION,
                        subitems: {
                            normal: {caption: MWY_FONT_SUBITEM_UNFORMAT, theclass: ''},
                            important: {caption: MWY_FONT_SUBITEM_IMPORTANT, theclass: 'moze-important'},
                            secondary: {caption: MWY_FONT_SUBITEM_SECONDARY, theclass: 'moze-secondary'},
                            blockquote: {caption: MWY_FONT_SUBITEM_BLOCKQUOTE, theclass: 'moze-blockquote'},
                            code: {caption: MWY_FONT_SUBITEM_CODE, theclass: 'moze-code'},
                            strike: {caption: MWY_FONT_SUBITEM_STRIKE, theclass: 'moze-strike'},
                        }

                    },
                    fontsize: {
                        tooltip: MWY_FONT_SIZE_TOOLTIP,
                        type: 'combo',
                        role: 'editor footer toptext blog overlay',
                        caption: MWY_FONT_SIZE_CAPTION,
                        subitems: {
                            tiny: {caption: MWY_FONT_SIZE_SUBITEM_TINY, theclass: 'moze-tiny'},
                            small: {caption: MWY_FONT_SIZE_SUBITEM_SMALL, theclass: 'moze-small'},
                            normal: {caption: MWY_FONT_SIZE_SUBITEM_NORMAL, theclass: 'moze-normal'},
                            large: {caption: MWY_FONT_SIZE_SUBITEM_LARGE, theclass: 'moze-large'},
                            huge: {caption: MWY_FONT_SIZE_SUBITEM_HUGE, theclass: 'moze-huge'},
                            gigantic: {caption: MWY_FONT_SIZE_SUBITEM_GIGANTIC, theclass: 'moze-gigantic'}
                        }
                    },
                    justifyleft: {
                        tooltip: MWY_JUSTIFY_LEFT_TOOLTIP,
                        type: 'button',
                        role: 'editor footer toptext blog'
                    },
                    justifycenter: {
                        tooltip: MWY_JUSTIFY_CENTER_TOOLTIP,
                        type: 'button',
                        role: 'editor footer toptext blog'
                    },
                    justifyright: {
                        tooltip: MWY_JUSTIFY_RIGHT_TOOLTIP,
                        type: 'button',
                        role: 'editor footer toptext blog'
                    },
                    justifyfull: {
                        tooltip: MWY_JUSTIFY_FULL_TOOLTIP,
                        type: 'button',
                        role: 'editor footer toptext blog'
                    },
                    undo: {
                        tooltip: MWY_UNDO_TOOLTIP,
                        type: 'button',
                        role: 'editor blog'
                    },
                    redo: {
                        tooltip: MWY_REDO_TOOLTIP,
                        type: 'button',
                        role: 'editor blog'
                    }

                },
                bottomStrip: {
                    bold: {
                        tooltip: MWY_BOLD_TOOLTIP,
                        type: 'button',
                        role: 'editor footer toptext blog overlay'
                    },
                    italic: {
                        tooltip: MWY_ITALIC_TOOLTIP,
                        type: 'button',
                        role: 'editor footer toptext blog overlay'
                    },
                    underline: {
                        tooltip: MWY_UNDERLINE_TOOLTIP,
                        type: 'button',
                        role: 'editor footer toptext blog overlay'
                    },
                    splitmerge: {
                        tooltip: MWY_SPLIT_TOOLTIP,
                        tooltipAlternate: MWY_MERGE_TOOLTIP,
                        type: 'button',
                        role: 'blog'
                    },
                    bullets: {
                        tooltip: MWY_BULLETS_TOOLTIP,
                        type: 'button',
                        role: 'editor blog'
                    },
                    numbering: {
                        tooltip: MWY_NUMBERING_TOOLTIP,
                        type: 'button',
                        role: 'editor blog'
                    },
                    link: {
                        tooltip: MWY_LINK_TOOLTIP,
                        type: 'button',
                        role: 'editor footer toptext blog'
                    },
                    image: {
                        tooltip: MWY_IMAGE_TOOLTIP,
                        type: 'button',
                        role: 'editor blog title'
                    },
                    insert: {
                        tooltip: MWY_TABLE_TOOLTIP,
                        type: 'button',
                        role: 'editor blog',
                        subitems: {
                            button: {caption: MWY_BUTTON_TOOLTIP, role: 'editor blog'},
                            video: {caption: MWY_VIDEO_TOOLTIP, role: 'editor blog'},
                            maps: {caption: MWY_MAPS_TOOLTIP, role: 'editor blog'},
                            file: {caption: MWY_FILE_TOOLTIP, role: 'editor blog'},
                            symbol: {caption: MWY_SYMBOL_TOOLTIP, role: 'editor blog'},
                            inscode: {caption: MWY_CODE_TOOLTIP, role: 'editor blog'},
                        }
                    },
                    table: {
                        tooltip: MWY_TABLE_TOOLTIP,
                        type: 'button',
                        role: 'editor blog',
                        subitems: {
                            createtable: {caption: MWY_TABLE_SUBITEM_CREATE, role: 'editor blog'},
                            addcolumnbefore: {caption: MWY_TABLE_SUBITEM_COLUMN_BEFORE, role: 'editor blog'},
                            addcolumnafter: {caption: MWY_TABLE_SUBITEM_COLUMN_AFTER, role: 'editor blog'},
                            deletecolumn: {caption: MWY_TABLE_SUBITEM_DELETE_COLUMN, role: 'editor blog'},
                            addrowbefore: {caption: MWY_TABLE_SUBITEM_ROW_BEFORE, role: 'editor blog'},
                            addrowafter: {caption: MWY_TABLE_SUBITEM_ROW_AFTER, role: 'editor blog'},
                            deleterow: {caption: MWY_TABLE_SUBITEM_DELETE_ROW, role: 'editor blog'},
                            togglerowstyle: {caption: MWY_TABLE_SUBITEM_HEADER, role: 'editor blog'}
                        }
                    },
                    fontcolor: {
                        tooltip: MWY_FONT_COLOR_TOOLTIP,
                        type: 'button',
                        role: 'editor blog'
                    },
                    clearformatting: {
                        tooltip: MWY_CLEARFORMATTING_TOOLTIP,
                        type: 'button',
                        role: 'editor footer toptext blog title overlay overlay-title'
                    },
                    html: {
                        tooltip: MWY_HTML_TOOLTIP,
                        type: 'button',
                        role: 'editor footer toptext blog title overlay overlay-title'
                    }
                }
            },
            imageToolbar: {
                topStrip: {
                    imgjustifyleft: {
                        tooltip: MWY_IMG_JUSTIFY_LEFT_TOOLTIP,
                        type: 'button',
                        role: 'editor blog title'
                    },
                    imgjustifycenter: {
                        tooltip: MWY_IMG_JUSTIFY_CENTER_TOOLTIP,
                        type: 'button',
                        role: 'editor blog title'
                    },
                    imgjustifyright: {
                        tooltip: MWY_IMG_JUSTIFY_RIGHT_TOOLTIP,
                        type: 'button',
                        role: 'editor blog title'
                    },
                    imgjustifyinline: {
                        tooltip: MWY_IMG_JUSTIFY_FULL_TOOLTIP,
                        type: 'button',
                        role: 'editor blog title'
                    },
                    imgresize: {
                        tooltip: MWY_IMG_RESIZE,
                        type: 'button',
                        role: 'editor blog title'
                    },
                    imgproperties: {
                        tooltip: MWY_IMG_PROPERTIES,
                        type: 'button',
                        role: 'editor blog title'
                    },
                    imgdelete: {
                        tooltip: MWY_IMG_DELETE,
                        type: 'button',
                        role: 'editor blog title'
                    }
                }
            },
            iframeToolbar: {
                topStrip: {
                    iframeresize: {
                        tooltip: MWY_IFRAME_RESIZE,
                        type: 'button',
                        role: 'editor blog'
                    },
                    maps: {
                        tooltip: MWY_MAPS_EDIT_TOOLTIP,
                        type: 'button',
                        role: 'editor blog'
                    },
                    iframedelete: {
                        tooltip: MWY_IFRAME_DELETE,
                        type: 'button',
                        role: 'editor blog'
                    }
                }
            },
            linkToolbar: {
                topStrip: {
                    link: {
                        tooltip: MWY_LINK_TOOLTIP,
                        type: 'button',
                        role: 'editor footer toptext blog'
                    },
                    linkremove: {
                        tooltip: MWY_LINK_REMOVE_TOOLTIP,
                        type: 'button',
                        role: 'editor footer toptext blog'
                    },
                    buttonspace: {
                        tooltip: MWY_LINK_SPACING_TOOLTIP,
                        type: 'button',
                        role: 'editor footer toptext blog'
                    },
                    bold: {
                        tooltip: MWY_BOLD_TOOLTIP,
                        type: 'button',
                        role: 'editor footer toptext blog overlay'
                    },
                    italic: {
                        tooltip: MWY_ITALIC_TOOLTIP,
                        type: 'button',
                        role: 'editor footer toptext blog overlay'
                    },
                    underline: {
                        tooltip: MWY_UNDERLINE_TOOLTIP,
                        type: 'button',
                        role: 'editor footer toptext blog overlay'
                    },
                    font: {
                        tooltip: MWY_FONT_TOOLTIP,
                        type: 'combo',
                        role: 'editor blog',
                        caption: MWY_FONT_CAPTION,
                        subitems: {
                            buttonremove: {caption: MWY_FONT_SUBITEM_UNFORMAT, theclass: ''},
                            buttonsmall: {caption: MWY_FONT_SUBITEM_BUTTON, theclass: 'moze-button'},
                            buttonlarge: {caption: MWY_FONT_SUBITEM_BUTTON_LARGE, theclass: 'moze-button-large'}
                        }

                    },
                    fontsize: {
                        tooltip: MWY_FONT_SIZE_TOOLTIP,
                        type: 'combo',
                        role: 'editor footer toptext blog overlay',
                        caption: MWY_FONT_SIZE_CAPTION,
                        subitems: {
                            tiny: {caption: MWY_FONT_SIZE_SUBITEM_TINY, theclass: 'moze-tiny'},
                            small: {caption: MWY_FONT_SIZE_SUBITEM_SMALL, theclass: 'moze-small'},
                            normal: {caption: MWY_FONT_SIZE_SUBITEM_NORMAL, theclass: 'moze-normal'},
                            large: {caption: MWY_FONT_SIZE_SUBITEM_LARGE, theclass: 'moze-large'},
                            huge: {caption: MWY_FONT_SIZE_SUBITEM_HUGE, theclass: 'moze-huge'},
                            gigantic: {caption: MWY_FONT_SIZE_SUBITEM_GIGANTIC, theclass: 'moze-gigantic'}
                        }
                    }
                }
            },

            autosaveTimer: 5000,
            autosaveEnabled: true,
            autosaveCallback: null,
            textSyncCallback: null,
            role: 'editor',
            wantsParagraphs: true,
            saveButton: null,
            toolbarReposition: true,
            toolbarRepositionHalign: 'left',
            toolbarAnchor: null,
            toolbarAnchorHalign: 'left',
            toolbarEnabled: true
        },

        init: function ()
        {
            var base = this;

            // Disables editing for controls that do not have the editor.

            if (base.editor.length == 0) {
                return;
            }

            // Disables editing the Premium component.

            if (base.element.data('premium') == 1)
            {
                base.editor
                    .removeAttr('contentEditable')
                    .css('cursor', 'pointer')
                    .on('click', function (e) {
                        if (noClicks()) {
                            e.stopPropagation();
                            return false;
                        }
                        $.smartModalWindow({
                            innerHeight: 580,
                            href: '/m/premium/',
                            innerWidth: 1100
                        });
                    });

                return this;
            }

            // Initializes configuration.

            base.config = $.extend({}, base.defaults, base.options);
            base.config.role = (typeof base.element.data('role') !== 'undefined') ? base.element.data('role') : 'editor';
            base.config.toolbarEnabled = (base.element.data('toolbar') != 0);
            base.config.wantsParagraphs = (base.config.role == 'editor' || base.config.role == 'blog');

            base.lastChange = $.now();

            base.savedSelection = null;
            base.undoStack = new Array();
            base.redoStack = new Array();
            base.lastUndoTime = new Date().getTime();

            base.toolbar = null;
            base.imageToolbar = null;
            base.iframeToolbar = null;
            base.linkToolbar = null;

            base.imageSelected = null;
            base.iframeSelected = null;
            base.linkSelected = null;

            base.isImageResizingModeOn = false;
            base.imageResizingOldClass = null;

            base.savedRange = null; // selection saver

            base.isModified = true;

            // Prepares editor focus in/out events.

            if (base.config.toolbarEnabled == true)
            {
                base.editor
                    .focusin(function () {
                        base.onFocusIn();
                    })
                    .focusout(function () {
                        base.onFocusOut();
                    });

                $(document).scroll(function () {
                    base.relocateToolbars();
                });
                $(window).resize(function () {
                    base.relocateToolbars();
                });

                $(document).on('touchstart', function (e) {
                    var target = $(e.target);
                    // touch inside editor during customization
                    if (target.parents('div.mz_wysiwyg').length && $('#mz_customizer').is(':visible')) {
                        base.editor.blur();
                        return false;
                    }
                    // ignore during resize mode
                    if (MozWysiwygGlobal.isResizeModeOn == true) {
                        return false;
                    }
                });

                $(document).on('touchend', function (e) {
                    var target = $(e.target);
                    // loose focus on touch outside editor
                    if (base.editor.is(":focus") && !isSwipeTakingPlace &&
                        !(target.parents('div.mz_wysiwyg').length ||
                        target.parents('div#mz_sidebar').length ||
                        target.parents('div#modal').length ||
                        target.is('div#modal-overlay') ||
                        target.is('div#mz_sidebar'))) {
                        // touched outside wysiwyg area, loose focus
                        base.toolbar.trigger('mouseleave');
                        base.editor.blur();
                        return false; // do nothing else
                    }
                });

                $(document).on('selectionchange', function (e) {
                    if (base.editor.is(":focus")) {
                        base.updateToolbarButtons();
                    }

                });

            }
            else
            {
                base.editor
                    .focusout(function () {
                        base.autosave();
                    });
            }

            // Prepares browser specific HTML & observes images and iframes.

            base.prepareBrowserSpecificHtml();
            base.observeObjects();

            // Prepares key press events.

            base.editor.keydown(function (e) {

                // ENTER
                if (e.which == 13) {
                    base.addUndoPoint(); // save undo
                } else if (e.which == 46 || e.which == 8) { // DELETE, BACKSPACE
                    base.addUndoPoint(1000);
                } else {
                    base.addUndoPoint(3000);
                }

                // button processing
                if (base.linkSelected != null) {
                    // if link still present
                    if (base.linkSelected.closest('body').length > 0) {
                        if (e.which == 13) {
                            var link = base.linkSelected;
                            var linkText = link.text().toString();
                            var selection = rangy.getSelection();
                            if (selection.rangeCount > 0 && selection.isCollapsed) {
                                var ranges = selection.getAllRanges();
                                var range = ranges[0];
                                var characterRange = range.toCharacterRange(link[0]);
                                if ((linkText.charAt(0) == '\u200B' && characterRange.start == 1) || (characterRange.start == 0)) {
                                    link.before('<br>');
                                    selection.selectAllChildren(link[0]);
                                    selection.collapseToStart();
                                    selection.move('character', -1);
                                    e.preventDefault();
                                    return false;
                                } else {
                                    // any other position
                                    link.after('<br>&nbsp;');
                                    selection.selectAllChildren(link[0]);
                                    selection.collapseToEnd();
                                    selection.move('character', 1);
                                    e.preventDefault();
                                    return false;
                                }
                            }
                        }
                    }
                }

                // Delete key was pressed, extra processing for tables
                if (e.which == 46) { // DEL
                    base.actionDeleteTableIfSelected();
                }

                // Ctrl + K
                if (e.ctrlKey && e.altKey == false && e.which == 75) {
                    base.toolbar.find('a.link').first().trigger('click'); // to respect roles, use button click trigger instead of direct call
                    e.preventDefault();
                    return false;
                }

                base.observeSplitState();
                return true;

            });

            base.editor.keyup(function (e) {

                if (base.linkSelected != null) {
                    // looks like link no more exists
                    if (base.linkSelected.closest('body').length == 0) {
                        base.linkSelected = null;
                        base.hideLinkToolbar();
                        base.showToolbar();
                    }
                }

                // arrow key processing
                if (e.which >= 37 && e.which <= 40) {
                    var selection = rangy.getSelection();
                    if (selection.rangeCount > 0 && selection.isCollapsed) {
                        var ranges = selection.getAllRanges();
                        var range = ranges[0];
                        if ($(range.startContainer).is('a')) {
                            base.linkSelected = $(range.startContainer).is('a');
                            base.onClickInsideSelectedLink();
                        } else if ($(range.startContainer).parents('a').length) {
                            base.linkSelected = $(range.startContainer).parents('a');
                            base.onClickInsideSelectedLink();
                        }
                    }
                }

                // Enter key was pressed, significant event to add undo block
                if (e.which == 13) { // ENTER

                    // do not allow table to be the first/last element (there is no way to put cursor after/before in such cases)
                    if (base.editor.children().first().is('table')) {
                        if (base.editor.contents().first().text().trim() == '') {
                            base.editor.prepend($('<br>'));
                        }
                    }
                    if (base.editor.children().last().is('table')) {
                        if (base.editor.contents().last().text().trim() == '') {
                            base.editor.append($('<br>'));
                        }
                    }

                    // replace div blocks with p tags
                    function findNearestBlockLevelParent(element) {
                        element = $(element);
                        while (element.length && element.css("display") != "block") {
                            element = element.parent();
                        }
                        // check if inside editor
                        if (element.parents('div.moze-wysiwyg-editor').length) {
                            return element;
                        } else {
                            return null;
                        }
                    }
                    function formatElement(element, tagName) {
                        newElement = $('<' + tagName + '>').append(element.clone().get(0).childNodes);
                        element.replaceWith(newElement);
                        return newElement;
                    }
                    if (base.config.wantsParagraphs) {
                        var selection = rangy.getSelection();
                        if (selection.rangeCount > 0) {
                            var ranges = selection.getAllRanges();
                            var range = ranges[0];
                            var element = findNearestBlockLevelParent(range.commonAncestorContainer);
                            // if the parent of current cursor position is a block level element and it is a div
                            if (element && range.collapsed) {
                                // replace any div with p
                                if ($(element).is('div')) {
                                    var div = $(element);
                                    var p = formatElement(div, 'p');
                                    selection.collapse(p[0], 0);
                                }
                            }
                        }
                    }

                }  // end Enter key processing

                // Sets up the Autosave.
                base.isModified = true;
                if ($.now() - base.lastChange > base.config.autosaveTimer) {
                    base.autosave();
                }

                // Updates toolbar
                base.updateToolbarButtons();

            });

            base.editor.on('mouseup mouseout touchend', function (e) {
                base.updateToolbarButtons();
            });

            base.editor.on('dragend', function () {
                base.isModified = true;
                base.autosave();
            });

            // paste processing - remove trash
            base.editor.get(0).onpaste = function (e) {
                base.addUndoPoint();
                // TODO: atrisināt align problēmu
                setTimeout(function () {
                    base.saveSelection();
                    base.cleanPastedContent();
                    base.restoreSelection();
                    base.isModified = true;
                    base.autosave();
                }, 100);
            };

            if (jQuery.hotkeys) {
                base.editor.bind('keypress', 'alt+ctrl+c', function () {
                    base.actionCopyright();
                });
            }

            // Autosaves when mouse leaves the editor.

            if (base.config.role == 'editor') {
                base.editor.mouseleave(function () {
                    base.autosave();
                });
            }

            // Initial autosave bug fix for blogs.

            if (base.config.role == 'blog' && base.config.textSyncCallback != null) {
                this.config.textSyncCallback(this.prepareHtmlForSave());
            }

            return this;
        },

        onFocusIn: function ()
        {
            var base = this;

            base.observeObjects();
            base.observeSplitState();
            // show toolbar only if image toolbar has not showed itself first
            if ((base.imageToolbar == null || !base.imageToolbar.is(':visible')) &&
                (base.iframeToolbar == null || !base.iframeToolbar.is(':visible')) &&
                (base.linkToolbar == null || !base.linkToolbar.is(':visible'))) {
                base.showToolbar();
            }
        },

        onFocusOut: function ()
        {
            this.hideToolbar();
            this.autosave();
        },

        onClickOutsideSelectedImage: function ()
        {
            var base = this;

            base.editor.on('mouseup touchend', function (e) {
                if (MozWysiwygGlobal.isResizeModeOn == false) {
                    var image = base.imageSelected;
                    var target = $(e.target);

                    if (image != null) {
                        if (image[0] != target[0]) {
                            if (target.prop('tagName').toLowerCase() == 'img') {
                                base.imageSelected = target;
                            }
                            else {
                                base.imageSelected = null;
                                base.hideImageToolbar();
                                base.showToolbar();
                            }
                        }
                    }
                }
            });

        },
        onClickOutsideSelectedIframe: function ()
        {
            var base = this;

            base.editor.on('mouseup touchend', function (e) {
                if (MozWysiwygGlobal.isResizeModeOn == false) {
                    var iframe = base.iframeSelected;
                    var target = $(e.target);

                    if (iframe != null) {
                        if (iframe[0] != target[0]) {
                            if (target.prop('tagName').toLowerCase() == 'div' && target.hasClass('moze-object')) {
                                base.iframeSelected = target;
                            }
                            else {
                                base.iframeSelected = null;
                                base.hideIframeToolbar();
                                base.showToolbar();
                            }
                        }
                    }
                }
            });
        },

        onClickOutsideSelectedLink: function ()
        {
            var base = this;

            base.editor.on('mouseup touchend', function (e) {
                var target = $(e.target);
                if (base.linkSelected != null) {
                    if (target.prop('tagName').toLowerCase() == 'a') {
                        base.linkSelected = target;
                        base.onClickInsideSelectedLink();
                    } else if (target.parents('a').length) {
                        base.linkSelected = target.parents('a');
                        base.onClickInsideSelectedLink();
                    } else {
                        // no link found
                        base.linkSelected = null;
                        base.hideLinkToolbar();
                        base.showToolbar();
                    }
                }

            });

        },

        onClickInsideSelectedLink: function ()
        {
            var base = this;
            var link = base.linkSelected;
            var a = link.get(0);
            var linkText = link.text().toString();
            var selection = rangy.getSelection();

            if (selection.rangeCount > 0) {
                var ranges = selection.getAllRanges();
                var range = ranges[0];

                var characterRange = range.toCharacterRange(a);
                var oldSelLength = characterRange.end - characterRange.start;
                var stringBefore = linkText.substr(0, characterRange.start);
                var stringSelection = linkText.substr(characterRange.start, (characterRange.end - characterRange.start));

                // coun any existing hidden markers to correctly calculate selection range offsets
                var hiddenMarkersBefore = (stringBefore.match(/[\u200B]/g) || []).length;
                var hiddenMarkersSelection = (stringSelection.match(/[\u200B]/g) || []).length;

                // save selection
                var savedSelection = rangy.getSelection().saveCharacterRanges(a);

                // this destroys dom selection and changes text length (adds/removes invisible markers), selection will have to be restored from saved character range
                link.html(base.appendHiddenMarkers(link.html()));

                // adjust selection range to account for missing / added invisible chars
                characterRange.start = characterRange.start - hiddenMarkersBefore + 1;
                characterRange.end = characterRange.start + oldSelLength - hiddenMarkersSelection;

                //console.log(characterRange.start + '/' + characterRange.end + '/' + link.text().length);

                // save selection object
                savedSelection[0].characterRange = characterRange;

                // restore selection
                selection.restoreCharacterRanges(a, savedSelection);

            }

            base.showLinkToolbar();

        },

        getComponentID: function ()
        {
            var cid = $(this.editor).parents('div.mz_component.mz_wysiwyg').first().data('cid');
            return (typeof cid !== 'undefined') ? cid : 0;
        },

        createToolbar: function (buttons)
        {
            var base = this;
            var toolbar = $('<div>');

            var createToolbarButton = function (index, item) {
                var button = $('<a>')
                    .attr('href', 'javascript:void(0);')
                    .attr('title', item.tooltip);

                button.addClass(index);

                if (typeof item.subitems !== 'undefined') {
                    // no action due to popup
                } else {
                    button.on('click touchend', function (e) {
                        if (noClicks()) {
                            e.stopPropagation();
                            return false;
                        }
                        base.action(index, null);
                        return false;
                    });
                }

                return button;
            };

            var createToolbarComboDropdown = function (index, item)
            {
                var dropdown = $('<ul>');
                var stag;

                $.each(item.subitems, function (subindex, subitem) {

                    // use special tag for some elements
                    var stag = '<span>';
                    if (subitem.htmltag != null) {
                        stag = '<' + subitem.htmltag + '>';
                    }

                    var inner = $(stag)
                        .html(subitem.caption)
                        .addClass(subitem.theclass)
                        .addClass('combo-element');

                    var button = $('<a>')
                        .attr('href', 'javascript:void(0);')
                        .addClass(subindex)
                        .on('click', function (e) {
                            $(this).parent().parent().hide();
                            base.action(index, subindex);
                            $(this).parents().parents('li').first().removeClass('focus');
                            e.stopPropagation(); // just to be safe
                            return true;
                        });

                    var container = $('<div>');

                    // note: need the empty span before element preview to make preveiw element
                    // non-first-child, as sometimes first-child elements differ from normal ones

                    dropdown.append($('<li>').append(container.append($('<span>')).append(inner)).append(button));

                });

                // top button
                var box = $('<a>')
                    .attr('href', 'javascript:void(0);')
                    .attr('title', item.tooltip)
                    .addClass(index)
                    .html(item.caption)
                    .add(dropdown);

                return box;
            };

            var createToolbarDropdown = function (subitems)
            {
                var dropdown = $('<ul>');

                $.each(subitems, function (index, subitem) {
                    if (subitem.role.search(base.config.role) > -1) {
                        var button = $('<a>')
                            .attr('href', 'javascript:void(0);')
                            .html(subitem.caption)
                            .addClass(index)
                            .on('click touchend', function (e) {
                                if (noClicks()) {
                                    e.stopPropagation();
                                    return false;
                                }
                                $(this).parent().parent().hide(); // hide submenu
                                base.action(index, null);
                                $(this).parents().parents('li').first().removeClass('focus');
                                e.stopPropagation();
                                return false;
                            });
                        dropdown.append($('<li>').append(button));
                    }
                });

                return dropdown;
            };

            var createToolbarStrip = function (items, fx)
            {
                var strip = $('<ul>').addClass('strip');

                $.each(items, function (index, item) {
                    if (item.role.search(base.config.role) > -1) {
                        if (item.type == 'button') {
                            if (typeof item.subitems !== 'undefined') {
                                strip.append($('<li>')
                                    .append(fx.button(index, item))
                                    .append(fx.dropdown(item.subitems))
                                    );
                            }
                            else {
                                strip.append($('<li>').append(fx.button(index, item)));
                            }
                        }
                        if (item.type == 'combo')
                        {
                            strip.append($('<li>')
                                .addClass('combo')
                                .append(fx.combo(index, item))
                            );
                        }
                    }
                });

                return strip;
            };

            // Builds the final toolbar.

            var fx = {
                button: createToolbarButton,
                combo: createToolbarComboDropdown,
                dropdown: createToolbarDropdown
            };

            toolbar
                .addClass('moze-wysiwyg-toolbar')
                .append($('<div>').addClass('handle'));

            if (typeof buttons.topStrip !== 'undefined') {
                toolbar.append(createToolbarStrip(buttons.topStrip, fx));
            }
            if (typeof buttons.bottomStrip !== 'undefined') {
                toolbar.append(createToolbarStrip(buttons.bottomStrip, fx));
            }

            // Submenu display logics.

            toolbar.find('li:not(.combo) > a ~ ul').parents('li')
                .on('touchend', function () {
                    $(this).children('ul').toggle();
                })
                .mouseenter(function () {
                    $(this).children('ul').show();
                })
                .mouseleave(function () {
                    $(this).children('ul').hide();
                });

            // save selection whenever toolbar is about to be touched
            toolbar.find('ul.strip > li > a').on('touchstart', function (e) {
                base.saveSelection();
            });

            toolbar.find('li.combo')
                .mouseleave(function () {
                    $(this).children('ul').hide();
                });

            // combo boxes use click instead of mouseover
            toolbar.find('li.combo > a')
                .on('click', function () {
                    // attach function to popup
                    var submenu = $(this).siblings('ul').first();
                    // closes submenu
                    function closeSubmenu() {
                        if (submenu.is(':visible')) {
                            submenu.hide();
                            base.editor.focus();
                            base.restoreSelection();
                        }
                    }
                    // show
                    if (!submenu.is(":visible")) {
                        // on mobiles selection causes bugs, so save and remove it temporarily
                        if ($('body').hasClass('touch-mode')) {
                            // make sure menu is closed during outside touch
                            $(document).one('touchend', closeSubmenu);
                            submenu.one('touchend', function (event) {
                                event.stopPropagation();
                            });
                        }
                        // show
                        submenu
                            .show()
                            .mouseleave(closeSubmenu);
                        // hide by clicking on top button
                    }
                    else {
                        submenu.hide();
                        base.restoreSelection();
                    }
                });

            return toolbar;
        },

        showMobileSidebar: function ()
        {
            if ($('body').hasClass('touch-mode')) {
                // first remove up bar
                $('#mz_topbar').hide();
                // adjust body
                $('body').animate({'margin-left': $('#mz_sidebar').outerWidth()});
                // adjust for designs that set relative positioning on body
                if ($('body').css('position') == 'relative') {
                    $('#mz_sidebar').css('left', -$('#mz_sidebar').outerWidth());
                }
                // then open sidebar
                $('#mz_sidebar').css('height', $(document).outerHeight()).show();
            }
        },

        canShowToolbar: function ()
        {
            if (!isMobileDevice()) {
                return true; // normal PC, show always
            }
            if ($('#mz_customizer').is(':visible')) {
                return false; // not during customizing
            }
            return (!isSmallMobileDevice()); // based on screen size, note, on some devices height is without keyboard
        },

        restoreFocusEvents: function() {
            var base = this;
            base.editor.off('focusin focusout');
            base.editor.focusin(function () {
                base.onFocusIn();
            });
            base.editor.focusout(function () {
                base.onFocusOut();
            });
            base.editor.removeClass('moze-select-border');
        },

        onToolbarEnter: function() {
            var base = this;
            base.editor.off('focusin focusout');
            base.editor.addClass('moze-select-border');
            // we need to give back focus events if we tap outside toolbar
            $(document).on('touchstart.restoreFocus', function (e) {
                var target = $(e.target);
                if (!target.parents('div.moze-wysiwyg-toolbar').length) {
                    base.restoreFocusEvents();
                    $(document).off('touchstart.restoreFocus');
                }
            });
        },

        showToolbar: function ()
        {
            var base = this;

            // do not show on tiny screens
            if (!base.canShowToolbar()) {
                return false;
            }

            $('div.moze-wysiwyg-toolbar').hide();

            if (base.toolbar == null) {

                base.toolbar = base.createToolbar(base.config.toolbar);

                var css_pos = 'fixed';
                if ($('body').hasClass('touch-mode')) {
                    $('#mz_sidebar').append(base.toolbar); // will show in sidebar, absolute positioned
                    css_pos = 'static';
                } else {
                    base.editor.before(base.toolbar); // normal positioning
                }

                base.toolbar
                    .hide()
                    .css('z-index', 200)
                    .css('position', css_pos)
                    .draggable({handle: '.handle'});

                base.toolbar
                    .on('mouseenter touchstart', function (e) {
                        base.onToolbarEnter();
                    })
                    .mouseleave(function (e) {
                        base.restoreFocusEvents();
                    });

                base.toolbar.find('.combo-element').each(function (index) {
                    var backgroundColor = colorToHex($(this).css("background-color"));
                    var color = colorToHex($(this).css("color"));
                    // do only if background is white
                    if (backgroundColor.toUpperCase() == '#FFFFFF') {
                        if (isColorTooLightYIQ(color)) {
                            $(this).css("color", "#444444");
                        }
                    }
                });
            }

            base.showMobileSidebar();
            base.toolbar.show();
            base.relocateToolbars();
            base.observeUndoState();
            base.updateToolbarButtons();

        },

        hideToolbar: function ()
        {
            var base = this;

            if ($('body').hasClass('touch-mode') && !$('#mz_customizer').is(':visible')) {
                $('#mz_sidebar').hide();
                $('body').css('margin-left', 0).removeClass('editing');
                if (!isSmallMobileDevice()) {
                    $('#mz_topbar').css('top', 0).show();
                }
                $('body').css('margin-left', $('#mz_topbar').outerWidth());
                //$('#mz_blur').off('mouseup touchend');
            }
            $('div.moze-wysiwyg-toolbar').hide();
            //if (base.config.saveButton !== null) base.config.saveButton.hide();

            base.imageSelected = null;
        },

        showImageToolbar: function ()
        {
            var base = this;

            // do not show on tiny screens
            if (!base.canShowToolbar()) {
                return false;
            }

            if (base.config.toolbarEnabled == true) {

                $('div.moze-wysiwyg-toolbar').hide();

                if (base.imageToolbar == null) {

                    base.imageToolbar = base.createToolbar(base.config.imageToolbar);

                    var css_pos = 'fixed';
                    if ($('body').hasClass('touch-mode')) {
                        $('#mz_sidebar').append(base.imageToolbar); // will show in sidebar, absolute positioned
                        css_pos = 'static';
                    } else {
                        base.editor.before(base.imageToolbar); // normal positioning
                    }

                    base.imageToolbar
                        .hide()
                        .css('z-index', 200)
                        .css('position', css_pos)
                        .draggable({handle: '.handle'});

                    base.imageToolbar
                        .on('mouseenter touchstart', function () {
                            base.onToolbarEnter();
                        })
                        .mouseleave(function () {
                            base.restoreFocusEvents();
                        });

                    base.onClickOutsideSelectedImage();
                }

                base.showMobileSidebar();
                base.imageToolbar.show();
                base.relocateToolbars();
            }
        },

        hideImageToolbar: function ()
        {
            var base = this;

            if (base.isImageResizingModeOn == false) {
                $('div.moze-wysiwyg-toolbar').hide();
                if (base.toolbar != null) {
                    if (base.editor.is(':focus') == true) {
                        base.toolbar.show();
                    }
                }
            }
        },

        showIframeToolbar: function ()
        {
            var base = this;

            // do not show on tiny screens
            if (!base.canShowToolbar()) {
                return false;
            }

            if (base.config.toolbarEnabled == true) {

                $('div.moze-wysiwyg-toolbar').hide();

                if (base.iframeToolbar == null) {

                    base.iframeToolbar = base.createToolbar(base.config.iframeToolbar);

                    var css_pos = 'fixed';
                    if ($('body').hasClass('touch-mode')) {
                        $('#mz_sidebar').append(base.iframeToolbar); // will show in sidebar, absolute positioned
                        css_pos = 'static';
                    } else {
                        base.editor.before(base.iframeToolbar); // normal positioning
                    }

                    base.iframeToolbar
                        .hide()
                        .css('z-index', 200)
                        .css('position', css_pos)
                        .draggable({handle: '.handle'});

                    base.iframeToolbar
                        .on('mouseenter touchstart', function () {
                            base.onToolbarEnter();
                        })
                        .mouseleave(function () {
                            base.restoreFocusEvents();
                        });

                    base.onClickOutsideSelectedIframe();
                }

                // Hides the resize button for JavaScript code inserts.

                if (base.iframeSelected.hasClass('moze-inserted-code') ||
                    base.iframeSelected.hasClass('moze-raw-script')) {
                    base.iframeToolbar.find('a.iframeresize').hide();
                }
                else {
                    base.iframeToolbar.find('a.iframeresize').show();
                }

                // Hides the maps button for nonmap edits.

                if (base.iframeSelected.hasClass('moze-maps')) {
                    base.iframeToolbar.find('a.maps').show();
                }
                else {
                    base.iframeToolbar.find('a.maps').hide();
                }

                base.showMobileSidebar();
                base.iframeToolbar.show();
                base.relocateToolbars();
            }
        },

        hideIframeToolbar: function ()
        {
            var base = this;

            if (base.isImageResizingModeOn == false)
            {
                $('div.moze-wysiwyg-toolbar').hide();
                if (base.toolbar != null)
                {
                    if (base.editor.is(':focus') == true)
                    {
                        base.toolbar.show();
                    }
                }
            }
        },

        showLinkToolbar: function ()
        {
            var base = this;

            // do not show on tiny screens
            if (!base.canShowToolbar()) {
                return false;
            }

            if (base.config.toolbarEnabled == true) {

                $('div.moze-wysiwyg-toolbar').hide();

                if (base.linkToolbar == null) {

                    base.linkToolbar = base.createToolbar(base.config.linkToolbar);

                    var css_pos = 'fixed';
                    if ($('body').hasClass('touch-mode')) {
                        $('#mz_sidebar').append(base.linkToolbar); // will show in sidebar, absolute positioned
                        css_pos = 'static';
                    } else {
                        base.editor.before(base.linkToolbar); // normal positioning
                    }

                    base.linkToolbar
                        .hide()
                        .css('z-index', 200)
                        .css('position', css_pos)
                        .draggable({handle: '.handle'});

                    base.linkToolbar
                        .on('mouseenter touchstart', function () {
                            base.onToolbarEnter();
                        })
                        .mouseleave(function () {
                            base.restoreFocusEvents();
                        });

                    base.linkToolbar.find('.combo-element').each(function (index) {
                        var backgroundColor = colorToHex($(this).css("background-color"));
                        var color = colorToHex($(this).css("color"));
                        // do only if background is white
                        if (backgroundColor.toUpperCase() == '#FFFFFF') {
                            if (isColorTooLightYIQ(color)) {
                                $(this).css("color", "#444444");
                            }
                        }
                    });

                    base.onClickOutsideSelectedLink();

                }



                // Hides the resize button for JavaScript code inserts
                base.showMobileSidebar();
                base.updateToolbarButtons();
                base.linkToolbar.show();
                base.relocateToolbars();
            }
        },

        hideLinkToolbar: function ()
        {
            var base = this;
            $('div.moze-wysiwyg-toolbar').hide();
            if (base.toolbar != null)
            {
                if (base.editor.is(':focus') == true)
                {
                    base.toolbar.show();
                }
            }
        },

        turnOnExclusiveToolbarButtonMode: function (toolbar, exclusiveBtnClass)
        {
            var buttons = $(toolbar).find('a');

            $.each(buttons, function () {
                var button = $(this);
                if (button.hasClass(exclusiveBtnClass) == false) {
                    button
                        .addClass('disabled')
                        .css('cursor', 'default')
                        .off('click');
                }
                else {
                    button.parent('li').addClass('down');
                }
            });
        },

        turnOffExclusiveToolbarButtonMode: function (toolbar)
        {
            var base = this;
            var buttons = $(toolbar).find('a');

            $.each(buttons, function () {
                var button = $(this);
                button
                    .removeClass('disabled')
                    .css('cursor', 'pointer')
                    .off('click')
                    .click(function () {
                        base.action(button.attr('class'), null);
                        return false;
                    });
                button.parent('li').removeClass('down');
            });
        },

        relocateToolbars: function ()
        {
            var base = this;

            var windowXOffset = window.pageXOffset;
            var windowYOffset = window.pageYOffset;
            var topbarHeight = 0;
            var deltaY = 5;

            var mobileToolbar = function (toolbar) {
                $('body').addClass('editing');

                $('#mz_blur').off('mouseup touchend');
                $('#mz_blur').on('mouseup touchend', function (e) {
                    // if resize mode, do nothing as it handles itself
                    if (MozWysiwygGlobal.isResizeModeOn)
                        return true;
                    // otherwise loose focus
                    if (base.editor.is(":focus")) {
                        base.toolbar.trigger('mouseleave');
                        base.editor.blur();
                    }
                    return false;
                });
                $('#mz_sidebar').css('height', $(document).outerHeight());
                setTimeout(function () {
                    $('#mz_sidebar').css('padding-top', $(document).scrollTop());
                }, 300);
            }

            var repositionToolbar = function (toolbar, editor) {

                var toolbarX = 100;
                var toolbarY = 100;

                if ($(editor).length > 0) {
                    toolbar.css({top: 0, left: 0});  // to calculate real width

                    var toolbarHeight = toolbar.outerHeight();
                    var toolbarWidth = toolbar.outerWidth();

                    var editorX = editor.offset().left;
                    var editorY = editor.offset().top;
                    var editorHeight = editor.outerHeight();
                    var editorWidth = editor.outerWidth();

                    switch (base.config.toolbarRepositionHalign) {
                        case 'center':
                            toolbarX = editorX + (editorWidth / 2 - toolbarWidth / 2);
                            break;
                        case 'right':
                            toolbarX = editorX + editorWidth - toolbarWidth;
                            break;
                        default:
                            toolbarX = editorX;
                            break;
                    }

                    // if too close to the end of window to fit in
                    if (toolbarWidth > window.innerWidth - editorX - 20) {
                        toolbarX = window.innerWidth - toolbarWidth - 25;
                    }

                    if (editorY - toolbarHeight < windowYOffset + topbarHeight + deltaY) {
                        toolbarY = topbarHeight + deltaY;
                    }
                    else {
                        toolbarY = editorY - windowYOffset - toolbarHeight - deltaY;
                    }

                    // if too close to the top
                    if (toolbarY + toolbarHeight > editorY) {
                        toolbarY = editorY + editorHeight;
                    }

                }

                toolbar
                    .css('left', toolbarX)
                    .css('top', toolbarY);
            };

            var anchorToolbar = function (toolbar, anchor)
            {
                var toolbarX = 100;
                var toolbarY = 100;

                if ($(anchor).length > 0) {

                    var toolbarHeight = toolbar.outerHeight();
                    var toolbarWidth = toolbar.outerWidth();

                    var anchorX = anchor.offset().left;
                    var anchorY = anchor.offset().top;
                    var anchorHeight = anchor.outerHeight();
                    var anchorWidth = anchor.outerWidth();

                    switch (base.config.toolbarAnchorHalign) {
                        case 'center':
                            toolbarX = anchorX + (anchorWidth / 2 - toolbarWidth / 2);
                            break;
                        case 'right':
                            toolbarX = anchorX + anchorWidth - toolbarWidth;
                            break;
                        default:
                            toolbarX = anchorX;
                    }

                    toolbarY = anchorY - windowYOffset - toolbarHeight - deltaY;

                    if (toolbarY < topbarHeight + deltaY) {
                        toolbarY = anchorY - windowYOffset + anchorHeight + deltaY;
                    }
                }

                toolbar
                    .css('left', toolbarX)
                    .css('top', toolbarY);
            };

            // Relocates the approperiate toolbar.

            if (base.toolbar !== null && base.toolbar.is(':visible') == true) {
                if ($('body').hasClass('touch-mode')) {
                    mobileToolbar(base.toolbar);
                }
                else if (base.config.toolbarAnchor !== null) {
                    anchorToolbar(base.toolbar, base.config.toolbarAnchor);
                }
                else {
                    repositionToolbar(base.toolbar, base.editor);
                }
            }

            if (base.imageToolbar !== null && base.imageToolbar.is(':visible') == true) {
                if ($('body').hasClass('touch-mode')) {
                    mobileToolbar(base.imageToolbar);
                }
                else if (base.config.toolbarAnchor !== null) {
                    anchorToolbar(base.imageToolbar, base.config.toolbarAnchor);
                }
                else {
                    repositionToolbar(base.imageToolbar, base.imageSelected);
                }
            }

            if (base.iframeToolbar !== null && base.iframeToolbar.is(':visible') == true) {
                if ($('body').hasClass('touch-mode')) {
                    mobileToolbar(base.iframeToolbar);
                }
                else if (base.config.toolbarAnchor !== null) {
                    anchorToolbar(base.iframeToolbar, base.config.toolbarAnchor);
                }
                else {
                    repositionToolbar(base.iframeToolbar, base.iframeSelected);
                }
            }

            if (base.linkToolbar !== null && base.linkToolbar.is(':visible') == true) {
                if ($('body').hasClass('touch-mode')) {
                    mobileToolbar(base.linkToolbar);
                }
                else if (base.config.toolbarAnchor !== null) {
                    anchorToolbar(base.linkToolbar, base.config.toolbarAnchor);
                }
                else {
                    repositionToolbar(base.linkToolbar, base.linkSelected);
                }
            }

        },

        updateToolbarButtons: function() {
            var base = this;
            var selection = rangy.getSelection();

            if (base.toolbar) {
                // no selection
                if ((selection.isCollapsed)) {
                    base.toolbar.find('a.bold, a.italic, a.underline, a.fontcolor').addClass('disabled');
                } else {
                    base.toolbar.find('a.bold, a.italic, a.underline, a.fontcolor').removeClass('disabled');
                }
            }

            if (base.linkToolbar) {
                // no selection
                if ((selection.isCollapsed)) {
                    base.linkToolbar.find('a.bold, a.italic, a.underline, a.fontsize').hide();
                } else {
                    base.linkToolbar.find('a.bold, a.italic, a.underline, a.fontsize').show();
                }
            }

        },

        setUseCss: function ()
        {
            try {
                // turn *false=off* CSS on all browsers - ensures B, U, I tags are used instead of SPAN with style which is what we want
                // as negative side effect, align is used for alignment, we fix this on save
                document.execCommand('styleWithCSS', 0, false); // false = CSS *off*
            }
            catch (e) {
                try {
                    // turn *true=off* CSS on really old browsers (inc ie 10 and older)
                    // ie 10 and older does not seem to support any CSS anyways
                    document.execCommand('useCSS', 0, true);  // true = CSS *off*
                }
                catch (e) {
                    try {
                        // not sure if this is necessary at all, left for backwards compatibility
                        document.execCommand('styleWithCSS', false, false);
                    }
                    catch (e) {

                    }
                }
            }
        },

        execCommand: function (command, param)
        {
            if (detectedBrowser.msie) {
                this.editor.focus(); // works only before ie 11
            }
            this.setUseCss();

            if (typeof param == 'undefined') {
                document.execCommand(command, null, false);
            }
            else if (param != '') {
                if (detectedBrowser.msie) {
                    param = '<' + param + '>'; // works only before ie 11
                }
                document.execCommand(command, null, param);
            }
            this.editor.focus();
        },

        prepareHtmlForSave: function ()
        {
            var base = this;
            var html = $('<div class="moze-content">' + this.editor.html() + '</div>');

            this.uploadBase64Images();

            // normalize invalid HTML - deals with align attribute
            html.find('p, div, h1, h2, h3, blockquote').each(function (i) {

                var cl = '';
                var attr = $(this).attr('align');
                if (typeof attr !== 'undefined' && attr !== false) {
                    cl = attr.toLowerCase();
                    $(this).removeAttr('align');
                }
                if (this.style && this.style.textAlign) {
                    cl = this.style.textAlign.toLowerCase();
                    $(this).css('text-align', '');
                    if ($(this).attr('style') === '') {
                        $(this).removeAttr('style');
                    }
                }
                if (cl) {
                    $(this).addClass('moze-' + cl);
                }
            });

            // remove leftover empty style="" and redundant span tags
            html.find('span').each(function () {
                // remove style, if empty
                if ($(this).attr('style') === '') {
                    $(this).removeAttr('style');
                }
                // remove empty tag
                if (this.attributes.length === 0) {
                    $(this).replaceWith($(this).html());
                }
            });

            // remove empty a, span tags
            html.find('a, span').each(function () {
                // remove empty tag
                var content = $(this).html();
                if (content == '') {
                    $(this).remove();
                }
            });

            // remove double empty paragraphs
            html.find('p').each(function () {
                if (($(this).html() == '') &&
                    ($(this).prev('p').length == 1) &&
                    ($(this).prev('p').html() == '')) {
                    $(this).remove();
                }
            });

            // remove paragraphs for non-paragraphed text
            if (!this.config.wantsParagraphs) {
                html.find('p').each(function () {
                    $(this).replaceWith($(this).html() + '<br>');
                });
            }

            // process iframes
            html.find('div.moze-iframe').each(function () {

                var dataSrc = $(this).data('src');
                var dataHeight = $(this).css('height');
                var dataWidth = $(this).css('width');
                var content = $(this).html();

                dataHeight = (typeof dataHeight != 'undefined') ? dataHeight : 360;
                dataWidth = (typeof dataWidth != 'undefined') ? dataWidth : 640;

                var iframe = $('<iframe>')
                    .addClass('moze-iframe')
                    .attr('src', dataSrc)
                    .attr('height', dataHeight)
                    .attr('width', dataWidth)
                    .html(content);

                // youtube requires allowfullscreen attribute to play in fullscreen
                if (base.getYouTubeVideoID(dataSrc) !== false) {
                    iframe.attr('allowfullscreen', 'allowfullscreen');
                }

                $(this).replaceWith(iframe);
            });

            // process maps
            html.find('div.moze-maps').each(function () {
                $(this).removeClass('moze-object');
            });

            //process inserted code
            html.find('div.moze-inserted-code').each(function () {
                if ($(this).length > 0) {
                    $(this)[0].innerHTML = $(this).data('code');
                }
                $(this).removeClass('moze-object');
                $(this).removeAttr('data-code');
                $(this).removeAttr('contenteditable');
            });

            //process raw code
            html.find('div.moze-raw-script').each(function () {
                if ($(this).length > 0) {
                    $(this)[0].outerHTML = $(this).data('code');
                }
            });

            // remove hidden markers and save
            var output = base.stripHiddenMarkers(html.html());
            return output.trim();
        },

        prepareBrowserSpecificHtml: function ()
        {
            var editor = this.editor;
            var html = editor.html();
            var base = this;

            if (html !== null) {
                html = html.replace(/<strong\b[^>]*>([\w\W]*?)<\/strong[^>]*>/gi, '<b>$1</b>');
                html = html.replace(/<em\b[^>]*>([\w\W]*?)<\/em[^>]*>/gi, '<i>$1</i>');
            }
            else {
                html = '';
            }

            editor.html(html);

            editor.find('p, div, h1, h2, h3, blockquote').each(function (i) {
                var forcealign = '';
                if ($(this).hasClass('moze-left')) {
                    forcealign = 'left';
                }
                if ($(this).hasClass('moze-center')) {
                    forcealign = 'center';
                }
                if ($(this).hasClass('moze-right')) {
                    forcealign = 'right';
                }
                if ($(this).hasClass('moze-justify')) {
                    forcealign = 'justify';
                }

                $(this).removeClass('moze-left moze-right moze-justify moze-center');
                if ($(this).attr('class') == '') {
                    $(this).removeAttr('class');
                }

                if (detectedBrowser.webkit) {
                    var attr = (forcealign) ? forcealign : $(this).attr('align');
                    if (typeof attr !== 'undefined' && attr !== false) {
                        attr = attr.toLowerCase();
                        $(this).removeAttr('align');
                        this.style.textAlign = attr;
                    }
                }
                else {
                    // since IE masks as mozilla, we have to force align for all browsers unless it is webkit
                    if ((this.style && this.style.textAlign) || forcealign) {
                        var al = (forcealign) ? forcealign : this.style.textAlign.toLowerCase();
                        $(this).removeAttr('style');
                        $(this).attr('align', al);
                    }
                }
            });

            editor.find('iframe').each(function() {


                var dataSrc    = $(this).attr('src');
                var dataHeight = $(this).attr('height');
                var dataWidth  = $(this).attr('width');
                var content    = $(this).html();

                var is_moze    = $(this).hasClass('moze-iframe')
                var youtube = base.getYouTubeVideoID(dataSrc);
                var vimeo = base.getVimeoVideoID(dataSrc);

                if (is_moze || youtube || vimeo) {
                    $(this).replaceWith(
                        $('<div class="moze-object moze-iframe">')
                            .attr('contenteditable', 'false')
                            .attr('data-src', dataSrc)
                            .css('height', dataHeight)
                            .css('width', dataWidth)
                            .html(content)
                    );
                }

            });

            editor.find('div.moze-maps').each(function () {
                $(this).addClass('moze-object').attr('contenteditable', 'false');
            });

            editor.find('div.moze-inserted-code').not('.moze-object').each(function () {
                var content = $(this).html();
                content = content.replace('<!--#Mozello Script Comment Start#', '<script');
                content = content.replace('#Mozello Script Comment End#-->', '</script>');
                content = content.replace('-#Mozello - Dashes#', '--');
                $(this)
                    .addClass('moze-object')
                    .attr('contenteditable', 'false')
                    .attr('data-code', content)
                    .html('');
            })

            //deal with leftover scripts
            editor.find(":not(iframe)").addBack().contents().each(function () {
                if (this.nodeType == 8) {
                    var content = this.nodeValue;
                    if (content.match(/^#Mozello Script Comment Start#/) && content.match(/#Mozello Script Comment End#$/)) {
                        content = content.replace('#Mozello Script Comment Start#', '<script');
                        content = content.replace('#Mozello Script Comment End#', '</script>');
                        content = content.replace('-#Mozello - Dashes#', '--');
                        var div = $('<div>')
                            .addClass('moze-object')
                            .addClass('moze-raw-script')
                            .attr('contenteditable', 'false')
                            .attr('data-code', content);
                        $(this).replaceWith(div);
                    }
                }
            });
        },

        autosave: function ()
        {
            if (this.isModified == true && this.config.autosaveEnabled == true && !MozWysiwygGlobal.isResizeModeOn) {

                var cid = this.element.attr('data-cid');
                var name = this.element.attr('data-name');
                var keyname = this.element.attr('data-keyname');
                var value = this.prepareHtmlForSave();

                if (this.config.autosaveCallback != null) {
                    this.config.autosaveCallback(cid, name, value, keyname);
                    this.isModified = false;
                    this.lastChange = $.now();
                }

                if (this.config.textSyncCallback != null) {
                    this.config.textSyncCallback(value);
                }
                this.observeObjects();
            }
        },

        uploadBase64Images: function ()
        {
            var base = this;
            var editor = this.editor;
            editor.find('img[src]').each(function() {
                if ($(this).attr('src').substr(0, 5) == 'data:') {
                    var img = this;
                    if ($(img).attr('data-moz-debase64') != 'yes') {
                        $.post(
                            '/m/ajax-save-base64-image/',
                            { src: $(this).attr('src') }
                        )
                        .done(function(data) {
                                if (data && data.error === false && data.fileDir && data.fileName) {
                                    $(img).attr('src', data.fileDir + data.fileName);
                                }
                        })
                        .always(function() {
                            $(img).attr('data-moz-debase64', 'yes');
                        });
                    }
                }
            });
        },

        observeObjects: function ()
        {
            var base = this;
            var editor = this.editor;

            // Disables object resizing and table editing.

            try {
                document.execCommand('enableObjectResizing', false, false);
                document.execCommand('enableInlineTableEditing', false, false);
            }
            catch (e) {

            }

            // Observers images.

            $.each(editor.find('img'), function () {

                var image = $(this);

                image
                    .removeAttr('unselectable')
                    .off();

                // legacy IE - disable IE-style resize (just in case)
                this.addEventListener('resizestart', function (e) {
                    e.returnValue = false;
                }, false);

                // legacy IE - do not let IE selection swallow click event
                this.addEventListener('controlselect', function (e) {
                    image.trigger('click');
                    //e.returnValue = false;
                }, false);

                // legacy IE - drop IE selection (selection needed while mousedown - for dragging)
                this.addEventListener('mouseup', function (e) {
                    if (document.selection && document.selection.type == 'Control') {
                        document.selection.empty();
                    }
                }, false);

                image.off('click.observer touchend.observer');
                image.on('click.observer touchend.observer', function (e) {
                    if (noClicks()) {
                        e.stopPropagation();
                        return false;
                    }
                    if (isSwipeTakingPlace) {
                        return false;
                    }
                    /* needed for touch to activate editor */
                    if (!MozWysiwygGlobal.isResizeModeOn) {
                        base.editor.focus();
                    }
                    base.imageSelected = image;
                    base.showImageToolbar();
                    return false;
                });

                image.off('dragstart.observer');
                image.on('dragstart.observer', function () {
                    base.hideImageToolbar();
                });

                image.off('dragend.observer');
                image.on('dragend.observer', function () {
                    base.observeObjects();
                    base.imageSelected = null;
                    base.editor.focus();
                    // drops IE object selection, but is multiplatform
                    window.getSelection().collapseToEnd();
                });

            });

            // Observers iframes.

            $.each(editor.find('div.moze-object'), function () {

                var iframe = $(this);

                // for IE
                iframe
                    .removeAttr('unselectable')
                    .attr('contenteditable', 'false')
                    .off();

                // legacy IE - disable IE-style resize (just in case)
                this.addEventListener('resizestart', function (e) {
                    e.returnValue = false;
                }, false);

                // legacy IE - do not let IE selection swallow click event
                this.addEventListener('controlselect', function (e) {
                    iframe.trigger('click');
                    //e.returnValue = false;
                }, false);

                // legacy IE - drop IE selection (selection needed while mousedown - for dragging)
                this.addEventListener('mouseup', function (e) {
                    if (document.selection && document.selection.type == 'Control') {
                        document.selection.empty();
                    }
                }, false);

                iframe.off('click.observer touchend.observer');
                iframe.on('click.observer touchend.observer', function (e) {
                    if (noClicks()) {
                        e.stopPropagation();
                        return false;
                    }
                    if (isSwipeTakingPlace) {
                        return false;
                    }
                    /* needed for touch to activate editor */
                    if (!MozWysiwygGlobal.isResizeModeOn) {
                        base.editor.focus();
                    }
                    base.iframeSelected = iframe;
                    base.showIframeToolbar();
                });

                iframe.off('dragstart.observer');
                iframe.on('dragstart.observer', function () {
                    base.hideIframeToolbar();
                });

                iframe.off('dragend.observer');
                iframe.on('dragend.observer', function () {
                    base.observeObjects();
                    base.iframeSelected = null;
                    base.editor.focus();
                    // drops IE object selection, but is multiplatform
                    window.getSelection().collapseToEnd();
                });

            });

            // Observe links

            $.each(editor.find('a'), function () {

                var link = $(this);

                // not for links containing images
                if (link.find('img').length) {
                    return false;
                }

                link.off('click.observer touchend.observer');
                link.on('click.observer touchend.observer', function (e) {
                    if (noClicks()) {
                        e.stopPropagation();
                        return false;
                    }
                    if (isSwipeTakingPlace) {
                        return false;
                    }
                    base.linkSelected = link;
                    base.onClickInsideSelectedLink();
                    return true;
                });

                link.off('dblclick.observer');
                link.on('dblclick.observer', function (e) {
                    base.onClickInsideSelectedLink();
                });

                link.off('dragstart.observer');
                link.on('dragstart.observer', function () {
                    base.hideLinkToolbar();
                });

                link.off('dragend.observer');
                link.on('dragend.observer', function () {
                    base.observeObjects();
                    base.linkSelected = null;
                    base.editor.focus();
                    // drops IE object selection, but is multiplatform
                    window.getSelection().collapseToEnd();
                });

            });



        },

        observeSplitState: function ()
        {
            var base = this;
            var editor = this.editor;

            if (base.toolbar != null) {
                if (editor.find('hr.moze-more-divider').length == 0) {
                    base.toolbar.find('a.splitmerge').parent('li').removeClass('down');
                }
                else {
                    base.toolbar.find('a.splitmerge').parent('li').addClass('down');
                }
            }
        },

        getCellFromSelectionRange: function (range)
        {
            // whole td is selected
            var cell = range.getNodes([1], function (node) {
                return (node.nodeName.toLowerCase() == 'td');
            });

            // something inside td is selected
            if (cell.length == 0) {
                cell = $(range.commonAncestorContainer).filter('td').first()[0];
            }

            // something deeper is selected
            if (typeof cell == 'undefined') {
                cell = $(range.commonAncestorContainer).parents('td').first()[0];
            }

            return $(cell);
        },

        getYouTubeVideoID: function (url)
        {
            var pattern = /^(?:https?:\/\/)?(?:www\.)?(?:youtu\.be\/|youtube\.com(?:\/embed\/|\/v\/|\/watch\?v=|\/watch\?.+&v=))([\w-]{11})(?:.+)?$/;
            return (url.match(pattern)) ? RegExp.$1 : false;
        },

        getVimeoVideoID: function (url)
        {
            var pattern = /^(?:https?:\/\/)?(?:www\.)?vimeo\.com\/(?:.*#|.*\/videos\/)?([0-9]+)$/;
            return (url.match(pattern)) ? RegExp.$1 : false;
        },

        isEmail: function (email)
        {
            var pattern = /^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,4})$/i;
            return (email.match(pattern)) ? true : false;
        },

        normalizeLink: function (newHref)
        {
            if (newHref.substring(0, 7) == 'mailto:') {
                return newHref;
            }
            if (newHref.substring(0, 7) == 'http://') {
                return newHref;
            }
            if (newHref.substring(0, 8) == 'https://') {
                return newHref;
            }
            if (newHref.substring(0, 4) == 'tel:') {
                return newHref;
            }

            if (this.isEmail(newHref)) {
                newHref = 'mailto:' + newHref;
            }
            else if (newHref.substring(0, 1) != '/') {
                newHref = 'http://' + newHref;
            }
            return newHref;
        },

        removeHeadersFromSelection: function () {

            //remove heading elements (because sometimes on chrome removeFormat and <p> command doesn't work)
            var selection = rangy.getSelection();
            if (selection.rangeCount > 0) {
                var ranges = selection.getAllRanges();
                var range = ranges[0];
                //all heading elements inside selection
                var elems = range.getNodes([1], function (node) {
                    return /^h[0-9]$/i.test(node.nodeName);
                });
                //plus all heading elements used as parents
                var ancestorelement = range.commonAncestorContainer;
                $(ancestorelement).parents(":header").addBack(":header").each(function (i, e) {
                    elems[elems.length] = e;
                })
                //remove heading elements, while leaving their children
                for (var i = 0; i < elems.length; i++) {
                    var elem = elems[i];
                    var cnt = $(elem).contents();
                    $(elem).replaceWith(cnt);
                }
            }
        },

        restoreSelection: function ()
        {
            var base = this;
            if (base.savedSelection != null) {
                rangy.getSelection().restoreCharacterRanges(base.editor.get(0), base.savedSelection);
                base.savedSelection = null;
            }
        },

        saveSelection: function ()
        {
            var base = this;
            base.savedSelection = rangy.getSelection().saveCharacterRanges(base.editor.get(0));
        },

        observeUndoState: function ()
        {
            var base = this;
            if (base.toolbar) {
                b_undo = base.toolbar.find('a.undo');
                b_redo = base.toolbar.find('a.redo');
                // update toolbar
                if (base.undoStack.length == 0) {
                    b_undo.addClass('disabled');
                } else {
                    b_undo.removeClass('disabled');
                }
                // update toolbar
                if (base.redoStack.length == 0) {
                    b_redo.addClass('disabled');
                } else {
                    b_redo.removeClass('disabled');
                }
            }
        },

        addUndoPoint: function (delay, clearRedo)
        {
            var base = this;
            var currentTime = new Date().getTime();
            clearRedo = (typeof clearRedo !== 'undefined') ? clearRedo : true;
            delay = (typeof delay !== 'undefined') ? delay : 0;

            if ((currentTime - base.lastUndoTime) > delay) {

                var undoPoint = new Object();

                // clear redo
                if (clearRedo) {
                    base.redoStack.length = 0;
                }

                // limit maximum undo count to conserve memory
                if (base.undoStack.length > 30) {
                    base.undoStack.shift();
                }

                // remember only selection
                if (base.undoStack.length > 0) {
                    var lastUndo = base.undoStack[base.undoStack.length - 1];
                    if (lastUndo.htmlText == base.editor.html()) {
                        base.undoStack.pop();
                    }
                }

                // save selection
                undoPoint.activeSelection = rangy.getSelection().saveCharacterRanges(base.editor.get(0));
                // save text
                undoPoint.htmlText = base.editor.html();
                // store undo item
                base.undoStack.push(undoPoint);

                base.observeUndoState();

                base.lastUndoTime = currentTime;

            }

        },

        addRedoPoint: function ()
        {
            var base = this;
            var redoPoint = new Object();
            // save selection
            redoPoint.activeSelection = rangy.getSelection().saveCharacterRanges(base.editor.get(0));
            // save text
            redoPoint.htmlText = base.editor.html();
            // store undo item
            base.redoStack.push(redoPoint);
            base.observeUndoState();
        },

        execUndoPoint: function ()
        {
            var base = this;
            // if there is something to undo
            if (base.undoStack.length > 0) {
                // in case we need to redo
                base.addRedoPoint();
                var undoPoint = base.undoStack.pop();
                base.editor.html(undoPoint.htmlText);
                rangy.getSelection().restoreCharacterRanges(base.editor.get(0), undoPoint.activeSelection);
                base.editor.focus();
            }
            base.isModified = true;
            base.autosave();
            base.observeUndoState();
        },

        execRedoPoint: function ()
        {
            var base = this;
            // if built-in redo did nothing
            if (base.redoStack.length > 0) {
                // save for undo
                base.addUndoPoint(0, false);
                var redoPoint = base.redoStack.pop();
                base.editor.html(redoPoint.htmlText);
                rangy.getSelection().restoreCharacterRanges(base.editor.get(0), redoPoint.activeSelection);
                base.editor.focus();
            }
            base.isModified = true;
            base.autosave();
            base.observeUndoState();
        },

        initCssAppliers: function ()
        {
            var base = this;

            if (typeof base.cssApplierMegatitle == 'undefined') {
                base.cssApplierMegatitle = rangy.createCssClassApplier('moze-megatitle', {normalize: true});
            }

            if (typeof base.cssApplierImportant == 'undefined') {
                base.cssApplierImportant = rangy.createCssClassApplier('moze-important', {normalize: true});
            }

            if (typeof base.cssApplierSecondary == 'undefined') {
                base.cssApplierSecondary = rangy.createCssClassApplier('moze-secondary', {normalize: true});
            }

            if (typeof base.cssApplierCode == 'undefined') {
                base.cssApplierCode = rangy.createCssClassApplier('moze-code', {normalize: true});
            }

            if (typeof base.cssApplierStrike == 'undefined') {
                base.cssApplierStrike = rangy.createCssClassApplier('moze-strike', {normalize: true});
            }

            if (typeof base.cssApplierBlockquote == 'undefined') {
                base.cssApplierBlockquote = rangy.createCssClassApplier('moze-blockquote', {normalize: true});
            }

            if (typeof base.cssApplierButton == 'undefined') {
                base.cssApplierButton = rangy.createCssClassApplier('moze-button', {normalize: true});
            }

            if (typeof base.cssApplierButtonLarge == 'undefined') {
                base.cssApplierButtonLarge = rangy.createCssClassApplier('moze-button-large', {normalize: true});
            }

            if (typeof base.cssApplierTiny == 'undefined') {
                base.cssApplierTiny = rangy.createCssClassApplier('moze-tiny', {normalize: true});
            }

            if (typeof base.cssApplierSmall == 'undefined') {
                base.cssApplierSmall = rangy.createCssClassApplier('moze-small', {normalize: true});
            }

            if (typeof base.cssApplierLarge == 'undefined') {
                base.cssApplierLarge = rangy.createCssClassApplier('moze-large', {normalize: true});
            }

            if (typeof base.cssApplierHuge == 'undefined') {
                base.cssApplierHuge = rangy.createCssClassApplier('moze-huge', {normalize: true});
            }

            if (typeof base.cssApplierGigantic == 'undefined') {
                base.cssApplierGigantic = rangy.createCssClassApplier('moze-gigantic', {normalize: true});
            }
        },

        action: function (type, value)
        {
            var base = this;

            if ($('body').hasClass('touch-mode')) {
                base.editor.focus();
            }

            base.restoreSelection();

            // skip some actions if no selection

            var selection = rangy.getSelection();
            if (selection.isCollapsed && (
                (type == 'bold') ||
                (type == 'italic') ||
                (type == 'underline') ||
                (type == 'textcolor'))) {
                base.editor.focus();
                return true;
            }

            if ((type != 'undo') && (type != 'redo') &&
                (type != 'imgresize') &&
                (type != 'iframeresize')) {
                base.addUndoPoint();
            }

            base.isModified = true; // just before action

            switch (type) {
                case 'font'             :
                    this.actionFont(value);
                    break;
                case 'heading'          :
                    this.actionFont(value);
                    break;
                case 'fontsize'         :
                    this.actionFontSize(value);
                    break;
                case 'justifyleft'      :
                    this.actionJustify('JustifyLeft');
                    break;
                case 'justifycenter'    :
                    this.actionJustify('JustifyCenter');
                    break;
                case 'justifyright'     :
                    this.actionJustify('JustifyRight');
                    break;
                case 'justifyfull'      :
                    this.actionJustify('JustifyFull');
                    break;
                case 'fontcolor'        :
                    this.actionFontColor();
                    break;
                case 'splitmerge'       :
                    this.actionSplitMerge();
                    break;
                case 'undo'             :
                    this.execUndoPoint();
                    break;
                case 'redo'             :
                    this.execRedoPoint();
                    break;
                case 'bold'             :
                    this.execCommand('Bold');
                    break;
                case 'italic'           :
                    this.execCommand('Italic');
                    break;
                case 'underline'        :
                    this.execCommand('Underline');
                    break;
                case 'bullets'          :
                    this.execCommand('InsertUnorderedList');
                    break;
                case 'numbering'        :
                    this.execCommand('InsertOrderedList');
                    break;
                case 'link'             :
                    this.actionLink();
                    break;
                case 'file'             :
                    this.actionFile();
                    break;
                case 'image'            :
                    this.actionImage();
                    break;
                case 'button'            :
                    this.actionButton();
                    break;
                case 'video'            :
                    this.actionVideo();
                    break;
                case 'maps'             :
                    this.actionMaps();
                    break;
                case 'symbol'           :
                    this.actionSymbol();
                    break;
                case 'inscode'          :
                    this.actionCode();
                    break;
                case 'createtable'      :
                    this.actionCreateTable();
                    break;
                case 'addcolumnbefore'  :
                    this.actionAddColumn('before');
                    break;
                case 'addcolumnafter'   :
                    this.actionAddColumn('after');
                    break;
                case 'deletecolumn'     :
                    this.actionDeleteColumn();
                    break;
                case 'addrowbefore'     :
                    this.actionAddRow('before');
                    break;
                case 'addrowafter'      :
                    this.actionAddRow('after');
                    break;
                case 'togglerowstyle'   :
                    this.actionToggleRowStyle();
                    break;
                case 'deleterow'        :
                    this.actionDeleteRow();
                    break;
                case 'html'             :
                    this.actionHtml();
                    break;
                case 'clearformatting'  :
                    this.actionClearFormatting();
                    break;

                case 'imgjustifyleft'   :
                    this.actionImgAlign('left');
                    break;
                case 'imgjustifycenter' :
                    this.actionImgAlign('center');
                    break;
                case 'imgjustifyright'  :
                    this.actionImgAlign('right');
                    break;
                case 'imgjustifyinline' :
                    this.actionImgAlign('inline');
                    break;
                case 'imgresize'        :
                    this.actionImgResize();
                    break;
                case 'imgproperties'    :
                    this.actionImgProperties();
                    break;
                case 'imgdelete'        :
                    this.actionImgDelete();
                    break;

                case 'iframeresize'     :
                    this.actionIframeResize();
                    break;
                case 'iframedelete'     :
                    this.actionIframeDelete();
                    break;

                case 'linkremove':
                    this.actionLinkRemove();
                    break;
                case 'buttonspace':
                    this.actionLinkSpacing();
                    break;

            }
        },

        actionUnformat: function ()
        {
            var base = this;

            // Styles
            base.cssApplierMegatitle.undoToSelection();
            base.cssApplierImportant.undoToSelection();
            base.cssApplierSecondary.undoToSelection();
            base.cssApplierCode.undoToSelection();
            base.cssApplierStrike.undoToSelection();
            base.cssApplierBlockquote.undoToSelection();
            base.cssApplierButton.undoToSelection();
            base.cssApplierButtonLarge.undoToSelection();

            // Sizes
            base.cssApplierTiny.undoToSelection();
            base.cssApplierSmall.undoToSelection();
            base.cssApplierLarge.undoToSelection();
            base.cssApplierHuge.undoToSelection();
            base.cssApplierGigantic.undoToSelection();

            base.execCommand('removeFormat');

            base.removeHeadersFromSelection();

        },
        actionFont: function (val)
        {
            var base = this;

            function selectIfNothingSelected() {
                var selection = rangy.getSelection();
                if (selection.rangeCount > 0) {
                    var ranges = selection.getAllRanges();
                    var range = ranges[0];
                    var element = range.commonAncestorContainer;
                    // if no selection, expand selection to nearest parent
                    if (range.toString() == '') {
                        range.selectNode(range.startContainer);
                        selection.setSingleRange(range);
                        // if there is no textual content, generate a space for formatting features to work
                        if (selection.toString() == '') {
                            $(element).prepend("&nbsp;");
                            selection.selectAllChildren(element);
                        }
                    }
                }
            }

            if (val != 'buttonsmall' && val != 'buttonlarge') {
                selectIfNothingSelected();
            }


            base.initCssAppliers();

            if (val != 'strike') {

                try {
                    // try fixes rangy crash on FireFox
                    base.cssApplierMegatitle.undoToSelection();
                    base.cssApplierImportant.undoToSelection();
                    base.cssApplierSecondary.undoToSelection();
                    base.cssApplierCode.undoToSelection();
                    base.cssApplierBlockquote.undoToSelection();
                    // for legacy reasons, old version allowed span to have button styles
                    base.cssApplierButton.undoToSelection();
                    base.cssApplierButtonLarge.undoToSelection();
                } catch (err) {

                }
            }

            switch (val) {
                case 'normal' :
                    base.actionUnformat();
                    break;
                case 'paragraph':
                    base.removeHeadersFromSelection();
                    base.execCommand('formatblock', 'p');
                    break;
                case 'topheader' :
                    base.execCommand('formatblock', 'h1');
                    break;
                case 'header' :
                    base.execCommand('formatblock', 'h2');
                    break;
                case 'subtitle' :
                    base.execCommand('formatblock', 'h3');
                    break;
                case 'megatitle' :
                    base.execCommand('formatblock', 'h1');
                    base.cssApplierMegatitle.applyToSelection();
                    break;
                case 'important' :
                    base.cssApplierImportant.applyToSelection();
                    break;
                case 'secondary' :
                    base.cssApplierSecondary.applyToSelection();
                    break;
                case 'blockquote' :
                    base.cssApplierBlockquote.applyToSelection();
                    break;
                case 'code' :
                    base.cssApplierCode.applyToSelection();
                    break;
                case 'strike' :
                    base.cssApplierStrike.toggleSelection();
                    break;
                case 'buttonremove' :
                    //base.cssApplierButton.applyToSelection();
                    base.actionLinkButtonStyle('');
                    break;
                case 'buttonsmall' :
                    //base.cssApplierButton.applyToSelection();
                    base.actionLinkButtonStyle('moze-button');
                    break;
                case 'buttonlarge' :
                    //base.cssApplierButtonLarge.applyToSelection();
                    base.actionLinkButtonStyle('moze-button-large');
                    break;
            }

            base.isModified = true;
            base.autosave();
        },

        actionFontSize: function (val)
        {
            var base = this;

            base.initCssAppliers();

            base.cssApplierTiny.undoToSelection();
            base.cssApplierSmall.undoToSelection();
            base.cssApplierLarge.undoToSelection();
            base.cssApplierHuge.undoToSelection();
            base.cssApplierGigantic.undoToSelection();

            switch (val) {
                case 'tiny' :
                    base.cssApplierTiny.applyToSelection();
                    break;
                case 'small' :
                    base.cssApplierSmall.applyToSelection();
                    break;
                case 'large' :
                    base.cssApplierLarge.applyToSelection();
                    break;
                case 'huge' :
                    base.cssApplierHuge.applyToSelection();
                    break;
                case 'gigantic' :
                    base.cssApplierGigantic.applyToSelection();
                    break;
            }

            base.isModified = true;
            base.autosave();
        },

        actionJustify: function (justifyDirection)
        {
            //select full paragraph (otherwise FF won't justify paragraph that contains newlines)
            var selection = rangy.getSelection();
            if (selection.rangeCount > 0) {
                var ranges = selection.getAllRanges();
                var range = ranges[0];
                var element = range.commonAncestorContainer;
                while (element != null) {
                    if (element == null || element == this.editor[0]) {
                        break;
                    } else if (element.nodeName.toLowerCase() == 'p') {
                        range.selectNode(element);
                        selection.setSingleRange(range);
                        break;
                    }
                    element = element.parentNode;
                }
            }

            this.execCommand(justifyDirection);
        },

        actionFontColor: function ()
        {
            var base = this;
            var editor = this.editor;
            var button = base.toolbar.find('a.fontcolor');

            // processes selection, resets all color tags to default
            function RemoveCSSColors() {
                var sel = rangy.getSelection();
                if (!sel.isCollapsed) {
                    for (var i = 0, range; i < sel.rangeCount; ++i) {
                        range = sel.getRangeAt(i);
                        // Split partially selected nodes
                        range.splitBoundaries();
                        // Get formatting elements. For this example, we'll count any
                        // element with display: inline, except <br>s.
                        var formattingEls = range.getNodes([1], function (el) {
                            return (el.tagName == "SPAN");
                        });
                        // Remove the formatting elements
                        for (var i = 0, el; el = formattingEls[i++]; ) {
                            $(el).css('color', '');
                        }
                    }
                }
            }

            if (!$('#textColorPicker').length) {

                // create input for color picker
                button.append('<input id="textColorPicker" style="display: none;">');

                var selectionData = base.reportColourAndFontSize();
                $('#textColorPicker').val(selectionData.color);

                $('#textColorPicker').spectrum({
                    showInput: true,
                    chooseText: CUS_BTN_CHOOSE,
                    cancelText: CUS_BTN_CANCEL,
                    preferredFormat: "hex",
                    allowEmpty: true,
                    showInitial: true,
                    change: function (color) {
                        // selected color
                        var strColor = '';
                        if (color != null) {
                            strColor = color.toString();
                        }

                        // set selection and preserve it for later
                        base.restoreSelection();
                        base.saveSelection();

                        // do color setting
                        if (strColor == '') {
                            RemoveCSSColors();
                        } else {
                            // set color
                            base.execCommand('foreColor', strColor);
                            // do cleanup
                            editor.find('font').each(function () {
                                $(this).replaceWith(function () {
                                    var c = $(this).attr('color');
                                    return '<span style="color: ' + c + '">' + $(this).html() + '</span>';
                                });
                            });
                        }

                        base.isModified = true;
                        base.autosave();
                    },
                    hide: function (color) {
                        base.restoreSelection();
                        $('#textColorPicker').spectrum("destroy");
                        $('#textColorPicker').remove();
                    },
                });

                base.saveSelection();
                $('#textColorPicker').spectrum('show');
                button.find('.sp-replacer').hide();
            }
        },

        actionSplitMerge: function ()
        {
            var base = this;
            var editor = this.editor;

            if (editor.find('hr.moze-more-divider').length == 0) {
                var selection = rangy.getSelection();
                if (selection.rangeCount > 0) {
                    var ranges = selection.getAllRanges();
                    var range = ranges[0];
                    range.collapse(true);
                    var element = range.commonAncestorContainer;
                    if ($(element)[0] == base.editor[0]) {
                        range.pasteHtml('<hr class="moze-more-divider" /><p></p>');
                    }
                    else {
                        $(element).after($('<hr class="moze-more-divider" /><p></p>'));
                    }
                    base.observeSplitState();
                }
            }
            else {
                editor.find('hr.moze-more-divider').remove();
                base.observeSplitState();
            }

            editor.focus();
            base.isModified = true;
            base.autosave();
        },

        actionLink: function ()
        {
            var base = this;
            var editor = this.editor;

            var selection = rangy.getSelection();
            if (selection.rangeCount > 0) {
                var ranges = selection.getAllRanges();
                var range = ranges[0];
                var element = range.commonAncestorContainer;
                var startElement = range.startContainer;

                // if we are inside a button style, we will apply the style directly to link
                var buttonClass = null;
                var span = $(startElement).parents('span');
                if (span.length > 0) {
                    if ($(span[0]).hasClass('moze-button')) {
                        buttonClass = 'moze-button';
                        range.selectNode(span[0]);
                        selection.setSingleRange(range);
                    }
                    if ($(span[0]).hasClass('moze-button-large')) {
                        buttonClass = 'moze-button-large';
                        range.selectNode(span[0]);
                        selection.setSingleRange(range);
                    }
                }

                // no selection
                if ((range.collapsed) || (range.startContainer == range.endContainer)) {
                    var a = $(element).parents('a');
                    if (a.length > 0) {
                        range.selectNode(a[0]);
                        selection.setSingleRange(range);
                    }
                }

                var link = range.getNodes([1], function (node) {
                    return (node.nodeName.toLowerCase() == 'a');
                });

                link = $(link);

                var oldText = range.toString();
                var oldHref = (link.length > 0) ? link.attr('href') : '';
                var oldTarget = (link.length > 0) ? link.attr('target') : '';

                $.smartModalWindow({
                    innerHeight: '330px',
                    href: '/m/wysiwyg-hyperlink/',
                    innerWidth: '600px',
                    onComplete: function () {

                        var modalIframe = $('#modal-iframe');

                        var childWin = modalIframe.get(0).contentWindow;

                        childWin.loadData(oldHref, oldTarget, oldText, (link.length > 0));

                        modalIframe.contents()
                            .find('input[name="link_href"]')
                            .focus();

                        modalIframe.contents().find('input[name="insert"]').bind('click', function () {

                            var newHref = modalIframe.contents().find('input[name="link_href"]').val();
                            var newText = modalIframe.contents().find('input[name="link_text"]').val();
                            var newTarget = modalIframe.contents().find('select[name="link_target"]').val();

                            $.smartModalWindow().close();
                            editor.focus();
                            selection.setSingleRange(range);

                            if (newHref != '') {
                                newHref = base.normalizeLink(newHref);
                                if (link.length > 0) {
                                    link
                                        .attr('href', newHref)
                                        .attr('target', newTarget);
                                }
                                else {
                                    var newLink = $('<a>')
                                        .attr('href', newHref)
                                        .attr('target', newTarget)
                                        .html((newText != '') ? newText : newHref);

                                    if (buttonClass) {
                                        newLink.addClass(buttonClass);
                                    }

                                    if ($(range.commonAncestorContainer).parents('div.mz_wysiwyg').first().length == 1) {
                                        range.pasteHtml(newLink.prop('outerHTML'));
                                    }
                                }
                            }
                            else {
                                link.replaceWith(link.html());
                            }
                            base.isModified = true;
                            base.autosave();
                        }); // click

                    },
                    onClosed: function () {
                        editor.focus();
                    }

                });
            }
        },

        actionLinkRemove: function ()
        {
            var base = this;
            link = base.linkSelected;
            if (link != null)  {
                link.replaceWith(link.html());
                base.linkSelected = null;
                base.hideLinkToolbar();
                base.showToolbar();
                base.isModified = true;
                base.autosave();
            }
        },

        actionLinkSpacing: function ()
        {
            var base = this;
            link = base.linkSelected;
            if (link != null)  {
                link.before('&nbsp;');
                link.after('&nbsp;');
                var selection = rangy.getSelection();
                if (selection.rangeCount > 0) {
                    var ranges = selection.getAllRanges();
                    var range = ranges[0];
                    selection.selectAllChildren(link[0]);
                    selection.collapseToEnd();
                    selection.move('character', 1);
                    selection.refresh();
                    base.editor.focus();
                }
                base.isModified = true;
                base.autosave();
            }
        },

        actionButton: function ()
        {

            var base = this;
            var editor = this.editor;
            var selection = rangy.getSelection();
            if (selection.rangeCount > 0) {
                var ranges = selection.getAllRanges();
                var range = ranges[0];
                var oldText = range.toString();

                var newLink = $('<a>')
                                        .addClass('moze-button-large')
                                        .addClass('just-inserted-button')
                                        .attr('href', '#')
                                        .html(base.appendHiddenMarkers(oldText == '' ? MWY_BUTTON_TEXT : oldText));

                var element = range.commonAncestorContainer;
                var a = $(element).parents('a');
                if (a.length > 0) {
                    //range.collapse();
                    a.first().after('<br>' + newLink.prop('outerHTML') + '<br>');
                } else {
                    range.pasteHtml('<br>' + newLink.prop('outerHTML') + '<br>');
                }

                base.observeObjects();
                base.linkSelected = editor.find('a.just-inserted-button');
                base.linkSelected.removeClass('just-inserted-button');

                var range = rangy.createRange();
                range.selectNodeContents(base.linkSelected.get(0).firstChild);
                range.moveStart('character', 1);
                range.moveEnd('character', -1);
                selection.setSingleRange(range);
                selection.refresh();

                editor.focus();
                base.showLinkToolbar();
                base.isModified = true;
                base.autosave();

            }
        },

        actionLinkButtonStyle: function (cssClass)
        {
            var base = this;
            link = base.linkSelected;
            if (link != null)  {
                link.removeClass('moze-button-large');
                link.removeClass('moze-button');
                if (cssClass != null) {
                    link.addClass(cssClass);
                }
            }
        },

        actionFile: function ()
        {
            var base = this;
            var editor = base.editor;

            var selection = rangy.getSelection();
            if (selection.rangeCount > 0) {
                var ranges = selection.getAllRanges();
                var range = ranges[0];
                var element = range.commonAncestorContainer;

                if (range.collapsed) {
                    var a = $(element).parents('a');
                    if (a.length > 0) {
                        range.selectNode(a[0]);
                        selection.setSingleRange(range);
                    }
                }

                var link = range.getNodes([1], function (node) {
                    return (node.nodeName.toLowerCase() == 'a');
                });

                link = $(link);
                var oldText = range.toString();

                $.smartModalWindow({
                    href: '/m/fileexplorer/params/sender/wysiwyg/uac/yes/filter/all/',
                    innerWidth: '900px',
                    innerHeight: '80%',
                    onCleanup: function () {

                        editor.focus();
                        selection.setSingleRange(range);

                        var fileName = $('#modal-iframe').contents().find('input[name="file_name"]').val();
                        if (fileName != '') {
                            if (oldText == '') {
                                var fileNameShort = fileName.replace(/^.*[\\\/]/, '');
                                fileNameShort = fileNameShort.split("?")[0];
                                var response = prompt(MWY_FILE_LINK_TEXT, fileNameShort);
                                if ((response != null) && (response != '')) {
                                    oldText = response;
                                } else oldText = fileNameShort;
                            }
                            if (link.length > 0) {
                                link.attr('href', fileName).html(oldText);
                            }
                            else {
                                var linkTag = $('<a>')
                                    .attr('href', fileName)
                                    .html(oldText);

                                if ($(range.commonAncestorContainer).parents('div.mz_wysiwyg').first().length == 1) {
                                    range.pasteHtml(linkTag.prop('outerHTML'));
                                }
                            }

                            base.isModified = true;
                            base.autosave();
                        }
                    },
                    onClosed: function () {
                        editor.focus();
                    }

                });
            }
        },
        actionImage: function ()
        {
            var base = this;
            var editor = base.editor;

            var selection = rangy.getSelection();

            if (selection.rangeCount > 0) {

                var ranges = selection.getAllRanges();
                var range = ranges[0];

                $.smartModalWindow({
                    href: '/m/fileexplorer/params/sender/wysiwyg/uac/yes/filter/images/',
                    innerWidth: '900px',
                    innerHeight: '80%',
                    onCleanup: function () {

                        editor.focus();
                        selection.setSingleRange(range);

                        var fileNameRes;
                        var modalIframe = $('#modal-iframe');
                        var fileName = modalIframe.contents().find('input[name="file_name"]').val();
                        var fileNameMedium = modalIframe.contents().find('input[name="file_name_medium"]').val();
                        var fileNameLarge = modalIframe.contents().find('input[name="file_name_large"]').val();

                        if (fileNameMedium != '') {
                            fileNameRes = fileNameMedium;
                        }
                        else {
                            fileNameRes = fileName;
                        }

                        if (fileNameRes != '') {
                            var imgTag = $('<img>').attr('src', fileNameRes);
                            if ($(range.commonAncestorContainer).parents('div.mz_wysiwyg').first().length == 1) {
                                range.pasteHtml(imgTag.prop('outerHTML'));
                            }
                            setTimeout(function () {
                                base.observeObjects();
                                base.isModified = true;
                                base.autosave();
                            }, 500);
                        }
                    },
                    onClosed: function () {
                        editor.focus();
                    }

                });
            }
        },

        actionVideo: function ()
        {
            var base = this;
            var editor = base.editor;

            var selection = rangy.getSelection();

            if (selection.rangeCount > 0) {

                var ranges = selection.getAllRanges();
                var range = ranges[0];

                $.smartModalWindow({
                    href: '/m/wysiwyg-video/',
                    innerHeight: '350px',
                    innerWidth: '600px',
                    onComplete: function () {

                        var modalIframe = $('#modal-iframe');

                        modalIframe.contents()
                            .find('textarea[name="video_coder"]')
                            .focus();

                        modalIframe.contents().find('input[name="insert"]').bind('click', function () {

                            var code = modalIframe.contents()
                                .find('textarea[name="video_coder"]')
                                .val();

                            $.smartModalWindow().close();
                            editor.focus();
                            selection.setSingleRange(range);

                            if (code != '') {
                                var html;
                                var youtube = base.getYouTubeVideoID(code);
                                var vimeo = base.getVimeoVideoID(code);

                                if (youtube !== false) {
                                    html = $('<div>')
                                        .addClass('moze-object')
                                        .addClass('moze-iframe')
                                        .attr('contenteditable', 'false')
                                        .attr('data-src', 'http://www.youtube.com/embed/' + youtube)
                                        .css('height', 360)
                                        .css('width', 640);

                                    if ($(range.commonAncestorContainer).parents('div.mz_wysiwyg').first().length == 1) {
                                        range.pasteHtml(html.prop('outerHTML'));
                                    }
                                }
                                else if (vimeo !== false) {
                                    html = $('<div>')
                                        .addClass('moze-object')
                                        .addClass('moze-iframe')
                                        .attr('contenteditable', 'false')
                                        .attr('data-src', 'http://player.vimeo.com/video/' + vimeo)
                                        .css('height', 360)
                                        .css('width', 640);

                                    if ($(range.commonAncestorContainer).parents('div.mz_wysiwyg').first().length == 1) {
                                        range.pasteHtml(html.prop('outerHTML'));
                                    }
                                }
                                else {
                                    if ($(range.commonAncestorContainer).parents('div.mz_wysiwyg').first().length == 1) {
                                        range.pasteHtml(code);
                                        base.prepareBrowserSpecificHtml();
                                    }
                                }
                            }

                            base.observeObjects();
                            base.isModified = true;
                            base.autosave();

                        });
                    },
                    onClosed: function () {
                        editor.focus();
                    }
                });
            }
        },

        actionMaps: function ()
        {
            var base = this;
            var editor = base.editor;

            // try to detect and update existing

            var iframe = base.iframeSelected;
            if ((iframe != null) && (iframe.hasClass('moze-maps')))
            {
                var oldLat = iframe.attr('data-lat');
                var oldLng = iframe.attr('data-lng');
                var oldZoom = iframe.attr('data-zoom');

                $.smartModalWindow({
                    href: '/m/wysiwyg-maps/',
                    innerHeight: '510px',
                    innerWidth: '600px',
                    onComplete: function () {

                        var dialog = $('#modal-iframe');
                        dialog.contents().find('input[name="address"]').focus();

                        var childWin = dialog.get(0).contentWindow;
                        childWin.loadData(oldLat, oldLng, oldZoom);

                        dialog.contents().find('input[name="insert"]').bind('click', function () {

                            var lat = dialog.contents().find('div.map-canvas').data('lat');
                            var lng = dialog.contents().find('div.map-canvas').data('lng');
                            var zoom = dialog.contents().find('div.map-canvas').data('zoom');

                            $.smartModalWindow().close();
                            editor.focus();

                            if (lat != null && lng != null) {
                                iframe.attr('data-lat', lat).attr('data-lng', lng).attr('data-zoom', zoom);
                            }

                            base.isModified = true;
                            base.autosave();

                        });
                    },
                    onClosed: function() {
                       editor.focus();
                    }
                });

                return true;
            }

            // insert new map

            var selection = rangy.getSelection();

            if (selection.rangeCount > 0) {

                var ranges = selection.getAllRanges();
                var range = ranges[0];

                $.smartModalWindow({
                    href: '/m/wysiwyg-maps/',
                    innerHeight: '510px',
                    innerWidth: '600px',
                    onComplete: function () {

                        var dialog = $('#modal-iframe');
                        dialog.contents().find('input[name="address"]').focus();

                        dialog.contents().find('input[name="insert"]').bind('click', function () {

                            var lat = dialog.contents().find('div.map-canvas').data('lat');
                            var lng = dialog.contents().find('div.map-canvas').data('lng');
                            var zoom = dialog.contents().find('div.map-canvas').data('zoom');

                            $.smartModalWindow().close();
                            editor.focus();
                            selection.setSingleRange(range);

                            if (lat != null && lng != null) {
                                if ($(range.commonAncestorContainer).parents('div.mz_wysiwyg').first().length == 1) {
                                    var html = $('<div>')
                                        .addClass('moze-object')
                                        .addClass('moze-maps')
                                        .attr('contenteditable', 'false')
                                        .attr('data-lat', lat)
                                        .attr('data-lng', lng)
                                        .attr('data-zoom', zoom)
                                        .css('height', '250px')
                                        .css('width', '100%');
                                    range.pasteHtml(html.prop('outerHTML'));
                                }
                            }

                            base.observeObjects();
                            base.isModified = true;
                            base.autosave();

                        });
                    },
                    onClosed: function() {
                       editor.focus();
                    }
                });
            }
        },

        actionCopyright: function ()
        {
            var base = this;
            var editor = base.editor;
            var selection = rangy.getSelection();

            if (selection.rangeCount > 0) {

                var ranges = selection.getAllRanges();
                var range = ranges[0];

                editor.focus();
                selection.setSingleRange(range);

                if ($(range.commonAncestorContainer).parents('div.mz_wysiwyg').first().length == 1) {
                    range.pasteHtml('&copy;');
                    range.startOffset++;
                    selection.removeAllRanges();
                    selection.addRange(range);
                    selection.refresh();
                }
            }
        },

        actionSymbol: function ()
        {
            var base = this;
            var editor = base.editor;
            var selection = rangy.getSelection();

            if (selection.rangeCount > 0) {

                var ranges = selection.getAllRanges();
                var range = ranges[0];

                $.smartModalWindow({
                    href: '/m/wysiwyg-symbol/',
                    innerWidth: '350px',
                    innerHeight: '220px',
                    onComplete: function () {

                        var dialog = $('#modal-iframe');

                        dialog.contents().find('a.symbol').bind('click', function () {
                            $.smartModalWindow().close();
                            editor.focus();
                            selection.setSingleRange(range);

                            if ($(range.commonAncestorContainer).parents('div.mz_wysiwyg').first().length == 1) {
                                range.pasteHtml($(this).html());
                                range.startOffset++;
                                selection.removeAllRanges();
                                selection.addRange(range);
                                selection.refresh();
                            }

                            base.isModified = true;
                            base.autosave();

                            return false;

                        });
                    },
                    onClosed: function () {
                        editor.focus();
                    }
                });
            }
        },

        actionCode: function ()
        {
            var base = this;
            var editor = base.editor;

            var selection = rangy.getSelection();
            if (selection.rangeCount > 0)
            {
                var ranges = selection.getAllRanges();
                var range = ranges[0];

                $.smartModalWindow({
                    href: '/m/wysiwyg-code/',
                    iframe: true,
                    fastIframe: false,
                    innerHeight: '350px',
                    innerWidth: '600px',
                    onComplete: function () {

                        var modalIframe = $('#modal-iframe');

                        modalIframe.contents()
                            .find('textarea[name="code_coder"]')
                            .focus();

                        modalIframe.contents().find('input[name="insert"]').bind('click', function () {

                            var code = modalIframe.contents()
                                .find('textarea[name="code_coder"]')
                                .val();

                            $.smartModalWindow().close();
                            editor.focus();
                            selection.setSingleRange(range);

                            if (code != '') {
                                var html;

                                html = $('<div>')
                                    .addClass('moze-object')
                                    .addClass('moze-inserted-code')
                                    .attr('contenteditable', 'false')
                                    .attr('data-code', code);

                                if ($(range.commonAncestorContainer).parents('div.mz_wysiwyg').first().length == 1) {
                                    range.pasteHtml(html.prop('outerHTML'));
                                }
                            }

                            base.observeObjects();
                            base.isModified = true;
                            base.autosave();

                        });
                    },
                    onClosed: function () {
                        editor.focus();
                    }
                });
            }
        },

        actionCreateTable: function ()
        {
            var base = this;
            var editor = base.editor;

            var selection = rangy.getSelection();
            if (selection.rangeCount > 0)
            {
                var ranges = selection.getAllRanges();
                var range = ranges[0];

                $.smartModalWindow({
                    href: '/m/wysiwyg-table/',
                    innerHeight: '260px',
                    innerWidth: '580px',
                    onComplete: function () {

                        var modalIframe = $('#modal-iframe');

                        modalIframe.contents().find('input[name="insert"]').bind('click', function () {

                            var tableCols = modalIframe.contents().find('input[name="table_cols"]').val();
                            var tableRows = modalIframe.contents().find('input[name="table_rows"]').val();

                            tableCols = parseInt(tableCols);
                            tableRows = parseInt(tableRows);

                            $.smartModalWindow().close();
                            editor.focus();
                            selection.setSingleRange(range);

                            if (tableCols > 0 && tableRows > 0) {
                                var tableHtml = '<table class="moze-table-border"><tbody>';
                                for (var cols = 0; cols < tableCols; cols++) {
                                    tableHtml += '<tr>';
                                    for (var rows = 0; rows < tableRows; rows++) {
                                        tableHtml += '<td>&nbsp;</td>'
                                    }
                                    tableHtml += '</tr>'
                                }
                                tableHtml += '</tbody></table>';

                                if ($(range.commonAncestorContainer).parents('div.mz_wysiwyg').first().length == 1) {
                                    range.pasteHtml(tableHtml);
                                }

                                // Adds an empty paragraph tag if the table tag is the last tag in the article.

                                if ($(editor.html()).last().prop('tagName').toLowerCase() == 'table') {
                                    $(editor).append($('<p>&nbsp;</p>'));
                                }
                            }

                            base.isModified = true;
                            base.autosave();

                        });
                    },
                    onCleanup: function () {
                        editor.focus();
                    }
                });
            }
        },

        actionAddColumn: function (location)
        {
            var selection = rangy.getSelection();

            if (selection.rangeCount > 0) {
                var ranges = selection.getAllRanges();

                var range;
                if (location == 'before') {
                    range = ranges[0];
                }
                if (location == 'after') {
                    range = ranges[selection.rangeCount - 1];
                }

                var firstCell = this.getCellFromSelectionRange(range);

                if (firstCell.length !== 0) {

                    var cell = $(firstCell);
                    var table = $(firstCell).parents('table').first();
                    var rows = table.children('tbody').children('tr');

                    if (table.length == 1) {

                        selection.removeAllRanges();

                        var cellIndex = cell[0].cellIndex;
                        $.each(rows, function (index, item) {
                            for (var i = 0; i < item.cells.length; i++) {
                                if (i == cellIndex) {
                                    var newCell = $('<td>&nbsp;</td>');
                                    if (location == 'before') {
                                        $(item.cells[i]).before(newCell);
                                        range.selectNode(item.cells[i + 1]);
                                    }
                                    if (location == 'after') {
                                        $(item.cells[i]).after(newCell);
                                        range.selectNode(item.cells[i]);
                                    }
                                    selection.addRange(range);
                                    break;
                                }
                            }
                        });
                    }
                }
            }

            this.editor.focus();
            this.isModified = true;
            this.autosave();
        },

        actionDeleteTableIfSelected: function ()
        {
            var selection = rangy.getSelection();

            if (selection.rangeCount > 0) {

                var ranges = selection.getAllRanges();
                var range = ranges[0];
                var firstCell = this.getCellFromSelectionRange(ranges[0]).first();
                var lastCell = this.getCellFromSelectionRange(ranges[selection.rangeCount - 1]).last();

                if (firstCell.length != 0 && lastCell.length != 0) {
                    if (firstCell.parents('table').first()[0] === lastCell.parents('table').first()[0]) {
                        var table = firstCell.parents('table').first();
                        var rows = table.children('tbody').children('tr');
                        if (firstCell[0].cellIndex == 0 &&
                            firstCell[0].parentNode.rowIndex == 0 &&
                            lastCell[0].cellIndex == table[0].rows[table[0].rows.length - 1].cells.length - 1 &&
                            lastCell[0].parentNode.rowIndex == table[0].rows.length - 1 &&
                            (firstCell[0] != lastCell[0] || firstCell.text().trim() == '')) {
                            table.remove();
                            this.editor.focus();
                            this.isModified = true;
                            this.autosave();
                        }
                    }
                }
            }
        },

        actionDeleteColumn: function ()
        {
            var selection = rangy.getSelection();

            if (selection.rangeCount > 0)
            {
                var ranges = selection.getAllRanges();
                var range = ranges[0];
                var firstCell = this.getCellFromSelectionRange(ranges[0]);
                var lastCell = this.getCellFromSelectionRange(ranges[selection.rangeCount - 1]);

                if (firstCell.length != 0 && lastCell.length !== 0) {
                    if (firstCell.parents('table').first()[0] === lastCell.parents('table').first()[0]) {
                        var table = firstCell.parents('table').first();
                        var rows = table.children('tbody').children('tr');
                        if (firstCell[0].cellIndex == 0 &&
                            lastCell[0].cellIndex == table[0].rows[0].cells.length - 1) {
                            table.remove();
                        }
                        else
                        {
                            selection.removeAllRanges();

                            $.each(rows, function (index, row) {
                                var selectedCell;
                                if (lastCell[0].cellIndex == table[0].rows[0].cells.length - 1) {
                                    selectedCell = $(row).children('td')
                                        .slice(firstCell[0].cellIndex - 1, firstCell[0].cellIndex);
                                }
                                else {
                                    selectedCell = $(row).children('td')
                                        .slice(lastCell[0].cellIndex + 1, lastCell[0].cellIndex + 2);
                                }
                                range.selectNode(selectedCell[0]);
                                selection.addRange(range);
                            });

                            $.each(rows, function (index, row) {
                                $.each($(row).children('td'), function (index, cell) {
                                    if ($(cell)[0].cellIndex >= firstCell[0].cellIndex &&
                                        $(cell)[0].cellIndex <= lastCell[0].cellIndex) {
                                        $(cell).addClass('moze-remove-table-cell');
                                    }
                                });
                            });

                            table.find('td.moze-remove-table-cell').remove();
                        }
                    }
                }
            }

            this.editor.focus();
            this.isModified = true;
            this.autosave();
        },

        actionAddRow: function (location)
        {
            var selection = rangy.getSelection();

            if (selection.rangeCount > 0) {

                var ranges = selection.getAllRanges();

                var range;
                if (location == 'before') {
                    range = ranges[0];
                }
                if (location == 'after') {
                    range = ranges[selection.rangeCount - 1];
                }

                var firstCell = this.getCellFromSelectionRange(range);

                if (typeof firstCell[0] !== 'undefined') {
                    var row = $(firstCell).parents('tr').first();
                    var newRow = $('<tr>');
                    for (var i = 0; i < row[0].cells.length; i++) {
                        newRow.append($('<td>&nbsp;</td>'));
                    }
                    if (location == 'before') {
                        row.before(newRow);
                    }
                    if (location == 'after') {
                        row.after(newRow);
                    }
                    range.selectNode(row[0]);
                    selection.setSingleRange(range);
                }
            }

            this.editor.focus();
            this.isModified = true;
            this.autosave();
        },

        actionToggleRowStyle: function ()
        {
            var selection = rangy.getSelection();

            if (selection.rangeCount > 0) {

                var ranges = selection.getAllRanges();
                var range = ranges[0];
                var firstCell = this.getCellFromSelectionRange(range);

                if (typeof firstCell[0] !== 'undefined') {
                    var row = $(firstCell).parents('tr').first();
                    if ($(row[0]).hasClass('moze-th')) {
                        $(row[0]).removeClass('moze-th');
                    }
                    else {
                        $(row[0]).addClass('moze-th');
                    }
                    range.selectNode(row[0]);
                    selection.setSingleRange(range);
                }
            }

            this.editor.focus();
            this.isModified = true;
            this.autosave();
        },

        actionDeleteRow: function ()
        {
            var selection = rangy.getSelection();

            if (selection.rangeCount > 0) {

                var ranges = selection.getAllRanges();
                var range = ranges[0];
                var firstCell = this.getCellFromSelectionRange(ranges[0]);
                var lastCell = this.getCellFromSelectionRange(ranges[selection.rangeCount - 1]);

                if (firstCell.length != 0 && lastCell.length !== 0) {

                    if (firstCell.parents('table').first()[0] === lastCell.parents('table').first()[0]) {

                        var table = firstCell.parents('table').first();
                        var rows = table.children('tbody').children('tr');
                        var firstRow = firstCell.parents('tr').first();
                        var lastRow = lastCell.parents('tr').first();

                        if (firstRow[0].rowIndex == 0 && lastRow[0].rowIndex == table[0].rows.length - 1) {
                            table.remove();
                        }
                        else {
                            var selectedRow;
                            if (lastRow[0].rowIndex == table[0].rows.length - 1) {
                                selectedRow = rows.slice(firstRow[0].rowIndex - 1, firstRow[0].rowIndex);
                            }
                            else {
                                selectedRow = rows.slice(lastRow[0].rowIndex + 1, lastRow[0].rowIndex + 2)
                            }

                            range.selectNode(selectedRow[0]);
                            selection.setSingleRange(range);

                            rows
                                .slice(firstRow[0].rowIndex, lastRow[0].rowIndex + 1)
                                .addClass('moze-remove-table-row');

                            table
                                .find('tr.moze-remove-table-row')
                                .remove();
                        }
                    }
                }
            }

            this.editor.focus();
            this.isModified = true;
            this.autosave();
        },

        actionHtml: function ()
        {
            var base = this;
            var editor = base.editor;

            $.smartModalWindow({
                href: '/m/wysiwyg-html/',
                iframe: true,
                fastIframe: false,
                innerHeight: '400px',
                innerWidth: '600px',
                onComplete: function () {

                    var modalIframe = $('#modal-iframe');
                    var coder = modalIframe.contents().find('#coder');
                    var childWin = modalIframe.get(0).contentWindow;
                    var isSimpleTextarea = (coder[0].tagName.toLowerCase() == 'textarea');
                    var html = $('<span>' + editor.html() + '</span>');

                    //make raw scripts editable in source
                    html.find('div.moze-raw-script').each(function () {
                        if ($(this).length > 0) {
                            $(this)[0].outerHTML = $(this).data('code');
                        }
                    });

                    var sourceCode = html.html();

                    // do not show hidden markers in code
                    sourceCode = base.stripHiddenMarkers(sourceCode);

                    if (isSimpleTextarea == false) {
                        childWin.updateCode($.trim(sourceCode));
                    }
                    else {
                        coder.html($.trim(sourceCode));
                    }

                    modalIframe.contents().find('input[name="insert"]').bind('click', function () {

                        var code;

                        if (isSimpleTextarea == false) {
                            code = childWin.aceEditor.getSession().getValue();
                        }
                        else {
                            code = coder.val();
                        }

                        //replace raw script tags
                        code = code.replace(/<script[^>]*>[\S\s]*?<\/script\s*>/gi, function (match, offset) {
                            //check if found code is in attribute - IE does not encode tags in attribute values
                            var isInAttribute = false;
                            var preCode = code.substring(0, offset);
                            if (/=\s*"[^"]*$/.test(preCode) || /=\s*'[^']*$/.test(preCode)) {
                                isInAttribute = true;
                            }
                            //do not replace tags in attribute values
                            if (!isInAttribute) {
                                var div = $('<div>')
                                    .addClass('moze-object')
                                    .addClass('moze-raw-script')
                                    .attr('contenteditable', 'false')
                                    .attr('data-code', match);
                                return div[0].outerHTML;
                            } else {
                                return match;
                            }
                        });

                        $.smartModalWindow().close();

                        editor
                            .html(code)
                            .focus();

                        base.prepareBrowserSpecificHtml();

                        base.isModified = true;
                        base.autosave();
                        base.observeObjects();

                    });
                },
                onClosed: function () {
                    editor.focus();
                }
            });
        },

        actionClearFormatting: function ()
        {
            var base = this;
            var html = $('<article>' + base.editor.html() + '</article>');

            var settings = {
                    img: {'src': 'src', 'alt': 'alt'},
                    a: {'href': 'href'}
                };

            if (base.config.wantsParagraphs) {
                var s = 'p, ';
            } else {
                var s = '';
            }

            // unwrap nested tags
            html.find('*').not(s + 'a, img, table, tbody, tr, td, th, h1, h2, h3, ul, ol, li, b, i, u, div.moze-object').children().unwrap();

            // unwrap what is left
            html.find('*').not(s + 'a, img, table, tbody, tr, td, th, h1, h2, h3, ul, ol, li, b, i, u, div.moze-object').each(function () {
                $(this).replaceWith($(this).html());
            });

            html.find('p, a, img, table, tbody, tr, td, th, h1, h2, h3, ul, ol, li, b, i, u').each(function () {
                if (this.attributes !== null) {
                    var tagName = $(this).prop('tagName').toLowerCase();
                    var useAttrFilter = (tagName in settings);
                    for (var i = this.attributes.length; i-- > 0; ) {
                        var attrName = this.attributes[i].nodeName;
                        if (useAttrFilter == true) {
                            if (attrName in settings[tagName] == false) {
                                $(this).removeAttr(attrName);
                            }
                        }
                        else {
                            $(this).removeAttr(attrName);
                        }
                    }
                }
            });

            base.editor.html(html.html());
            base.observeObjects();
            base.editor.focus();
            base.isModified = true;
            base.autosave();
        },

        actionImgAlign: function (justify)
        {
            var base = this;
            var image = base.imageSelected;

            if (image != null)
            {
                var classToApply = null;

                switch (justify) {
                    case 'left':
                        classToApply = 'moze-img-left';
                        break;
                    case 'center':
                        classToApply = 'moze-img-center';
                        break;
                    case 'right':
                        classToApply = 'moze-img-right';
                        break;
                }

                image.removeClass()
                if (classToApply != null) {
                    image.addClass(classToApply);
                }
            }

            base.relocateToolbars();
            base.editor.focus();
            base.isModified = true;
            base.autosave();
        },

        actionImgResize: function ()
        {
            var base = this;
            var image = base.imageSelected;

            if (image != null) {
                if (MozWysiwygGlobal.isResizeModeOn == false) {

                    var range = rangy.createRange();
                    range.selectNodeContents(image[0]);
                    var selection = rangy.getSelection();
                    selection.setSingleRange(range);

                    MozWysiwygGlobal.isResizeModeOn = true;
                    MozWysiwygGlobal.baseOfResizeMode = base;
                    MozWysiwygGlobal.imageOfResizeMode = image;

                    $('div.moze-wysiwyg-editor')
                        .attr('contenteditable', false)
                        .addClass('moze-no-select-border');

                    base.editor.addClass('moze-select-border');
                    base.editor.removeClass('moze-no-select-border'); // not for this one
                    base.turnOnExclusiveToolbarButtonMode(base.imageToolbar, 'imgresize');

                    var contm = false;
                    var maxW = false;
                    if (base.config.role == 'editor') {
                        //contm = base.editor;
                        maxW = base.editor.width();
                    }

                    base.imageSelected.resizable({
                        aspectRatio: true,
                        handles: 'se',
                        minHeight: 32,
                        minWidth: 32,
                        maxWidth: maxW,
                        containment: contm,
                        create: function (event, ui) {

                            var imgClass = null;

                            if (base.imageSelected.hasClass('moze-img-left') == true) {
                                imgClass = 'moze-img-left';
                            }
                            if (base.imageSelected.hasClass('moze-img-center') == true) {
                                imgClass = 'moze-img-center';
                            }
                            if (base.imageSelected.hasClass('moze-img-right') == true) {
                                imgClass = 'moze-img-right';
                            }

                            base.imageSelected.removeAttr('class');
                            base.imageResizingOldClass = imgClass;
                            $(event.target).addClass(imgClass);

                            var containerLayer = $(event.target);
                            var resImg = $(containerLayer.children("img"));

                            // create drag layer
                            resImg.after('<div id="mozello_image_resize_drag_layer" style="position: absolute; top: 0; left: 0;"></div>');
                            var dragLayer = $("#mozello_image_resize_drag_layer");
                            dragLayer.css("width", resImg.css("width"));
                            dragLayer.css("height", resImg.css("height"));

                            // create visual selection overlay
                            resImg.after('<div id="mozello_image_resize_overlay" style="position: absolute; top: 0; left: 0;"></div>');
                            $("#mozello_image_resize_overlay").css("width", resImg.outerWidth());
                            $("#mozello_image_resize_overlay").css("height", resImg.outerHeight());

                            // set up drag layer
                            dragLayer.draggable({
                                start: function (event, ui) {
                                    ui.helper.imgStartWidth = resImg.width();
                                    ui.helper.imgStartHeight = resImg.height();
                                },
                                drag: function (event, ui) {
                                    var new_width = (ui.helper.imgStartWidth + ui.position.left);
                                    if (new_width < 32) {
                                        new_width = 32;
                                    } else if (maxW && new_width > base.editor.width()) {
                                        new_width = base.editor.width();
                                    }

                                    var new_height = (ui.helper.imgStartHeight + ui.position.top);
                                    if (new_height < 32) {
                                        new_height = 32;
                                    }

                                    var new_height_related = Math.round(new_width * ui.helper.imgStartHeight / ui.helper.imgStartWidth);
                                    var new_width_related = Math.round(new_height * ui.helper.imgStartWidth / ui.helper.imgStartHeight);

                                    if (new_height > new_height_related) {
                                        new_height = new_height_related;
                                    } else {
                                        new_width = new_width_related;
                                    }

                                    containerLayer.css("width", new_width + "px");
                                    containerLayer.css("height", new_height + "px");
                                    resImg.css("width", new_width + "px");
                                    resImg.css("height", new_height + "px");
                                    $("#mozello_image_resize_overlay").css("width", resImg.outerWidth());
                                    $("#mozello_image_resize_overlay").css("height", resImg.outerHeight());

                                },
                                stop: function (event, ui) {
                                    dragLayer.css("left", 0);
                                    dragLayer.css("top", 0);
                                    dragLayer.css("width", resImg.css("width"));
                                    dragLayer.css("height", resImg.css("height"));
                                }
                            });
                        },
                        resize: function (event, ui)
                        {
                            $("#mozello_image_resize_overlay").css("width", $(event.target).outerWidth());
                            $("#mozello_image_resize_overlay").css("height", $(event.target).outerHeight());
                        },
                        stop: function (event, ui)
                        {
                            $("#mozello_image_resize_drag_layer").css("width", $(event.target).outerWidth());
                            $("#mozello_image_resize_drag_layer").css("height", $(event.target).outerHeight());
                        }

                    });

                    function cancelImgResize(e) {
                        if (MozWysiwygGlobal.baseOfResizeMode != null) {
                            MozWysiwygGlobal.baseOfResizeMode.imageSelected = MozWysiwygGlobal.imageOfResizeMode;
                            MozWysiwygGlobal.baseOfResizeMode.observeObjects();
                            MozWysiwygGlobal.baseOfResizeMode.actionImgResize();
                        }
                        return false;
                    }

                    $(document).one('click', cancelImgResize);
                    $(document).one('touchend', cancelImgResize);
                }
                else
                {
                    $('div.moze-wysiwyg-editor')
                        .attr('contenteditable', true)
                        .removeClass('moze-no-select-border');

                    base.editor.removeClass('moze-select-border');
                    base.turnOffExclusiveToolbarButtonMode(base.imageToolbar);

                    base.imageSelected.resizable('destroy');

                    var deltaHeight =
                        parseInt(base.imageSelected.css('padding-top')) +
                        parseInt(base.imageSelected.css('padding-bottom')) +
                        parseInt(base.imageSelected.css('border-top-width')) +
                        parseInt(base.imageSelected.css('border-bottom-width'));

                    var deltaWidth =
                        parseInt(base.imageSelected.css('padding-left')) +
                        parseInt(base.imageSelected.css('padding-right')) +
                        parseInt(base.imageSelected.css('border-left-width')) +
                        parseInt(base.imageSelected.css('border-right-width'));

                    // if resized to full width, use 100%
                    var newWidth;
                    if (base.config.role == 'editor' && base.imageSelected.outerWidth() >= base.editor.width()) {
                        newWidth = "100%";
                    }
                    else {
                        newWidth = base.imageSelected.width() - deltaWidth;
                    }

                    var newImage = $('<img>')
                        .attr('src', base.imageSelected.attr('src'))
                        .attr('class', base.imageSelected.attr('class'))
                        .css('width', newWidth);

                    // for ie that adds these
                    newImage.removeAttr("width");
                    newImage.removeAttr("height");

                    if (base.imageResizingOldClass != null)
                    {
                        newImage.addClass(base.imageResizingOldClass);
                        base.imageResizingOldClass = null;
                    }

                    base.imageSelected.replaceWith(newImage);
                    base.imageSelected = newImage;

                    base.observeObjects();
                    base.showToolbar();

                    base.editor.blur(); // necessary for ios
                    base.editor.focus();

                    MozWysiwygGlobal.isResizeModeOn = false;
                    MozWysiwygGlobal.baseOfResizeMode = null;
                    MozWysiwygGlobal.imageOfResizeMode = null;

                    base.isModified = true;
                    base.autosave();

                }
            }
        },

        actionImgProperties: function ()
        {
            var base = this;
            var image = base.imageSelected;

            if (image != null) {

                var parent = image.parent('a');

                var oldTitle = (typeof image.attr('alt') !== 'undefined') ? image.attr('alt') : '';
                var oldHref = '';
                var oldTarget = '';

                if (parent.length !== 0) {
                    oldHref = (typeof parent.attr('href') !== 'undefined') ? parent.attr('href') : '';
                    oldTarget = (typeof parent.attr('target') !== 'undefined') ? parent.attr('target') : '';
                }

                $.smartModalWindow({
                    height: '420px',
                    href: '/m/wysiwyg-imageprops/',
                    width: '600px',
                    onComplete: function () {

                        var modalIframe =  $('#modal-iframe');
                        var childWin = modalIframe.get(0).contentWindow;
                        childWin.loadData(oldHref, oldTarget, oldTitle);

                        modalIframe.contents().find('input[name="img_title"]').focus();
                        modalIframe.contents().find('input[name="insert"]').click(function () {

                            var newTitle = modalIframe.contents().find('input[name="img_title"]').val();
                            var newHref = modalIframe.contents().find('input[name="link_href"]').val();
                            var newTarget = modalIframe.contents().find('select[name="link_target"]').val();

                            $.smartModalWindow().close();
                            base.editor.focus();

                            image.attr('alt', newTitle);

                            if (newHref != '') {
                                newHref = base.normalizeLink(newHref);
                                if (parent.length !== 0) {
                                    parent.attr('href', newHref);
                                    if (newTarget != '') {
                                        parent.attr('target', newTarget);
                                    }
                                }
                                else {
                                    parent = $('<a>').attr('href', newHref);
                                    if (newTarget != '') {
                                        parent.attr('target', newTarget);
                                    }
                                    image.wrap(parent);
                                }
                            }
                            else {
                                if (parent.length !== 0) {
                                    parent.replaceWith(image);
                                }
                            }

                            base.editor.focus();
                            base.isModified = true;
                            base.autosave();

                        });
                    },
                    onClosed: function() {
                        base.editor.focus();
                    }

                });
            }
            else {
                base.editor.focus();
                base.isModified = true;
                base.autosave();
            }
        },

        actionImgDelete: function ()
        {
            var base = this;

            if (base.imageSelected != null) {
                base.imageSelected.remove();
                base.imageSelected = null;
            }

            base.hideImageToolbar();
            base.showToolbar();
            base.editor.focus();
        },

        actionIframeResize: function ()
        {
            var base = this;
            var iframe = base.iframeSelected;

            if (iframe != null) {

                if (MozWysiwygGlobal.isResizeModeOn == false) {

                    MozWysiwygGlobal.isResizeModeOn = true;
                    MozWysiwygGlobal.baseOfResizeMode = base;
                    MozWysiwygGlobal.iframeOfResizeMode = iframe;

                    $('div.moze-wysiwyg-editor')
                        .attr('contenteditable', false)
                        .addClass('moze-no-select-border');

                    base.editor.addClass('moze-select-border');
                    base.editor.removeClass('moze-no-select-border');
                    base.turnOnExclusiveToolbarButtonMode(base.iframeToolbar, 'iframeresize');

                    var keepAspect = base.iframeSelected.hasClass('moze-iframe');
                    var contm = false;
                    if (base.config.role == 'editor')
                        contm = base.editor;

                    base.iframeSelected.resizable({
                        aspectRatio: keepAspect,
                        handles: 'se',
                        minHeight: 32,
                        minWidth: 32,
                        containment: contm,
                        create: function (event, ui) {

                            var imgClass = null;

                            var containerLayer = $(event.target);
                            var resizeHandle = $(containerLayer.children("div"));

                            // create visual selection overlay
                            resizeHandle.before('<div id="mozello_image_resize_overlay" style="position: absolute; top: 0; left: 0;"></div>');
                            $("#mozello_image_resize_overlay").css("width", containerLayer.outerWidth());
                            $("#mozello_image_resize_overlay").css("height", containerLayer.outerHeight());

                            // create drag layer
                            resizeHandle.before('<div id="mozello_image_resize_drag_layer" style="position: absolute; top: 0; left: 0;"></div>');
                            var dragLayer = $("#mozello_image_resize_drag_layer");
                            dragLayer.css("width", containerLayer.css("width"));
                            dragLayer.css("height", containerLayer.css("height"));

                            // set-up drag layer
                            dragLayer.draggable({
                                start: function (event, ui) {
                                    ui.helper.imgStartWidth = containerLayer.width();
                                    ui.helper.imgStartHeight = containerLayer.height();
                                },
                                drag: function (event, ui) {
                                    var new_width = (ui.helper.imgStartWidth + ui.position.left);
                                    if (new_width < 32) {
                                        new_width = 32;
                                    }

                                    var new_height = (ui.helper.imgStartHeight + ui.position.top);
                                    if (new_height < 32) {
                                        new_height = 32;
                                    }

                                    if (keepAspect) {
                                        var new_height_related = Math.round(new_width * ui.helper.imgStartHeight / ui.helper.imgStartWidth);
                                        var new_width_related = Math.round(new_height * ui.helper.imgStartWidth / ui.helper.imgStartHeight);
                                        if (new_height < new_height_related) {
                                            new_height = new_height_related;
                                        } else {
                                            new_width = new_width_related;
                                        }
                                    }

                                    containerLayer.css("width", new_width + "px");
                                    containerLayer.css("height", new_height + "px");
                                    //dragLayer.css("width", containerLayer.css("width"));
                                    //dragLayer.css("height", containerLayer.css("height"));

                                    // resize selection overlay
                                    $("#mozello_image_resize_overlay").css("width", containerLayer.outerWidth());
                                    $("#mozello_image_resize_overlay").css("height", containerLayer.outerHeight());
                                },
                                stop: function (event, ui) {
                                    dragLayer.css("left", 0);
                                    dragLayer.css("top", 0);
                                    dragLayer.css("width", containerLayer.css("width"));
                                    dragLayer.css("height", containerLayer.css("height"));
                                }
                            });
                        },
                        resize: function (event, ui)
                        {
                            // resize selection overlay
                            $("#mozello_image_resize_overlay").css("width", $(event.target).outerWidth());
                            $("#mozello_image_resize_overlay").css("height", $(event.target).outerHeight());
                        },
                        stop: function (event, ui)
                        {
                            $("#mozello_image_resize_drag_layer").css("width", $(event.target).outerWidth());
                            $("#mozello_image_resize_drag_layer").css("height", $(event.target).outerHeight());
                        }

                    });

                    function cancelIframeResize(e) {
                        if (MozWysiwygGlobal.baseOfResizeMode != null) {
                            MozWysiwygGlobal.baseOfResizeMode.iframeSelected = MozWysiwygGlobal.iframeOfResizeMode;
                            MozWysiwygGlobal.baseOfResizeMode.observeObjects();
                            MozWysiwygGlobal.baseOfResizeMode.actionIframeResize();
                        }
                        return false;
                    }

                    $(document).one('click', cancelIframeResize);
                    $(document).one('touchend', cancelIframeResize);

                }
                else
                {
                    $('div.moze-wysiwyg-editor')
                        .attr('contenteditable', true)
                        .removeClass('moze-no-select-border');

                    base.editor.removeClass('moze-select-border');
                    base.turnOffExclusiveToolbarButtonMode(base.iframeToolbar);

                    base.iframeSelected.resizable('destroy');

                    // if resized to full width, use 100%
                    if (base.config.role == 'editor' && base.iframeSelected.outerWidth() >= base.editor.width()) {
                        var newWidth = "100%";
                    } else {
                        var newWidth = base.iframeSelected.width();
                    }

                    if (base.iframeSelected.hasClass('moze-iframe')) {
                        var newIframe = $('<div>')
                            .attr('class', 'moze-iframe')
                            .addClass('moze-object')
                            .css('height', base.iframeSelected.height())
                            .css('width', newWidth)
                            .data('src', base.iframeSelected.data('src'))
                            .attr('data-src', base.iframeSelected.data('src'));

                    }
                    else if (base.iframeSelected.hasClass('moze-maps')) {
                        var newIframe = $('<div>')
                            .attr('class', 'moze-maps')
                            .addClass('moze-object')
                            .css('height', base.iframeSelected.height())
                            .css('width', newWidth)
                            .data('lat', base.iframeSelected.data('lat'))
                            .data('lng', base.iframeSelected.data('lng'))
                            .data('zoom', base.iframeSelected.data('zoom'))
                            .attr('data-lat', base.iframeSelected.data('lat'))
                            .attr('data-lng', base.iframeSelected.data('lng'))
                            .attr('data-zoom', base.iframeSelected.data('zoom'));
                    }

                    base.iframeSelected.replaceWith(newIframe);
                    base.iframeSelected = newIframe;

                    base.observeObjects();
                    base.showToolbar();

                    base.editor.blur();
                    base.editor.focus();

                    MozWysiwygGlobal.isResizeModeOn = false;
                    MozWysiwygGlobal.baseOfResizeMode = null;
                    MozWysiwygGlobal.iframeOfResizeMode = null;

                    base.isModified = true;
                    base.autosave();
                }
            }
        },

        actionIframeDelete: function ()
        {
            var base = this;

            if (base.iframeSelected != null) {
                base.iframeSelected.remove();
                base.iframeSelected = null;
            }

            base.hideIframeToolbar();
            base.showToolbar();
            base.editor.focus();
            base.isModified = true;
            base.autosave();
        },

        // Word tag cleaner
        cleanPastedContent: function ()
        {
            var base = this;
            base.editor.css('cursor', 'wait');

            // remove comments, mostly for MS Office spam
            base.editor.contents().filter(function () {
                return this.nodeType == 8;
            }).remove();
            // nested comment cleanup
            base.editor.find('*').each(function () {
                $(this).contents().filter(function () {
                    return this.nodeType == 8;
                }).remove();
            });
            // unwrap all, also nested font tags
            base.editor.find('font').children().unwrap();
            // strip inline styles
            base.editor.find('p, span, table, tr, th, td, i, b, strong, u, a, div, h1, h2, h3').each(function () {
                $(this).css('color', '');
                $(this).css('background-color', '');
                $(this).css('background', '');
                $(this).css('border', '');
                $(this).css('font-size', '');
                $(this).css('font-family', '');
                $(this).css('font', '');
                $(this).css('margin', '');
                $(this).css('padding', '');
                $(this).css('text-indent', '');
                // strip office class names
                $(this).removeClass('MsoNormal').removeClass('MsoBodyText');
                // prevent paste of system divs
                if ($(this).prop('tagName').toLowerCase() == 'div') {
                    $(this).removeClass('mz_component mz_wysiwyg mz_editable moze-wysiwyg-editor fullwidth column-1-2 column-1-3');
                    if (!$(this).hasClass('moze-object')) {
                        $(this).css('float', '');
                        $(this).css('clear', '');
                        $(this).css('width', '');
                        $(this).css('height', '');
                    }
                }
            });
            // Word tables
            base.editor.find('table.MsoTableGrid').each(function () {
                $(this).removeAttr('style');
                $(this).removeAttr('cellspacing');
                $(this).removeAttr('cellpadding');
                $(this).removeAttr('width');
                $(this).removeAttr('align');
                // find tr tags
                $(this).find('tr').each(function () {
                    $(this).removeAttr('style');
                    // find td tags
                    $(this).find('td').each(function () {
                        $(this).removeAttr('style');
                        $(this).removeAttr('valign');
                        $(this).removeAttr('width');
                        // find p tags
                        $(this).find('p').each(function () {
                            $(this).replaceWith($(this).html());
                        });
                    });
                });
            });
            // strip table borders
            base.editor.find('table').each(function () {
                $(this).removeAttr('border');
            });
            // strip images copied from word
            base.editor.find('img[src]').each(function () {
                if ($(this).attr('src').match(/^file:/i)) {
                    $(this).remove();
                }
            });
            // strip skype nonsense
            base.editor.find('.skype_c2c_container, .skype_pnh_container').remove();
            base.editor.find('span.skype_c2c_print_container, span[class^="skype_pnh_print_container"]').each(function () {
                $(this).replaceWith($(this).text());
            });

            base.editor.css('cursor', '');
        },

        // Font attribute detection
        reportColourAndFontSize: function () {

            function getComputedStyleProperty(el, propName) {
                if (window.getComputedStyle) {
                    return window.getComputedStyle(el, null)[propName];
                } else if (el.currentStyle) {
                    return el.currentStyle[propName];
                }
            }

            var containerEl, sel;
            if (window.getSelection) {
                sel = window.getSelection();
                if (sel.rangeCount) {
                    containerEl = sel.getRangeAt(0).commonAncestorContainer;
                    // Make sure we have an element rather than a text node
                    if (containerEl.nodeType == 3) {
                        containerEl = containerEl.parentNode;
                    }
                }
            } else if ((sel = document.selection) && sel.type != "Control") {
                containerEl = sel.createRange().parentElement();
            }

            if (containerEl) {
                var fontSize = getComputedStyleProperty(containerEl, "fontSize");
                var colour = getComputedStyleProperty(containerEl, "color");
                return {"color": colour, "size": fontSize}
            }

            return false;

        },

        appendHiddenMarkers: function(s) {
            s = s.replace(/[\u200B]/g,'');
            return '&#8203;' + s + '&#8203;';
        },

        stripHiddenMarkers: function(s) {
            s = s.replace(/[\u200B]/g,'');
            return s;
        },

        // Non-rangy text insertion
        pasteHtmlAtCaret: function (html, selectPastedContent) {
            var sel, range;
            if (window.getSelection) {
                // IE9 and non-IE
                sel = window.getSelection();
                if (sel.getRangeAt && sel.rangeCount) {
                    range = sel.getRangeAt(0);
                    range.deleteContents();

                    // Range.createContextualFragment() would be useful here but is
                    // only relatively recently standardized and is not supported in
                    // some browsers (IE9, for one)
                    var el = document.createElement("div");
                    el.innerHTML = html;
                    var frag = document.createDocumentFragment(), node, lastNode;
                    while ((node = el.firstChild)) {
                        lastNode = frag.appendChild(node);
                    }
                    var firstNode = frag.firstChild;
                    range.insertNode(frag);

                    // Preserve the selection
                    if (lastNode) {
                        range = range.cloneRange();
                        range.setStartAfter(lastNode);
                        if (selectPastedContent) {
                            range.setStartBefore(firstNode);
                        } else {
                            range.collapse(true);
                        }
                        sel.removeAllRanges();
                        sel.addRange(range);
                    }
                }
            }
        },

        // Non-rangy selection save and restore methods, might come in useful at some point
        saveEditorSelection: function ()
        {
            if (!$('body').hasClass('touch-mode') || isiOS())
                return false; // use only for non-iOS mobiles
            var base = this;
            if (window.getSelection) { //non IE Browsers
                base.savedRange = window.getSelection().getRangeAt(0);
            } else if (document.selection) { //IE
                base.savedRange = document.selection.createRange();
            }
        },

        restoreEditorSelection: function ()
        {
            if (!$('body').hasClass('touch-mode') || isiOS()) {
                return false; // use only for non-iOS mobiles
            }
            var base = this;
            isInFocus = true;
            base.editor.focus();
            if (base.savedRange != null) {
                if (window.getSelection) {
                    //non IE and there is already a selection
                    var s = window.getSelection();
                    if (s.rangeCount > 0) {
                        s.removeAllRanges();
                    }
                    s.addRange(base.savedRange);
                }
                else if (document.createRange) {
                    //non IE and no selection
                    window.getSelection().addRange(base.savedRange);
                }
                else if (document.selection) {
                    //IE
                    base.savedRange.select();
                }
            }
        }
    };

    /* Main Entry Point */

    $.fn.mozwysiwyg = function (options) {
        return this.each(function () {
            new MozWysiwyg(this, options).init();
        });
    };

    /* End */

})(window, jQuery);

jQuery.mozwysiwyginit = function() {
    $('.mz_wysiwyg').mozwysiwyg({
        autosaveCallback: function (cid, name, value, keyname) {
            var alias = location.hostname;
            alias = alias.slice(0, alias.indexOf('.mozello.'));
            $.ajax({
                url: '/m/wysiwyg-do-save/' + 'params/' + alias + '/' + value.length + '/' + cid + '/',
                type: 'post',
                data: {
                    cid: cid,
                    name: name,
                    value: value,
                    keyname: keyname
                }
            });
        },
        autosaveEnabled: true,
        saveButton: $('div#mz_topbar a.save'),
        toolbarDefaultPos: 'left'
    });
};