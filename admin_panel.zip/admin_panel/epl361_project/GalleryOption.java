package epl361_project;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.SwingConstants;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class GalleryOption extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					GalleryOption frame = new GalleryOption();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public GalleryOption() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JButton btnAvailableDogList = new JButton("Available Dog List");
		btnAvailableDogList.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new TabsGalleryDog().setVisible(true);
			}
		});
		btnAvailableDogList.setBounds(136, 89, 140, 53);
		contentPane.add(btnAvailableDogList);
		
		JButton btnAvailableCatList = new JButton("Available Cat List");
		btnAvailableCatList.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new TabsGallery().setVisible(true);
			}
		});
		btnAvailableCatList.setBounds(136, 176, 140, 53);
		contentPane.add(btnAvailableCatList);
		
		JLabel lblAnimalsGallery = new JLabel("Animals Gallery");
		lblAnimalsGallery.setHorizontalAlignment(SwingConstants.CENTER);
		lblAnimalsGallery.setFont(new Font("Times New Roman", Font.BOLD, 15));
		lblAnimalsGallery.setBounds(44, 11, 332, 33);
		contentPane.add(lblAnimalsGallery);
		
		JButton btnGoBack = new JButton("Go Back ");
		btnGoBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
				new Main().setVisible(true);
			}
		});
		btnGoBack.setBounds(335, 227, 89, 23);
		contentPane.add(btnGoBack);
	}
}
