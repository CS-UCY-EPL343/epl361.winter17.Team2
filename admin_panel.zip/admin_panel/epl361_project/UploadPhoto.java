package epl361_project;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JLabel;
import javax.swing.JTextField;
import java.awt.event.ActionListener;
import java.io.File;
import java.awt.event.ActionEvent;

public class UploadPhoto extends JFrame {

	private JPanel contentPane;
	private JTextField textField;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					UploadPhoto frame = new UploadPhoto();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public UploadPhoto() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JButton btnAttachAPhoto = new JButton("Save Post");
		btnAttachAPhoto.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
				Tabs win=new Tabs();
				win.setVisible(true);
				
			}
		});
		btnAttachAPhoto.setBounds(172, 172, 105, 37);
		contentPane.add(btnAttachAPhoto);
		
		JLabel lblGiveName = new JLabel("Give Name");
		lblGiveName.setBounds(31, 124, 111, 30);
		contentPane.add(lblGiveName);
		
		textField = new JTextField();
		textField.setBounds(20, 172, 124, 37);
		contentPane.add(textField);
		textField.setColumns(10);
	}
}
