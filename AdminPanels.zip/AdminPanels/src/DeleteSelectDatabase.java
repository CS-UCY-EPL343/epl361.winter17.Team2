import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.AbstractListModel;
import java.awt.Color;
import javax.swing.JButton;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Button;
import javax.swing.ImageIcon;

public class DeleteSelectDatabase {

	private JFrame frame;

	/**
	 * Launch the application.
	 */
	private DeleteFromAnimalsOfTheOrganization deleteFromAnimals;
	private DeleteFromParticipants deleteFromP;
	public static void SelectTable(String username) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					DeleteSelectDatabase window = new DeleteSelectDatabase(username);
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public DeleteSelectDatabase(String Username) {
		initialize(Username);
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize(String username) {
		frame = new JFrame();
		frame.getContentPane().setBackground(Color.WHITE);
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblSelectATable = new JLabel("Select A Table from Below");
		lblSelectATable.setFont(new Font("Comic Sans MS", Font.BOLD, 12));
		lblSelectATable.setForeground(Color.RED);
		lblSelectATable.setBounds(149, 28, 178, 14);
		frame.getContentPane().add(lblSelectATable);
		
		JList list = new JList();
		list.setFont(new Font("Comic Sans MS", Font.BOLD, 13));
		list.setForeground(Color.RED);
		list.setModel(new AbstractListModel() {
			String[] values = new String[] {"1. All animals Of the Organization", "2. Participants",  "3. Report for stray Animal"};
			public int getSize() {
				return values.length;
			}
			public Object getElementAt(int index) {
				return values[index];
			}
		});
		list.setBounds(35, 72, 292, 89);
		frame.getContentPane().add(list);
		
		JButton btnSelectTable = new JButton("Select Table");
		btnSelectTable.setForeground(Color.RED);
		btnSelectTable.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String selection=null;
				if(list.getSelectedValue()!=null) {
				selection=list.getSelectedValue().toString();
					if(selection.compareTo("1. All animals Of the Organization")==0 ) {
						deleteFromAnimals.delete(username);
						frame.setVisible(false);

					}
					else if(selection.compareTo("2. Participants")==0) {
						deleteFromP.delete(username);
						frame.setVisible(false);

					}
				
					else if(selection.compareTo("3. Report for stray Animal")==0) {
						DeleteReport.delete(username);
						frame.setVisible(false);
					}
				}
				else {
					JOptionPane.showMessageDialog(null, "Please select a Table");
					}
				
				}
			}
		
			
			
		
			);
		
	
		btnSelectTable.setFont(new Font("Comic Sans MS", Font.BOLD, 12));
		btnSelectTable.setBounds(157, 172, 131, 23);
		frame.getContentPane().add(btnSelectTable);
		
		Button button = new Button("<- Go Back");
		button.setFont(new Font("Comic Sans MS", Font.BOLD, 12));
		button.setForeground(Color.BLACK);
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				DB_initialView.DBmain(username);
			}
		});
		button.setBounds(0, 0, 70, 22);
		frame.getContentPane().add(button);
		
		JLabel label = new JLabel("");
		label.setIcon(new ImageIcon(DeleteSelectDatabase.class.getResource("/images/23721782_1771329182908750_1673673037_n.jpg")));
		label.setBounds(316, 11, 108, 76);
		frame.getContentPane().add(label);
		
		
		}
}
		
