
	import java.awt.Color;
	import java.awt.EventQueue;
	import java.awt.event.ActionEvent;
	import java.awt.event.ActionListener;

	import javax.swing.JButton;
	import javax.swing.JFrame;
	import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTable;
	import javax.swing.table.DefaultTableModel;
	import javax.swing.table.TableRowSorter;
	import java.awt.Button;
import java.awt.Font;
import javax.swing.ImageIcon;

	
public class DeleteReport{
		private JFrame frame;
		private JTable table;
		private DefaultTableModel dm;
		/**
		 * Launch the application.
		 */
		public static void delete(String Username) {
			EventQueue.invokeLater(new Runnable() {
				public void run() {
					try {
						DeleteReport window = new DeleteReport(Username);
						window.frame.setVisible(true);
					} catch (Exception e) {
						e.printStackTrace();
					}
				}
			});
		}

		/**
		 * Create the application.
		 */
		public DeleteReport(String username) {
			initialize(username);
		}

		/**
		 * Initialize the contents of the frame.
		 */
		private void initialize(String Username ) {
			frame = new JFrame();
			frame.getContentPane().setBackground(Color.WHITE);
			frame.setBounds(100, 100, 529, 323);
			frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			frame.getContentPane().setLayout(null);
			
			table = new JTable();
			table.setForeground(Color.BLACK);
			//Add columns
			dm=(DefaultTableModel) table.getModel();
			dm.addColumn("Ref. No");
			dm.addColumn("Name");
			dm.addColumn("Surname");
			dm.addColumn("Phone Number");
			dm.addColumn("Email");
			dm.addColumn("Location Found");
			dm.addColumn("Type");
			dm.addColumn("Gender");
			dm.addColumn("Estimated Age");
			dm.addColumn("Has Chip");
			dm.addColumn("Comments");



			//Add rows
			String[] Row={"Ref. No", "Name","Surname", "Phone Number", "Email", "Location Found","Type","Gender","Estimated Age","Has Chip","Comments"};
			dm.addRow(Row);
			String[]Row1= {"189", "Eleftheria", "Kouppari", "999999", "eleftheriakouppari@yahoo.com","University of Cyprus","Cat","Female","10","No","N/A"};
			dm.addRow(Row1);
			String[]Row2= {"190", "Pantelina", "Ioannou", "9888888", "pantelinaioannou@yahoo.com","University of Cyprus","Dog","Female","5","No","N/A"};
			dm.addRow(Row2);
			String[]Row3= {"189", "Kristia", "Charilaou", "9777777", "kristiacharilaou@yahoo.com","University of Cyprus","Bird","Don't Know","10","No","N/A"};
			dm.addRow(Row3);

			
			TableRowSorter<DefaultTableModel> tr=new TableRowSorter<DefaultTableModel>(dm);
			table.setRowSorter(tr);
			
			
			table.setBounds(10, 36, 493, 154);
			frame.getContentPane().add(table);
			
			JButton btnDelet = new JButton("Delete");
			btnDelet.setFont(new Font("Comic Sans MS", Font.BOLD, 12));
			btnDelet.setForeground(Color.RED);
			btnDelet.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					if(table.getSelectedRow()!=-1)
					dm.removeRow(table.getSelectedRow());
					else
						JOptionPane.showMessageDialog(null, "Please select a record");
				}
			});
			btnDelet.setBounds(218, 250, 89, 23);
			frame.getContentPane().add(btnDelet);
			
			JLabel lblDeleteFromTable = new JLabel("Delete a Report of stray Dog");
			lblDeleteFromTable.setFont(new Font("Comic Sans MS", Font.BOLD, 12));
			lblDeleteFromTable.setForeground(Color.RED);
			lblDeleteFromTable.setBounds(181, 11, 190, 14);
			frame.getContentPane().add(lblDeleteFromTable);
			
			Button button = new Button("<- Go Back");
			button.setFont(new Font("Comic Sans MS", Font.BOLD, 12));
			button.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					DeleteSelectDatabase.SelectTable(Username);
					frame.setVisible(false);
				}
			});
			button.setBounds(0, 0, 70, 22);
			frame.getContentPane().add(button);
			
			JLabel label = new JLabel("");
			label.setIcon(new ImageIcon(DeleteReport.class.getResource("/images/23721782_1771329182908750_1673673037_n.jpg")));
			label.setBounds(391, 196, 112, 77);
			frame.getContentPane().add(label);
		}
		}

