import java.awt.Color;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.SwingConstants;
import javax.swing.JComboBox;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Select_Table {

	private JFrame frame;

	/**
	 * Launch the application.
	 */
	public static void selectTable(String Username) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Select_Table window = new Select_Table(Username);
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Select_Table(String Username) {
		initialize(Username);
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize(String Username) {
		frame = new JFrame();
		frame.setBounds(100, 100, 428, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblDatabaseTables = new JLabel("Database Tables");
		lblDatabaseTables.setFont(new Font("Comic Sans MS", Font.BOLD, 13));
		lblDatabaseTables.setHorizontalAlignment(SwingConstants.CENTER);
		lblDatabaseTables.setBounds(10, 11, 392, 24);
		frame.getContentPane().add(lblDatabaseTables);
		
		JLabel lblPleaseSelectA = new JLabel("Please select a table:");
		lblPleaseSelectA.setFont(new Font("Comic Sans MS", Font.BOLD, 12));
		lblPleaseSelectA.setBounds(10, 46, 132, 24);
		frame.getContentPane().add(lblPleaseSelectA);
		
		JButton btnAnimalsTable = new JButton("Animal's Table");
		btnAnimalsTable.setFont(new Font("Comic Sans MS", Font.BOLD, 11));
		btnAnimalsTable.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				View_Animals_Table.view(Username);
				frame.setVisible(false);
			}
		});
		btnAnimalsTable.setForeground(Color.RED);
		btnAnimalsTable.setBounds(10, 97,171, 23);
		frame.getContentPane().add(btnAnimalsTable);
		
		JButton btnNewButton = new JButton("Stray Animal's Table");
		btnNewButton.setFont(new Font("Comic Sans MS", Font.BOLD, 11));
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				View_Stray_Animals_Table.view(Username);
				frame.setVisible(false);
			}
		});
		btnNewButton.setForeground(Color.RED);
		btnNewButton.setBounds(10, 147, 171, 23);
		frame.getContentPane().add(btnNewButton);
		
		JButton btnEventParticipantsTable = new JButton("Event Participants Table");
		btnEventParticipantsTable.setFont(new Font("Comic Sans MS", Font.BOLD, 11));
		btnEventParticipantsTable.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				View_Event_Participants_Table.view(Username);
				frame.setVisible(false);
			}
		});
		btnEventParticipantsTable.setForeground(Color.RED);
		btnEventParticipantsTable.setBounds(10, 200, 171, 23);
		frame.getContentPane().add(btnEventParticipantsTable);
		
		JButton btnNewButton_1 = new JButton("Request for a Dog Table");
		btnNewButton_1.setFont(new Font("Comic Sans MS", Font.BOLD, 11));
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				View_Request_Dog.view(Username);
				frame.setVisible(false);
			}
		});
		btnNewButton_1.setForeground(Color.red);
		btnNewButton_1.setBounds(231, 97, 171, 23);
		frame.getContentPane().add(btnNewButton_1);
		
		JButton btnRequestForA = new JButton("Request for a Cat Table");
		btnRequestForA.setFont(new Font("Comic Sans MS", Font.BOLD, 11));
		btnRequestForA.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				View_Request_Cat.view(Username);
				frame.setVisible(false);
			}
		});
		btnRequestForA.setForeground(Color.RED);
		btnRequestForA.setBounds(231, 148, 171, 23);
		frame.getContentPane().add(btnRequestForA);
		
		JButton btnExit = new JButton("Exit");
		btnExit.setFont(new Font("Comic Sans MS", Font.BOLD, 11));
		btnExit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.exit(0);
			}
		});
		btnExit.setForeground(Color.red);
		btnExit.setBounds(231, 200, 171, 23);
		frame.getContentPane().add(btnExit);
		
		JButton button = new JButton("<-Back");
		button.setFont(new Font("Comic Sans MS", Font.BOLD, 11));
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				DB_initialView.DBmain(Username);
				frame.setVisible(false);
			}
			
		});
		button.setBounds(0, 0, 89, 23);
		frame.getContentPane().add(button);
	}
}
