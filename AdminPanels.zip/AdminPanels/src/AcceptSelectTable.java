import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.BorderLayout;
import java.awt.Button;

import javax.swing.JButton;
import java.awt.Color;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Font;
import javax.swing.ImageIcon;

public class AcceptSelectTable {

	private JFrame frame;

	/**
	 * Launch the application.
	 */
	public static void accept(String username) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					AcceptSelectTable window = new AcceptSelectTable(username);
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public AcceptSelectTable(String Username) {
		initialize(Username);
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize(String username) {
		frame = new JFrame();
		frame.getContentPane().setBackground(Color.WHITE);
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel label = new JLabel("");
		label.setBounds(0, 0, 434, 0);
		frame.getContentPane().add(label);
		
		JButton btnNewButton = new JButton("Dogs Requests");
		btnNewButton.setFont(new Font("Comic Sans MS", Font.BOLD, 13));
		btnNewButton.setForeground(Color.RED);
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				AcceptDogRequests.accept(username);
				frame.setVisible(false);
			}
		});
		btnNewButton.setBounds(275, 107, 125, 23);
		frame.getContentPane().add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("Cats Requests");
		btnNewButton_1.setFont(new Font("Comic Sans MS", Font.BOLD, 11));
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				AcceptCatRequest.accept(username);
				frame.setVisible(false);
			}
		});
		btnNewButton_1.setForeground(Color.RED);
		btnNewButton_1.setBounds(275, 152, 125, 23);
		frame.getContentPane().add(btnNewButton_1);
		
		JLabel lblSelectATable = new JLabel("Select A Table From Were You would Like to Accept a request");
		lblSelectATable.setFont(new Font("Comic Sans MS", Font.BOLD | Font.ITALIC, 13));
		lblSelectATable.setForeground(Color.RED);
		lblSelectATable.setBounds(10, 34, 424, 33);
		frame.getContentPane().add(lblSelectATable);
		
		JButton button = new JButton("<-Go Back");
		button.setFont(new Font("Comic Sans MS", Font.BOLD, 12));
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				DB_initialView.DBmain(username);
				frame.setVisible(false);
			}
		});
		button.setBounds(0, 0, 105, 23);
		frame.getContentPane().add(button);
		
		JLabel label_1 = new JLabel("");
		label_1.setIcon(new ImageIcon(AcceptSelectTable.class.getResource("/images/23721782_1771329182908750_1673673037_n.jpg")));
		label_1.setBounds(50, 92, 125, 99);
		frame.getContentPane().add(label_1);
		
	}
}
