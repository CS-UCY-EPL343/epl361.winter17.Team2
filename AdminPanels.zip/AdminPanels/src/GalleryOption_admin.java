
import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.SwingConstants;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Color;

public class GalleryOption_admin extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void gallery_option_a(String Username) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					GalleryOption_admin frame = new GalleryOption_admin(Username);
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public GalleryOption_admin(String Username) {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBackground(Color.WHITE);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JButton btnAvailableDogList = new JButton("Available Dog List");
		btnAvailableDogList.setFont(new Font("Comic Sans MS", Font.BOLD, 12));
		btnAvailableDogList.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				TabsGalleryDog_admin.tabs_gallerydog_A(Username);
				contentPane.setVisible(false);
			}
		});
		btnAvailableDogList.setBounds(137, 80, 140, 53);
		contentPane.add(btnAvailableDogList);
		
		JButton btnAvailableCatList = new JButton("Available Cat List");
		btnAvailableCatList.setFont(new Font("Comic Sans MS", Font.BOLD, 12));
		btnAvailableCatList.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				TabsGallery_admin.tabsgallery_admin(Username);
				contentPane.setVisible(false);
			}
		});
		btnAvailableCatList.setBounds(137, 144, 140, 53);
		contentPane.add(btnAvailableCatList);
		
		JLabel lblAnimalsGallery = new JLabel("Animals Gallery");
		lblAnimalsGallery.setForeground(new Color(165, 42, 42));
		lblAnimalsGallery.setHorizontalAlignment(SwingConstants.CENTER);
		lblAnimalsGallery.setFont(new Font("Comic Sans MS", Font.BOLD, 16));
		lblAnimalsGallery.setBounds(0, 0, 434, 33);
		contentPane.add(lblAnimalsGallery);
		
		JButton btnGoBack = new JButton("Go Back ");
		btnGoBack.setFont(new Font("Comic Sans MS", Font.BOLD, 12));
		btnGoBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
				 admin_webuser_administrator.admin_main(Username);;
			}
		});
		btnGoBack.setBounds(0, 0, 89, 23);
		contentPane.add(btnGoBack);
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(0, 0, 0));
		panel.setBounds(0, 39, 446, 10);
		contentPane.add(panel);
	}
}
