import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;

import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JSpinner;
import javax.swing.JTextField;
import javax.swing.SpinnerNumberModel;
import javax.swing.SwingConstants;
import javax.swing.filechooser.FileNameExtensionFilter;
import java.awt.Color;

public class Edit_Stray {

	private JFrame frame;
	private JTextField textField;
	private JTextField textField_1;
	private final JFileChooser openFileChooser;
	private JTextField textField_2;
	private JTextField textField_3;
	private JTextField textField_4;
	private JTextField textField_6;
	private JTextField textField_7;


	/**
	 * Launch the application.
	 */
	public static void EditStray(String Username) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Edit_Stray window = new Edit_Stray(Username);
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Edit_Stray(String Username) {
		initialize(Username);
		openFileChooser = new JFileChooser();
		openFileChooser.setCurrentDirectory(new File ("C:\\temp"));
		openFileChooser.setFileFilter(new FileNameExtensionFilter("PNG images", "png"));
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize(String Username) {
		frame = new JFrame();
		frame.getContentPane().setBackground(Color.WHITE);
		frame.setBounds(100, 100, 482, 482);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblEditupdateTable = new JLabel("Edit/Update a Table's Record");
		lblEditupdateTable.setForeground(Color.RED);
		lblEditupdateTable.setHorizontalAlignment(SwingConstants.CENTER);
		lblEditupdateTable.setFont(new Font("Comic Sans MS", Font.BOLD, 20));
		lblEditupdateTable.setBounds(10, 11, 446, 24);
		frame.getContentPane().add(lblEditupdateTable);
		
		JLabel lblSn = new JLabel("S/N : ");
		lblSn.setFont(new Font("Comic Sans MS", Font.BOLD, 10));
		lblSn.setBounds(20, 51, 40, 14);
		frame.getContentPane().add(lblSn);
		
		JSpinner spinner = new JSpinner();
		spinner.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		spinner.setModel(new SpinnerNumberModel(new Integer(1), new Integer(1), null, new Integer(1)));
		spinner.setBounds(57, 46, 40, 20);
		frame.getContentPane().add(spinner);
		
		JLabel lblAnimalsNumber = new JLabel("Name:");
		lblAnimalsNumber.setFont(new Font("Comic Sans MS", Font.BOLD, 10));
		lblAnimalsNumber.setBounds(116, 46, 40, 24);
		frame.getContentPane().add(lblAnimalsNumber);
		
		textField = new JTextField();
		textField.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		textField.setBounds(166, 48, 86, 20);
		frame.getContentPane().add(textField);
		textField.setColumns(10);
		
		JLabel lblNewLabel = new JLabel("Surname:");
		lblNewLabel.setFont(new Font("Comic Sans MS", Font.BOLD, 10));
		lblNewLabel.setBounds(275, 46, 53, 20);
		frame.getContentPane().add(lblNewLabel);
		
		JLabel lblAnimalType = new JLabel("Phone Number:");
		lblAnimalType.setFont(new Font("Comic Sans MS", Font.BOLD, 10));
		lblAnimalType.setBounds(20, 92, 86, 24);
		frame.getContentPane().add(lblAnimalType);
		
		JComboBox comboBox = new JComboBox();
		comboBox.setModel(new DefaultComboBoxModel(new String[] {"Please Select...", "Bird", "Dog", "Cat", "Other"}));
		comboBox.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		comboBox.setBounds(337, 140, 97, 20);
		frame.getContentPane().add(comboBox);
		
		JLabel lblNewLabel_1 = new JLabel("Picture:");
		lblNewLabel_1.setFont(new Font("Comic Sans MS", Font.BOLD, 10));
		lblNewLabel_1.setBounds(20, 368, 47, 19);
		frame.getContentPane().add(lblNewLabel_1);
		
		textField_1 = new JTextField();
		textField_1.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		textField_1.setBounds(77, 365, 261, 24);
		frame.getContentPane().add(textField_1);
		textField_1.setColumns(10);
		
		JButton btnNewButton = new JButton("Browse");
		btnNewButton.setForeground(Color.RED);
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JFileChooser file = new JFileChooser();
				file.setCurrentDirectory(new File(System.getProperty("user.home")));
				FileNameExtensionFilter filter = new FileNameExtensionFilter("*.Images","png","gif","jpg");
				file.addChoosableFileFilter(filter);
				int result = file.showSaveDialog(null);
				if(result == JFileChooser.APPROVE_OPTION){
					File selectedFile=file.getSelectedFile();
					String path = selectedFile.getAbsolutePath();
					textField_1.setText(path);
				}
				else if(result == JFileChooser.CANCEL_OPTION){
					System.out.println("No File Selected");
				}
			}
		});
		btnNewButton.setFont(new Font("Comic Sans MS", Font.BOLD, 10));
		btnNewButton.setBounds(348, 365, 86, 24);
		frame.getContentPane().add(btnNewButton);
		
		JLabel lblDateOfAdoption = new JLabel("Animal Gender:");
		lblDateOfAdoption.setFont(new Font("Comic Sans MS", Font.BOLD, 10));
		lblDateOfAdoption.setBounds(20, 190, 97, 20);
		frame.getContentPane().add(lblDateOfAdoption);
		
		textField_2 = new JTextField();
		textField_2.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		textField_2.setBounds(116, 94, 97, 20);
		frame.getContentPane().add(textField_2);
		textField_2.setColumns(10);
		
		JLabel lblMicrochip = new JLabel("Microchip:");
		lblMicrochip.setFont(new Font("Comic Sans MS", Font.BOLD, 10));
		lblMicrochip.setBounds(241, 191, 86, 19);
		frame.getContentPane().add(lblMicrochip);
		
		JComboBox comboBox_1 = new JComboBox();
		comboBox_1.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		comboBox_1.setModel(new DefaultComboBoxModel(new String[] {"Please Select...", "YES", "NO"}));
		comboBox_1.setBounds(337, 189, 106, 22);
		frame.getContentPane().add(comboBox_1);
		
		JLabel lblAdoptersName = new JLabel("Email Address:");
		lblAdoptersName.setFont(new Font("Comic Sans MS", Font.BOLD, 10));
		lblAdoptersName.setBounds(241, 97, 86, 14);
		frame.getContentPane().add(lblAdoptersName);
		
		textField_3 = new JTextField();
		textField_3.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		textField_3.setBounds(337, 94, 97, 20);
		frame.getContentPane().add(textField_3);
		textField_3.setColumns(10);
		
		JLabel lblAdoptersPhone = new JLabel("Location Found:");
		lblAdoptersPhone.setFont(new Font("Comic Sans MS", Font.BOLD, 10));
		lblAdoptersPhone.setBounds(20, 143, 86, 14);
		frame.getContentPane().add(lblAdoptersPhone);
		
		textField_4 = new JTextField();
		textField_4.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		textField_4.setBounds(116, 143, 97, 20);
		frame.getContentPane().add(textField_4);
		textField_4.setColumns(10);
		
		JLabel lblAdoptersEmail = new JLabel("Type of Animal:");
		lblAdoptersEmail.setFont(new Font("Comic Sans MS", Font.BOLD, 10));
		lblAdoptersEmail.setBounds(241, 143, 86, 14);
		frame.getContentPane().add(lblAdoptersEmail);
		
		JLabel lblComments = new JLabel("Comments:");
		lblComments.setFont(new Font("Comic Sans MS", Font.BOLD, 10));
		lblComments.setBounds(20, 281, 85, 20);
		frame.getContentPane().add(lblComments);
		
		textField_6 = new JTextField();
		textField_6.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		textField_6.setBounds(20, 312, 414, 42);
		frame.getContentPane().add(textField_6);
		textField_6.setColumns(10);
		
		JButton btnExit = new JButton("Exit");
		btnExit.setForeground(Color.RED);
		btnExit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.exit(0);
			}
		});
		btnExit.setFont(new Font("Comic Sans MS", Font.BOLD, 10));
		btnExit.setBounds(345, 409, 89, 23);
		frame.getContentPane().add(btnExit);
		
		JButton btnSave = new JButton("Save");
		btnSave.setForeground(Color.RED);
		btnSave.setFont(new Font("Comic Sans MS", Font.BOLD, 10));
		btnSave.setBounds(28, 409, 89, 23);
		frame.getContentPane().add(btnSave);
		
		JButton btnBack = new JButton("Back");
		btnBack.setForeground(Color.RED);
		btnBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				View_Stray_Animals_Table.view(Username);
				frame.setVisible(false);
			}
		});
		btnBack.setFont(new Font("Comic Sans MS", Font.BOLD, 10));
		btnBack.setBounds(191, 409, 89, 23);
		frame.getContentPane().add(btnBack);
		
		textField_7 = new JTextField();
		textField_7.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		textField_7.setColumns(10);
		textField_7.setBounds(338, 46, 96, 20);
		frame.getContentPane().add(textField_7);
		
		JComboBox comboBox_2 = new JComboBox();
		comboBox_2.setModel(new DefaultComboBoxModel(new String[] {"Select...", "Male", "Female", "Don't Know"}));
		comboBox_2.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		comboBox_2.setBounds(116, 190, 97, 20);
		frame.getContentPane().add(comboBox_2);
		
		JLabel lblEstimatedAgeOf = new JLabel("Estimated Age of Animal:");
		lblEstimatedAgeOf.setFont(new Font("Comic Sans MS", Font.BOLD, 10));
		lblEstimatedAgeOf.setBounds(20, 244, 136, 14);
		frame.getContentPane().add(lblEstimatedAgeOf);
		
		JSpinner spinner_1 = new JSpinner();
		spinner_1.setModel(new SpinnerNumberModel(1, 1, 15, 1));
		spinner_1.setBounds(166, 241, 47, 20);
		frame.getContentPane().add(spinner_1);
	}

}
