import java.awt.Color;
import java.awt.Dimension;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JButton;
import javax.swing.JTextField;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JFormattedTextField;
import java.awt.Button;
import java.awt.Choice;
import javax.swing.JLabel;
import javax.swing.ImageIcon;
import java.awt.Font;

public class DB_initialView {

	private JFrame frame;
	private JTextField textField;
	/**
	 * Launch the application.
	 */
	public static void DBmain(String username) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					DB_initialView window = new DB_initialView(username);
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	public DB_initialView(String username) {
		initialize(username);
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize(String Username) {
		frame = new JFrame();
		frame.getContentPane().setBackground(Color.WHITE);
		frame.setBounds(100, 100, 705, 318);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);

		JButton View = new JButton("Select a Table to View");
		View.setFont(new Font("Comic Sans MS", Font.BOLD, 12));
		View.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				Select_Table.selectTable(Username);
				frame.setVisible(false);
			}
		});
		View.setForeground(Color.RED);
		View.setBounds(155, 59, 174, 23);
		frame.getContentPane().add(View);
		
		JButton Delete = new JButton("Delete a record");
		Delete.setFont(new Font("Comic Sans MS", Font.BOLD, 12));
		Delete.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				DeleteSelectDatabase.SelectTable(Username);
				frame.setVisible(false);
			}
		});
		Delete.setBounds(155, 153, 174, 23);
		frame.getContentPane().add(Delete);
		Delete.setForeground(Color.RED);
		
		JButton Reject = new JButton("Reject");
		Reject.setFont(new Font("Comic Sans MS", Font.BOLD, 12));
		Reject.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				RejectSelectTable.reject(Username);
				frame.setVisible(false);
			}
		});
		Reject.setForeground(Color.RED);

		Reject.setBounds(369, 59, 162, 23);
		frame.getContentPane().add(Reject);
		
		JButton Accept = new JButton("Accept");
		Accept.setFont(new Font("Comic Sans MS", Font.BOLD, 12));
		Accept.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				AcceptSelectTable.accept(Username);
				frame.setVisible(false);
			}
		});
		Accept.setForeground(Color.RED);

		Accept.setBounds(155, 106, 174, 23);
		frame.getContentPane().add(Accept);
		
		JButton LogOut = new JButton("Log Out");
		LogOut.setFont(new Font("Comic Sans MS", Font.BOLD, 12));
		LogOut.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frame.setVisible(false);
			}
		});
		LogOut.setForeground(Color.RED);

		LogOut.setBounds(369, 106, 162, 23);
		frame.getContentPane().add(LogOut);
		
		Button PreviousPage = new Button("<- Go Back");
		PreviousPage.setBackground(Color.LIGHT_GRAY);
		PreviousPage.setFont(new Font("Comic Sans MS", Font.BOLD, 12));
		PreviousPage.setForeground(Color.BLACK);
		PreviousPage.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				General.GeneralSite(Username);
				frame.setVisible(false);
			}
		});
		PreviousPage.setBounds(10, 11, 70, 22);
		frame.getContentPane().add(PreviousPage);
		
		textField = new JTextField();
		textField.setText("Username of User Loged In");
		textField.setColumns(10);
		textField.setBounds(533, 0, 156, 20);
		frame.getContentPane().add(textField);
		
		JLabel label = new JLabel("");
		label.setIcon(new ImageIcon(DB_initialView.class.getResource("/images/23721782_1771329182908750_1673673037_n.jpg")));
		label.setBounds(554, 155, 107, 113);
		frame.getContentPane().add(label);
		
		JLabel lblNewLabel = new JLabel("Options");
		lblNewLabel.setForeground(Color.RED);
		lblNewLabel.setFont(new Font("Comic Sans MS", Font.BOLD | Font.ITALIC, 18));
		lblNewLabel.setBounds(303, 11, 129, 37);
		frame.getContentPane().add(lblNewLabel);
		
		
	}
}
