import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.SwingConstants;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Color;

public class View_Event_Participants_Table {

	private JFrame frame;
	private JTable table;

	/**
	 * Launch the application.
	 */
	public static void view(String Username) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					View_Event_Participants_Table window = new View_Event_Participants_Table(Username);
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public View_Event_Participants_Table( String Username ) {
		initialize(Username);
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize(String Username) {
		frame = new JFrame();
		frame.getContentPane().setFont(new Font("Comic Sans MS", Font.BOLD, 11));
		frame.setBounds(100, 100, 572, 455);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblViewEventsParticipantsTable = new JLabel("View 'Events' Participants' Table");
		lblViewEventsParticipantsTable.setForeground(Color.RED);
		lblViewEventsParticipantsTable.setHorizontalAlignment(SwingConstants.CENTER);
		lblViewEventsParticipantsTable.setFont(new Font("Comic Sans MS", Font.BOLD, 16));
		lblViewEventsParticipantsTable.setBounds(10, 23, 536, 29);
		frame.getContentPane().add(lblViewEventsParticipantsTable);
		
		table = new JTable();
		table.setModel(new DefaultTableModel(
			new Object[][] {
				{"S/N", "Name", "Surname", "Phone Number", "Email Address ", "Participants"},
				{null, "", "", "", null, ""},
				{"1", "Christiana", "Polixroni", "99163326", "polixroni_chr@gmail.com", "1"},
				{"2", "Vasiliki", "Sofokleous", "97163256", "vasiliki.sofokleous@yahoo.com", "1"},
				{"3", "Elena", "Kyriacou", "96156325", "kyriacouelena6@outlook.com", "2"},
				{"4", "Maria", "Evangelou", "99322536", "evangelou_m@gmail.com", "2"},
				{"5", "Andreas", "Miltiadous", "96158625", "andr.miltiadous1987@gmail.com", "3"},
				{"6", "Angelos", "Constantinou", "96325625", "constant_ang@outlook.com", "1"},
				{"7", "Constantina", "Antoniou", "96418325", "antoniou.constantina11@gmail.com", "1"},
				{"8", "Nikolas", "Papa", "97215634", "papa_nikolas@yahoo.gr", "1"},
				{"9", "Evangelia", "Kimitri", "97156146", "evangeliaKimitri_1997@yahoo.com", "2"},
				{"10", "Tasos", "Constantinou", "99863355", "tasos_constan@gmail.com", "2"},
				{"11", "Kyriacos", "Andreou", "99315965", "andreouk@outlook.com", "1"},
				{"12", "Lenos", "Apostolou", "96518656", "apost_lenos@outlook.com", "1"},
				{"13", "Chryso", "Eleftheriou", "97265658", "chryso_eleftheriou@yahoo.gr", "1"},
				{"14", "Antonia", "Andreou", "99521325", null, "3"},
			},
			new String[] {
				"S/N", "Name", "Surname", "Phone Number", "Email Address", "Participants"
			}
		));
		table.getColumnModel().getColumn(0).setPreferredWidth(30);
		table.getColumnModel().getColumn(4).setPreferredWidth(175);
		table.setFont(new Font("Comic Sans MS", Font.BOLD, 11));
		table.setBounds(10, 83, 536, 240);
		frame.getContentPane().add(table);
		
		JButton btnClose = new JButton("Close");
		btnClose.setForeground(Color.RED);
		btnClose.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.exit(0);
			}
		});
		btnClose.setFont(new Font("Comic Sans MS", Font.BOLD, 11));
		btnClose.setBounds(457, 367, 89, 23);
		frame.getContentPane().add(btnClose);
		
		JButton btnSearch = new JButton("Search");
		btnSearch.setForeground(Color.RED);
		btnSearch.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Search_Participant.SearchParticipant(Username);
				frame.setVisible(false);
			}
		});
		btnSearch.setFont(new Font("Comic Sans MS", Font.BOLD, 11));
		btnSearch.setBounds(10, 367, 89, 23);
		frame.getContentPane().add(btnSearch);
		
		JButton btnEdit = new JButton("Edit Data");
		btnEdit.setForeground(Color.RED);
		btnEdit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Edit_Participant.EditParticipant(Username);
				frame.setVisible(false);
			}
		});
		btnEdit.setFont(new Font("Comic Sans MS", Font.BOLD, 11));
		btnEdit.setBounds(154, 367, 95, 23);
		frame.getContentPane().add(btnEdit);
		
		JButton btnInsertData = new JButton("Insert Data");
		btnInsertData.setForeground(Color.RED);
		btnInsertData.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Insert_Participants.InsertParticipants(Username);
				frame.setVisible(false);
			}
		});
		btnInsertData.setFont(new Font("Comic Sans MS", Font.BOLD, 11));
		btnInsertData.setBounds(303, 367, 101, 23);
		frame.getContentPane().add(btnInsertData);
		
		JButton button = new JButton("<-Back");
		button.setFont(new Font("Comic Sans MS", Font.BOLD, 11));
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Select_Table.selectTable(Username);
				frame.setVisible(false);

			}
		});
		button.setBounds(0, 0, 89, 23);
		frame.getContentPane().add(button);
		
	}
}
