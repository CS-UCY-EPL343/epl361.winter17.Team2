import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTable;
import javax.swing.SwingConstants;
import javax.swing.table.DefaultTableModel;
import java.awt.Color;

public class View_Request_Cat {

	private JFrame frame;
	private JTable table;

	/**
	 * Launch the application.
	 */
	public static void view(String Username) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					View_Request_Cat window = new View_Request_Cat(Username);
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public View_Request_Cat(String Username) {
		initialize(Username);
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize(String Username) {
		frame = new JFrame();
		frame.setBounds(100, 100, 800, 455);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblViewRequestCatTable = new JLabel("View 'Request for a Cat' Table");
		lblViewRequestCatTable.setForeground(Color.RED);
		lblViewRequestCatTable.setHorizontalAlignment(SwingConstants.CENTER);
		lblViewRequestCatTable.setFont(new Font("Comic Sans MS", Font.BOLD, 16));
		lblViewRequestCatTable.setBounds(10, 31, 764, 37);
		frame.getContentPane().add(lblViewRequestCatTable);
		
		table = new JTable();
		table.setModel(new DefaultTableModel(
			new Object[][] {
				{"S/N", "Adopter's Fullname", "Adopter's Address", "Adopter's Phone", "Adopter's Email", "Adopter's Age", "Family Members", "Discussed with Family", "Cat's Number", "Cat's Name", "Cat's Breed", "Cat's Gender", "Cat's Age", "Day Completed"},
				{null, null, null, null, null, null, null, null, null, null, null, null, null, null},
				{"1", "Vasos Ioannou", "Galinis 15, Aglantzia, Nicosia", "96525265", "vasos_ioan@gmail.com", "20", null, null, "152", "Ellie", "Other", "Female", "2", "20.12.2015"},
				{"2", "Eleftherios Andreou", "Georgiou Nikolaidi 8, Livadia, Larnaca", "97215653", "eleftherios_andreou@gmail.com", "36", "Wife, 1 Child", "YES", "96", null, null, "Male", "1", "30.05.2000"},
				{"3", "Natalia Venizelou", "Agiou Savva 62, Livadia, Larnaca", "99315315", null, "27", "Husband", "NO", null, null, null, "Male", "3", "Obidience"},
				{"4", "Ermioni Vasileiou", "Panepistimiou 13, Aglantzia, Nicosia", "97321315", null, "19", "Mother, Father", "YES", "75", "Max", null, "Male", "", "30.02.2017"},
				{"5", "Maria Papa", "Agias Sofias 154, Aradipou, Larnaca", "99316516", "papa.mar54@yahoo.gr", "54", "Husband", "YES", "168", null, null, "Female", "2", "15.06.2014"},
				{"6", "Antigoni Theodoulou", "Markou Drakou 23, Aglantzia, Nicosia", "96365165", null, "49", "Husband", "NO", "358", "Charls", "Persian", "Male", "1", "09.07.2016"},
				{"7", "Magda Tofari", "Chrysanthou Mylona 7, Strovolos, Nicosia", "96514635", null, "40", "Husband", "YES", null, null, null, "Female", "1", "26.02.2006"},
				{"8", "Persefoni Panagiotou", "Tilepikoinonion 18, Strovolos, Nicosia", "99202552", null, "36", "Sister", "NO", "245", null, null, "Female", "3", "19.11.2009"},
				{"9", "Costas Christou", "Irinis 15, Limassol", "96462213", null, "28", "Brother", "NO", null, null, null, "Female", "1", "14.12.2009"},
				{"10", "Christos Antoniou", "Ellados 35, Limassol", "99863316", "antonchristos@outlook.com", "20", "Mother, Father, Sister", "YES", "149", null, "Ragdoll", "Male", "2", "24.09.2008"},
				{"11", "Maria Michael", "Kalamatas 24, Paphos", "99316353", "marmichael@hotmail.com", "36", null, null, "364", "Tom", null, "Female", null, "31.04.2010"},
				{"12", "Petros Hlia", "Michael Kyprianou 8, Paphos", "96215233", null, "60", null, null, null, "Elvis", "Other", "Male", null, "18.10.2014"},
				{"13", "Antonia Georgiou", "Nicolaou P. Laniti 3, Limassol", "97326333", "ageorg@yahoo.com", "57", null, null, "34", null, null, "Male", "2", "24.01.2015"},
			},
			new String[] {
				"S/N", "Adopter's Fullname", "Adopter's Address", "Adopter's Phone", "Adopter's Email", "Adopter's Age", "Family Members", "Discussed with Family", "Cat's Number", "Cat's Name", "Cat's Breed", "Cat's Gender", "Cat's Age", "Day Completed"
			}
		));
		table.getColumnModel().getColumn(0).setPreferredWidth(30);
		table.getColumnModel().getColumn(1).setPreferredWidth(105);
		table.getColumnModel().getColumn(2).setPreferredWidth(206);
		table.getColumnModel().getColumn(3).setPreferredWidth(90);
		table.getColumnModel().getColumn(4).setPreferredWidth(158);
		table.getColumnModel().getColumn(6).setPreferredWidth(113);
		table.getColumnModel().getColumn(13).setPreferredWidth(84);
		table.setFont(new Font("Comic Sans MS", Font.BOLD, 12));
		table.setBounds(10, 87, 764, 241);
		frame.getContentPane().add(table);
		
		JButton btnClose = new JButton("Close");
		btnClose.setForeground(Color.RED);
		btnClose.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.exit(0);
			}
		});
		btnClose.setFont(new Font("Comic Sans MS", Font.BOLD, 12));
		btnClose.setBounds(589, 370, 89, 23);
		frame.getContentPane().add(btnClose);
		
		JButton btnInsertData = new JButton("Insert Data");
		btnInsertData.setForeground(Color.RED);
		btnInsertData.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Insert_Request_Cat.InsertRequestCat(Username);
				frame.setVisible(false);
			}
		});
		btnInsertData.setFont(new Font("Comic Sans MS", Font.BOLD, 12));
		btnInsertData.setBounds(404, 370, 107, 23);
		frame.getContentPane().add(btnInsertData);
		
		JButton btnSearch = new JButton("Search");
		btnSearch.setForeground(Color.RED);
		btnSearch.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e) {
				Search_Request_Cat.SearchRequestCat(Username);
				frame.setVisible(false);
			}
		});
		btnSearch.setFont(new Font("Comic Sans MS", Font.BOLD, 12));
		btnSearch.setBounds(89, 370, 89, 23);
		frame.getContentPane().add(btnSearch);
		
		JButton btnEditData = new JButton("Edit Data");
		btnEditData.setForeground(Color.RED);
		btnEditData.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Edit_Request_Cat.EditRequestCat(Username);
				frame.setVisible(false);
			}
		});
		btnEditData.setFont(new Font("Comic Sans MS", Font.BOLD, 12));
		btnEditData.setBounds(245, 370, 89, 23);
		frame.getContentPane().add(btnEditData);
		
		JButton button = new JButton("<-Back");
		button.setFont(new Font("Comic Sans MS", Font.BOLD, 12));
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Select_Table.selectTable(Username);
				frame.setVisible(false);

			}
		});
		button.setBounds(0, 0, 89, 23);
		frame.getContentPane().add(button);
	}

}
