
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;

public class Main extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main1(String Username) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Main frame = new Main(Username);
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Main(String Username) {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 769, 506);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(255, 255, 255));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setIcon(new ImageIcon(Main.class.getResource("/images/23721782_1771329182908750_1673673037_n.jpg")));
		lblNewLabel.setBounds(0, 0, 113, 95);
		getContentPane().add(lblNewLabel);
		
		JLabel lblAdminPanel = new JLabel("H&H Administrator Panel");
		lblAdminPanel.setForeground(new Color(178, 34, 34));
		lblAdminPanel.setHorizontalAlignment(SwingConstants.CENTER);
		lblAdminPanel.setFont(new Font("Comic Sans MS", Font.BOLD, 18));
		lblAdminPanel.setBounds(123, 0, 630, 106);
		getContentPane().add(lblAdminPanel);
		
		    
		
		String tabs[] ={"Home","Successful Stories", "Events","Animal's Gallery","Advices&Tips"};		
		JComboBox comboBox = new JComboBox(tabs);
		comboBox.setFont(new Font("Comic Sans MS", Font.BOLD, 12));
		comboBox.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent event) {
                //
                // Get the source of the component, which is our combo
                // box.
                //
                JComboBox comboBox = (JComboBox) event.getSource();

                Object selected = comboBox.getSelectedItem();
                if(selected.toString().equals("Home")) {
                setVisible(false);
                new Tabs(Username).setVisible(true);}
                else if(selected.toString().equals("Events")) {
                	setVisible(false);
                new EventTab(Username).setVisible(true);}
                else if(selected.toString().equals("Adoptions")) {
                	setVisible(false);
                new Tabs(Username).setVisible(true);}
                else if(selected.toString().equals("Animal's Gallery")) {
                	setVisible(false);
                new GalleryOption(Username).setVisible(true);} 
                else if(selected.toString().equals("Advices&Tips")) {
                	setVisible(false);
                new Tabs(Username).setVisible(true);}
                else if(selected.toString().equals("Successful Stories")) {
                	setVisible(false);
                new Tabs(Username).setVisible(true);}
               
                

            }
        });
		
		comboBox.setBounds(407, 144, 175, 48);
		getContentPane().add(comboBox);
		
		JButton btnView = new JButton("View Website");
		btnView.setFont(new Font("Comic Sans MS", Font.BOLD, 12));
		btnView.setBounds(84, 144, 256, 48);
		getContentPane().add(btnView);
		JButton btnEdit = new JButton("Edit Website");
		btnEdit.setFont(new Font("Comic Sans MS", Font.BOLD, 12));
		btnEdit.addActionListener(new ActionListener() {	
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				btnEdit.setVisible(false);
				
				comboBox.setVisible(!comboBox.isVisible());}
						
		});
		comboBox.setVisible(Boolean.FALSE);
		//frame.getContentPane().add(comboBox);
	    getContentPane().add(comboBox);
		
		btnEdit.setBounds(395, 144, 256, 48);
		getContentPane().add(btnEdit);
		
		
		
		JLabel label = new JLabel("");
		label.setIcon(new ImageIcon(Main.class.getResource("/images/1511588_604719249605970_1089402828_n1.jpg")));
		label.setBounds(10, 118, 743, 457);
		getContentPane().add(label);
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(0, 0, 0));
		panel.setBounds(0, 101, 753, 10);
		contentPane.add(panel);
		
		JButton btnGoBack = new JButton("Go Back");
		btnGoBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				General g=new General(Username);
				String d=null;
				g.GeneralSite(d);
				setVisible(false);
			}
		});
		btnGoBack.setBounds(664, 0, 89, 23);
		contentPane.add(btnGoBack);

		btnView.addActionListener(new ActionListener() {	
			@Override
			public void actionPerformed(ActionEvent e) {
				try { 
			         String url = "http://eriakouppari97.mozello.com/";
			         java.awt.Desktop.getDesktop().browse(java.net.URI.create(url));
			       }
			       catch (java.io.IOException ex) {
			           System.out.println(ex.getMessage());
			       }}
						
	});
	}

}
