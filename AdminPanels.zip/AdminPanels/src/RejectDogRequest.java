import java.awt.Color;
	import java.awt.EventQueue;
	import java.awt.event.ActionEvent;
	import java.awt.event.ActionListener;

	import javax.swing.JButton;
	import javax.swing.JFrame;
	import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTable;
	import javax.swing.table.DefaultTableModel;
	import javax.swing.table.TableRowSorter;
	import java.awt.Button;
import java.awt.Font;
import javax.swing.ImageIcon;

	
public class RejectDogRequest{
		private JFrame frame;
		private JTable table;
		private DefaultTableModel dm;
		private JLabel lblPleaseSelectA;
		/**
		 * Launch the application.
		 */
		public static void reject(String Username) {
			EventQueue.invokeLater(new Runnable() {
				public void run() {
					try {
						RejectDogRequest window = new RejectDogRequest(Username);
						window.frame.setVisible(true);
					} catch (Exception e) {
						e.printStackTrace();
					}
				}
			});
		}

		/**
		 * Create the application.
		 */
		public RejectDogRequest(String Username) {
			initialize(Username);
		}

		/**
		 * Initialize the contents of the frame.
		 */
		private void initialize(String Username) {
			frame = new JFrame();
			frame.setBounds(100, 100, 744, 323);
			frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			frame.getContentPane().setLayout(null);
			
			table = new JTable();
			table.setForeground(Color.BLACK);
			//Add columns
			dm=(DefaultTableModel) table.getModel();
			dm.addColumn("Adopter's Full Name");
			dm.addColumn("Adopter's Address");
			dm.addColumn("Adopter's Phone No");
			dm.addColumn("Adopter's E-mail");
			dm.addColumn("Adopter's Age");
			dm.addColumn("Othe Household members");
			dm.addColumn("Discussed");
			dm.addColumn("Dog's No");
			dm.addColumn("Dog's Name");
			dm.addColumn("Dog's Breed");
			dm.addColumn("Dog's Gender");
			dm.addColumn("Dog's Age");
			dm.addColumn("Activities");
			dm.addColumn("ACCEPTED");


			//Add rows
			String[] Row={"Adopter's Full Name", "Adopter's Address","Adopter's Phone No", "Adopter's E-mail", "Adopters Age", "Other Houshold Members","Discussed","Dog's No","Dog's Name","Dog's Breed","Dog's Gender","Dog's Age","Activities","Accepted"};
			dm.addRow(Row);
			String[]Row1= {"Sherlock Holmes", "22B Baker Street", "999999", "sherlock.Holmes@gmail.com","38","3","Yes","189","Max","Chihuahua","Male","5","N/A","N/A"};
			dm.addRow(Row1);
			String[]Row2= {"Anthony Miles", "Leoforos Larnakos", "988888", "Anthony.miles@gmail.com","35","0","Yes","188","Ann","Labrator","Female","2","N/A","N/A"};
			dm.addRow(Row2);
			String[]Row3= {"Mary Anton", "22B Baker Street", "999999", "sherlock.Holmes@gmail.com","38","3","Yes","189","Max","Chihuahua","Male","5","N/A","N/A"};
			dm.addRow(Row3);

			TableRowSorter<DefaultTableModel> tr=new TableRowSorter<DefaultTableModel>(dm);
			table.setRowSorter(tr);
			
			table.setBounds(10, 36, 708, 150);
			frame.getContentPane().add(table);
			
			JButton btnDelet = new JButton("Reject");
			btnDelet.setFont(new Font("Comic Sans MS", Font.BOLD, 12));
			btnDelet.setForeground(Color.RED);
			btnDelet.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					if(table.getSelectedRow()!=-1) {
						dm.setValueAt("No", table.getSelectedRow(), 13);
					}
					else {
						JOptionPane.showMessageDialog(null, "Please select a record");
					}
						
				}
			});
			btnDelet.setBounds(325, 226, 89, 23);
			frame.getContentPane().add(btnDelet);
			
			JLabel lblDeleteFromTable = new JLabel("Reject A Report From Below");
			lblDeleteFromTable.setFont(new Font("Comic Sans MS", Font.BOLD, 12));
			lblDeleteFromTable.setForeground(Color.RED);
			lblDeleteFromTable.setBounds(307, 11, 268, 14);
			frame.getContentPane().add(lblDeleteFromTable);
			
			Button button = new Button("<- Go Back");
			button.setFont(new Font("Comic Sans MS", Font.BOLD, 12));
			button.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					RejectSelectTable.reject(Username);
					frame.setVisible(false);
				}
			});
			button.setBounds(0, 0, 70, 22);
			frame.getContentPane().add(button);
			lblPleaseSelectA = new JLabel(" ");

			lblPleaseSelectA.setBounds(237, 226, 46, 14);
			frame.getContentPane().add(lblPleaseSelectA);
			
			JLabel label = new JLabel("");
			label.setIcon(new ImageIcon(RejectDogRequest.class.getResource("/images/23721782_1771329182908750_1673673037_n.jpg")));
			label.setBounds(594, 197, 113, 76);
			frame.getContentPane().add(label);
			
			
			
		}
}