
import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.DefaultListModel;
import javax.swing.ImageIcon;
import javax.swing.JScrollPane;
import javax.swing.ScrollPaneConstants;
import javax.swing.JList;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.SwingConstants;
import javax.swing.JTextField;
import javax.swing.ListModel;
import java.awt.Color;
import java.awt.Font;
 class TestModel {

private DefaultListModel lm_;

   TestModel() {
    lm_ = new DefaultListModel();

    String[] testList = new String[] {"Post1", "Post2", "Post3","Post4","Post5","Post6","Post7","Post8","Post9","Post10"};

    for(int i=0; i < testList.length; i++) {
      lm_.add(i, testList[i]);
    }
  }

  public ListModel getListModel() {
    return lm_;
  }
}
public class Tabs extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;

	/**
	 * Launch the application.
	 */
	public static void tabs(String Username) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Tabs frame = new Tabs(Username);
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Tabs(String Username) {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 516, 402);
		contentPane = new JPanel();
		contentPane.setBackground(Color.WHITE);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel label = new JLabel("");
		label.setBounds(0, 0, 113, 88);
		label.setIcon(new ImageIcon(Tabs.class.getResource("/images/23721782_1771329182908750_1673673037_n.jpg")));
		contentPane.add(label);
		
		JLabel label_1 = new JLabel("");
		label_1.setBounds(238, 47, 46, 14);
		contentPane.add(label_1);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
		scrollPane.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
		scrollPane.setBounds(27, 143, 461, 128);
		contentPane.add(scrollPane);
		
		// String[] array = {"Post1", "Post2", "Post3","Post4","Post5","Post6","Post7","Post8","Post9","Post10"};
		//JList list = new JList(array);
		//scrollPane.setViewportView(list);
		
		
		TestModel tm = new TestModel();

	    JList list = new JList(tm.getListModel());
	    list.setFont(new Font("Comic Sans MS", Font.BOLD, 11));
	    scrollPane.setViewportView(list);
	    
		JButton btnEdit = new JButton("EDIT");
		btnEdit.setFont(new Font("Comic Sans MS", Font.BOLD, 11));
		btnEdit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
				EditFrame.edit_frame1(Username);
			}
		});
		btnEdit.setBounds(37, 290, 89, 23);
		contentPane.add(btnEdit);
		
		JButton btnDelete = new JButton("DELETE");
		btnDelete.setFont(new Font("Comic Sans MS", Font.BOLD, 11));
		btnDelete.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				DefaultListModel model = (DefaultListModel) list.getModel();
				int selectedIndex = list.getSelectedIndex();
				if (selectedIndex != -1) {
				    model.remove(selectedIndex);
				}
				
			}
		});
		btnDelete.setBounds(151, 290, 89, 23);
		contentPane.add(btnDelete);
		
		JButton btnAddNewArticle = new JButton("+ Add New Article");
		btnAddNewArticle.setFont(new Font("Comic Sans MS", Font.BOLD, 11));
		btnAddNewArticle.setHorizontalAlignment(SwingConstants.LEFT);
		btnAddNewArticle.addActionListener(new ActionListener() {
		
			public void actionPerformed(ActionEvent arg0) {
				new_article.new_article(Username);
			}
			
		});
				
	
		
		btnAddNewArticle.setBounds(27, 111, 150, 23);
		contentPane.add(btnAddNewArticle);
		
		JLabel lblSearch = new JLabel("Search:");
		lblSearch.setFont(new Font("Comic Sans MS", Font.BOLD, 11));
		lblSearch.setBounds(296, 115, 46, 14);
		contentPane.add(lblSearch);
		
		textField = new JTextField();
		textField.setBounds(337, 112, 113, 20);
		contentPane.add(textField);
		textField.setColumns(10);
		
		JButton btnGoBack = new JButton("Go Back");
		btnGoBack.setFont(new Font("Comic Sans MS", Font.BOLD, 11));
		btnGoBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
				Main.main1(Username);
			}
		});
		btnGoBack.setBounds(396, 328, 89, 23);
		contentPane.add(btnGoBack);
		}
}
