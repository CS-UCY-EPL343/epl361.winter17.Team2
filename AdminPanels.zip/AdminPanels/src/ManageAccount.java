
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.BorderLayout;
import javax.swing.JButton;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JLabel;
import javax.swing.ImageIcon;

public class ManageAccount {

	private JFrame frame;

	/**
	 * Launch the application.
	 */
	public static void main(String Username) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ManageAccount window = new ManageAccount(Username);
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public ManageAccount(String Username) {
		initialize(Username);
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize(String Username) {
		frame = new JFrame();
		frame.setBounds(100, 100, 749, 410);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		JPanel panel = new JPanel();
		panel.setForeground(Color.WHITE);
		frame.getContentPane().add(panel, BorderLayout.CENTER);
		panel.setLayout(null);
		
		JButton btnNewButton = new JButton("Change Username ");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ChangeUsername us=new ChangeUsername(Username);
				us.username(Username);
			}
		});
		btnNewButton.setFont(new Font("Comic Sans MS", Font.BOLD, 16));
		btnNewButton.setForeground(Color.RED);
		btnNewButton.setBounds(80, 196, 196, 23);
		panel.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("Change Passsword");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ChangePassword pass=new ChangePassword(Username);
				pass.ChangePass(Username);
			}
		});
		btnNewButton_1.setFont(new Font("Comic Sans MS", Font.BOLD, 16));
		btnNewButton_1.setForeground(Color.RED);
		btnNewButton_1.setBounds(493, 196, 196, 23);
		panel.add(btnNewButton_1);
		
		JLabel lblNewLabel = new JLabel("        Manage your account");
		lblNewLabel.setFont(new Font("Comic Sans MS", Font.BOLD, 22));
		lblNewLabel.setForeground(Color.RED);
		lblNewLabel.setBounds(223, 18, 337, 29);
		panel.add(lblNewLabel);
		
		JLabel label = new JLabel("");
		label.setIcon(new ImageIcon(ManageAccount.class.getResource("/images/21062616-Metallic-my-account-icon-with-black-design-on-white-glass-background-Stock-Photo.jpg")));
		label.setBounds(-252, 18, 1004, 353);
		panel.add(label);
		
		JButton btnGoBack = new JButton("Go Back");
		btnGoBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				General g=new General(Username);
				g.GeneralSite(Username);
				frame.setVisible(false);
			}
		});
		
		btnGoBack.setFont(new Font("Comic Sans MS", Font.BOLD, 11));
		btnGoBack.setForeground(Color.BLACK);
		btnGoBack.setBounds(0, 18, 89, 23);
		panel.add(btnGoBack);
		
		JLabel label_2 = new JLabel("");
		label_2.setIcon(new ImageIcon(ManageAccount.class.getResource("/images/23721782_1771329182908750_1673673037_n.jpg")));
		label_2.setBounds(0, 0, 121, 90);
		panel.add(label_2);
		
	}
}
