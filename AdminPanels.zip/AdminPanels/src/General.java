
import java.awt.EventQueue;

import javax.swing.JFrame;
import java.awt.Color;
import javax.swing.JButton;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.Image;

import javax.swing.ImageIcon;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.UIManager;
import javax.swing.JScrollBar;

public class General {

	private JFrame frame;
	/**
	 * Launch the application.
	 */
	public static void GeneralSite(String Username) {
		System.out.println(Username);
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					General window = new General(Username);
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public General(String username) {
		initialize(username);
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize(String Username) {
		frame = new JFrame();
		frame.getContentPane().setBackground(Color.WHITE);
		frame.getContentPane().setLayout(null);
		
		JButton btnManageWebsite = new JButton("Manage Website");
		btnManageWebsite.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//System.out.println("General:"+Username);
				if(Username.compareTo("admin@hotmail.com")==0){
					admin_webuser_administrator ad=new admin_webuser_administrator(Username);
					ad.admin_main(Username);
					frame.setVisible(false);
				}
				else{
					admin_webuser adw=new admin_webuser(Username);
					adw.ad_we(Username);
					frame.setVisible(false);
				}
			}
		});
		btnManageWebsite.setBackground(Color.LIGHT_GRAY);
		btnManageWebsite.setForeground(Color.RED);
		btnManageWebsite.setFont(new Font("Comic Sans MS", Font.BOLD | Font.ITALIC, 14));
		btnManageWebsite.setBounds(52, 95, 182, 29);
		frame.getContentPane().add(btnManageWebsite);
		
		JButton btnManageDatabase = new JButton("Manage Database");
		btnManageDatabase.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				DB_initialView.DBmain(Username);
				frame.setVisible(false);
			}
		});
		btnManageDatabase.setBackground(Color.LIGHT_GRAY);
		btnManageDatabase.setFont(new Font("Comic Sans MS", Font.BOLD | Font.ITALIC, 14));
		btnManageDatabase.setForeground(Color.RED);
		btnManageDatabase.setBounds(284, 95, 182, 29);
		frame.getContentPane().add(btnManageDatabase);
		
		JButton btnManageAccount = new JButton("Manage Account");
		btnManageAccount.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ManageAccount mg=new ManageAccount(Username);
				String[] st=null;
				mg.main(Username);
				frame.setVisible(false);
			
			}
		});
		btnManageAccount.setBackground(Color.LIGHT_GRAY);
		btnManageAccount.setForeground(Color.RED);
		btnManageAccount.setFont(new Font("Comic Sans MS", Font.BOLD | Font.ITALIC, 14));
		btnManageAccount.setBounds(167, 152, 182, 29);
		frame.getContentPane().add(btnManageAccount);
		
		JLabel lblWelcomeToYour = new JLabel("Welcome to your account\r\n\r\n");
		lblWelcomeToYour.setFont(new Font("Comic Sans MS", Font.BOLD | Font.ITALIC, 18));
		lblWelcomeToYour.setForeground(Color.RED);
		lblWelcomeToYour.setBounds(151, 11, 258, 29);
		frame.getContentPane().add(lblWelcomeToYour);
		
		JLabel lblPleaseChooseThe = new JLabel("Please choose the action you want to execute:");
		lblPleaseChooseThe.setFont(new Font("Comic Sans MS", Font.BOLD | Font.ITALIC, 14));
		lblPleaseChooseThe.setForeground(Color.GRAY);
		lblPleaseChooseThe.setBounds(10, 59, 327, 21);
		frame.getContentPane().add(lblPleaseChooseThe);
		
		JLabel label = new JLabel("");
		ImageIcon im;
		label.setIcon(new ImageIcon(General.class.getResource("/images/cat_n_dog.gif")));
		label.setBounds(40, 192, 473, 144);
		frame.getContentPane().add(label);
		
		JButton button = new JButton("Go Back");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String[] k=null;
				frame f=new frame();
				f.main(k);
				frame.setVisible(false);
			}
		});
		button.setFont(new Font("Comic Sans MS", Font.BOLD, 12));
		button.setBounds(0, 0, 89, 23);
		frame.getContentPane().add(button);
		
		JLabel label_1 = new JLabel("");
		label_1.setIcon(new ImageIcon(General.class.getResource("/images/23721782_1771329182908750_1673673037_n.jpg")));
		label_1.setBounds(442, 0, 108, 84);
		frame.getContentPane().add(label_1);
		frame.setBackground(Color.WHITE);
		frame.setBounds(100, 100, 566, 375);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}

}
