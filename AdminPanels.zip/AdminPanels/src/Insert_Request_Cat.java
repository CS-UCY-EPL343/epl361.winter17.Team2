import java.awt.EventQueue;
import java.awt.Font;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.SwingConstants;
import javax.swing.JTextField;
import javax.swing.JSpinner;
import javax.swing.SpinnerNumberModel;
import javax.swing.JList;
import javax.swing.AbstractListModel;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Color;

public class Insert_Request_Cat {

	private JFrame frame;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;
	private JTextField textField_4;
	private JTextField textField_5;
	private JTextField textField_6;
	private JTextField textField_7;

	/**
	 * Launch the application.
	 */
	public static void InsertRequestCat(String Username) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Insert_Request_Cat window = new Insert_Request_Cat(Username);
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Insert_Request_Cat(String Username) {
		initialize(Username);
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize(String Username) {
		frame = new JFrame();
		frame.setBounds(100, 100, 486, 499);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblInsertData = new JLabel("Insert Data");
		lblInsertData.setForeground(Color.RED);
		lblInsertData.setHorizontalAlignment(SwingConstants.CENTER);
		lblInsertData.setFont(new Font("Comic Sans MS", Font.BOLD, 14));
		lblInsertData.setBounds(10, 11, 450, 24);
		frame.getContentPane().add(lblInsertData);
		
		JLabel lblAdoptersName = new JLabel("Adopter's Name:");
		lblAdoptersName.setFont(new Font("Comic Sans MS", Font.BOLD, 11));
		lblAdoptersName.setBounds(26, 61, 92, 14);
		frame.getContentPane().add(lblAdoptersName);
		
		textField = new JTextField();
		textField.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		textField.setBounds(128, 58, 86, 20);
		frame.getContentPane().add(textField);
		textField.setColumns(10);
		
		JLabel lblAdoptersAddress = new JLabel("Adopter's Address:");
		lblAdoptersAddress.setFont(new Font("Comic Sans MS", Font.BOLD, 11));
		lblAdoptersAddress.setBounds(232, 61, 107, 14);
		frame.getContentPane().add(lblAdoptersAddress);
		
		textField_1 = new JTextField();
		textField_1.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		textField_1.setColumns(10);
		textField_1.setBounds(342, 58, 86, 20);
		frame.getContentPane().add(textField_1);
		
		JLabel lblAdoptersPhone = new JLabel("Adopter's Phone:");
		lblAdoptersPhone.setFont(new Font("Comic Sans MS", Font.BOLD, 11));
		lblAdoptersPhone.setBounds(26, 106, 92, 14);
		frame.getContentPane().add(lblAdoptersPhone);
		
		textField_2 = new JTextField();
		textField_2.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		textField_2.setColumns(10);
		textField_2.setBounds(128, 103, 86, 20);
		frame.getContentPane().add(textField_2);
		
		JLabel lblAdoptersEmail = new JLabel("Adopter's Email:");
		lblAdoptersEmail.setFont(new Font("Comic Sans MS", Font.BOLD, 11));
		lblAdoptersEmail.setBounds(232, 106, 100, 14);
		frame.getContentPane().add(lblAdoptersEmail);
		
		textField_3 = new JTextField();
		textField_3.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		textField_3.setColumns(10);
		textField_3.setBounds(342, 103, 86, 20);
		frame.getContentPane().add(textField_3);
		
		JLabel lblAdoptersAge = new JLabel("Adopter's Age:");
		lblAdoptersAge.setFont(new Font("Comic Sans MS", Font.BOLD, 11));
		lblAdoptersAge.setBounds(26, 152, 92, 14);
		frame.getContentPane().add(lblAdoptersAge);
		
		JSpinner spinner = new JSpinner();
		spinner.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		spinner.setModel(new SpinnerNumberModel(18, 18, 66, 1));
		spinner.setBounds(128, 149, 46, 20);
		frame.getContentPane().add(spinner);
		
		JLabel lblFamilyMembers = new JLabel("Family Members:");
		lblFamilyMembers.setFont(new Font("Comic Sans MS", Font.BOLD, 11));
		lblFamilyMembers.setBounds(26, 345, 100, 14);
		frame.getContentPane().add(lblFamilyMembers);
		
		JLabel lblDiscussedWithFamilly = new JLabel("Discussed with Familly:");
		lblDiscussedWithFamilly.setFont(new Font("Comic Sans MS", Font.BOLD, 11));
		lblDiscussedWithFamilly.setBounds(26, 198, 126, 23);
		frame.getContentPane().add(lblDiscussedWithFamilly);
		
		JCheckBox chckbxNewCheckBox = new JCheckBox("");
		chckbxNewCheckBox.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		chckbxNewCheckBox.setBounds(171, 198, 21, 23);
		frame.getContentPane().add(chckbxNewCheckBox);
		
		JLabel lblCatsNumber = new JLabel("Cat's Number:");
		lblCatsNumber.setFont(new Font("Comic Sans MS", Font.BOLD, 11));
		lblCatsNumber.setBounds(232, 152, 100, 14);
		frame.getContentPane().add(lblCatsNumber);
		
		textField_4 = new JTextField();
		textField_4.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		textField_4.setColumns(10);
		textField_4.setBounds(342, 149, 86, 20);
		frame.getContentPane().add(textField_4);
		
		JLabel lblCatsName = new JLabel("Cat's Name:");
		lblCatsName.setFont(new Font("Comic Sans MS", Font.BOLD, 11));
		lblCatsName.setBounds(232, 202, 100, 14);
		frame.getContentPane().add(lblCatsName);
		
		textField_5 = new JTextField();
		textField_5.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		textField_5.setColumns(10);
		textField_5.setBounds(342, 199, 86, 20);
		frame.getContentPane().add(textField_5);
		
		JLabel lblCatsBreed = new JLabel("Cat's Breed:");
		lblCatsBreed.setFont(new Font("Comic Sans MS", Font.BOLD, 11));
		lblCatsBreed.setBounds(232, 249, 100, 14);
		frame.getContentPane().add(lblCatsBreed);
		
		textField_6 = new JTextField();
		textField_6.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		textField_6.setColumns(10);
		textField_6.setBounds(342, 246, 86, 20);
		frame.getContentPane().add(textField_6);
		
		JLabel lblCatsGender = new JLabel("Cat's Gender:");
		lblCatsGender.setFont(new Font("Comic Sans MS", Font.BOLD, 11));
		lblCatsGender.setBounds(26, 294, 100, 14);
		frame.getContentPane().add(lblCatsGender);
		
		JComboBox comboBox = new JComboBox();
		comboBox.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		comboBox.setModel(new DefaultComboBoxModel(new String[] {"Select...", "Male", "Female"}));
		comboBox.setBounds(128, 291, 86, 20);
		frame.getContentPane().add(comboBox);
		
		JLabel lblCats = new JLabel("Cat's Age:");
		lblCats.setFont(new Font("Comic Sans MS", Font.BOLD, 11));
		lblCats.setBounds(26, 249, 100, 14);
		frame.getContentPane().add(lblCats);
		
		JSpinner spinner_1 = new JSpinner();
		spinner_1.setModel(new SpinnerNumberModel(1, 1, 15, 1));
		spinner_1.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		spinner_1.setBounds(128, 246, 46, 20);
		frame.getContentPane().add(spinner_1);
		
		JLabel lblDayCompleted = new JLabel("Day Completed:");
		lblDayCompleted.setFont(new Font("Comic Sans MS", Font.BOLD, 11));
		lblDayCompleted.setBounds(232, 294, 100, 14);
		frame.getContentPane().add(lblDayCompleted);
		
		textField_7 = new JTextField();
		textField_7.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		textField_7.setColumns(10);
		textField_7.setBounds(342, 291, 86, 20);
		frame.getContentPane().add(textField_7);
		
		JButton btnSave = new JButton("Save");
		btnSave.setForeground(Color.RED);
		btnSave.setFont(new Font("Comic Sans MS", Font.BOLD, 11));
		btnSave.setBounds(26, 426, 89, 23);
		frame.getContentPane().add(btnSave);
		
		JButton btnNewButton = new JButton("Exit");
		btnNewButton.setForeground(Color.RED);
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.exit(0);
			}
		});
		btnNewButton.setFont(new Font("Comic Sans MS", Font.BOLD, 11));
		btnNewButton.setBounds(339, 426, 89, 23);
		frame.getContentPane().add(btnNewButton);
		
		JButton btnBack = new JButton("Back");
		btnBack.setForeground(Color.RED);
		btnBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				View_Request_Cat.view(Username);
				frame.setVisible(false);
			}
		});
		btnBack.setFont(new Font("Comic Sans MS", Font.BOLD, 11));
		btnBack.setBounds(187, 426, 89, 23);
		frame.getContentPane().add(btnBack);
		
		JCheckBox chckbxNewCheckBox_1 = new JCheckBox("Mother/Father");
		chckbxNewCheckBox_1.setFont(new Font("Comic Sans MS", Font.BOLD, 11));
		chckbxNewCheckBox_1.setBounds(128, 341, 107, 23);
		frame.getContentPane().add(chckbxNewCheckBox_1);
		
		JCheckBox chckbxSisterbrother = new JCheckBox("Sister/Brother");
		chckbxSisterbrother.setFont(new Font("Comic Sans MS", Font.BOLD, 11));
		chckbxSisterbrother.setBounds(342, 341, 118, 23);
		frame.getContentPane().add(chckbxSisterbrother);
		
		JCheckBox chckbxSondaughter = new JCheckBox("Son/Daughter");
		chckbxSondaughter.setFont(new Font("Comic Sans MS", Font.BOLD, 11));
		chckbxSondaughter.setBounds(232, 341, 107, 23);
		frame.getContentPane().add(chckbxSondaughter);
		
		JCheckBox chckbxHusbandwife = new JCheckBox("Husband/Wife");
		chckbxHusbandwife.setFont(new Font("Comic Sans MS", Font.BOLD, 11));
		chckbxHusbandwife.setBounds(128, 382, 102, 23);
		frame.getContentPane().add(chckbxHusbandwife);
		
		JCheckBox chckbxFriend = new JCheckBox("Friend");
		chckbxFriend.setFont(new Font("Comic Sans MS", Font.BOLD, 11));
		chckbxFriend.setBounds(232, 382, 97, 23);
		frame.getContentPane().add(chckbxFriend);
		
		JCheckBox chckbxOther = new JCheckBox("Other");
		chckbxOther.setFont(new Font("Comic Sans MS", Font.BOLD, 11));
		chckbxOther.setBounds(342, 382, 97, 23);
		frame.getContentPane().add(chckbxOther);
	}
}
