import java.awt.EventQueue;
import java.awt.Font;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.SwingConstants;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.JSpinner;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class View_Stray_Animals_Table {

	private JFrame frame;
	private JTable table;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					View_Stray_Animals_Table window = new View_Stray_Animals_Table(args);
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public View_Stray_Animals_Table(String[] args) {
		initialize(args);
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize(String[] args) {
		frame = new JFrame();
		frame.setBounds(100, 100, 689, 455);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblViewStrayAnimalsTable = new JLabel("View 'Stray Animals' Table");
		lblViewStrayAnimalsTable.setHorizontalAlignment(SwingConstants.CENTER);
		lblViewStrayAnimalsTable.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 20));
		lblViewStrayAnimalsTable.setBounds(10, 39, 653, 37);
		frame.getContentPane().add(lblViewStrayAnimalsTable);
		
		table = new JTable();
		table.setModel(new DefaultTableModel(
			new Object[][] {
				{"S/N", "Name", "Surname", "Phone Number", "Email Address", "Location Founded", "Type of Animal", "Gender of Animal", "Estimated Age", "Picture", "Microchip", "Comments"},
				{null, null, null, null, null, null, null, null, null, null, null, null},
				{"1", "Yiannis", "Ioannou", "96565882", "yiannis.ioannou@gmail.com", "Latsia", "Bird", "Male", "2", "C://StayAnimals/1", "NO", null},
				{"2", "Andreas", "Manoli", "99256255", "andreas_man@gmail.com", "Aglantzia", "Dog", "Male", "9", "C://StayAnimals/2", "YES", null},
				{"3", "Magda", "Kountouri", "97521631", "kountouri_1997@yahoo.com", "Engomi", "Other", "Don't Know", "1", "C://StayAnimals/3", "NO", null},
				{"4", "Elena", "Antoniou", "97225453", null, "Nicosia Center", "Cat", "Female", null, "C://StayAnimals/4", "YES", null},
				{"5", "Costas", "Charalambous", "96852325", "charalambous_cos@outlook.com", "Latsia", "Dog", "Male", "10", "C://StayAnimals/5", "YES", null},
				{"6", "Laoura", "Eleftheriou", "96156455", null, "Strovolos", "Dog", "Female", null, "C://StayAnimals/6", "YES", null},
				{"7", "Minas", "Kyriacou", "99214144", "", "Strovolos", "Cat", "Female", null, "C://StayAnimals/7", "NO", null},
				{"8", "Kyriakos", "Panteli", "97254552", "kyriacos.pant@hotmail.com", "Pallouriotisa", "Cat", "Male", "3", "C://StayAnimals/8", "YES", null},
				{"9", "Evengelia", "Georgiou", "97321552", "georgiouEvangelia@gmail.com", "Aglantzia", "Bird", "Female", "3", "C://StayAnimals/9", "NO", null},
				{"10", "Maria", "Kasapi", "99215655", null, "Nicosia Center", "Cat", "Don't Know", "1", "C://StayAnimals/10", "NO", null},
				{"11", "Stalo", "Asprou", "96125855", "astalo03@gmail.com", "Lykavitos", "Cat", "Female", null, "C://StayAnimals/11", "NO", null},
				{"12", "Lefteris", "Argirou", "96789745", null, "Pallouriotisa", "Dog", "Female", "7", "C://StayAnimals/12", "YES", null},
			},
			new String[] {
				"S/N", "Name", "Surname", "Phone Number", "Email Address", "Location Founded", "Type of Animal", "Gender of Animal", "Estimated Age", "Picture", "Microchip", "Comments"
			}
		));
		table.getColumnModel().getColumn(0).setPreferredWidth(30);
		table.getColumnModel().getColumn(4).setPreferredWidth(163);
		table.getColumnModel().getColumn(9).setPreferredWidth(98);
		table.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		table.setBounds(10, 101, 653, 224);
		frame.getContentPane().add(table);
		
		JButton btnClose = new JButton("Close");
		btnClose.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.exit(0);
			}
		});
		btnClose.setFont(new Font("Times New Roman", Font.PLAIN, 14));
		btnClose.setBounds(523, 370, 89, 23);
		frame.getContentPane().add(btnClose);
		
		JButton btnInsertData = new JButton("Insert Data");
		btnInsertData.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Insert_Stray.InsertStray(args);
				frame.setVisible(false);
			}
		});
		btnInsertData.setFont(new Font("Times New Roman", Font.PLAIN, 14));
		btnInsertData.setBounds(353, 370, 107, 23);
		frame.getContentPane().add(btnInsertData);
		
		JButton btnSearch = new JButton("Search");
		btnSearch.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e) {
				Search_Stray.SearchStray(args);
				frame.setVisible(false);
			}
		});
		btnSearch.setFont(new Font("Times New Roman", Font.PLAIN, 14));
		btnSearch.setBounds(53, 370, 89, 23);
		frame.getContentPane().add(btnSearch);
		
		JButton btnEditData = new JButton("Edit Data");
		btnEditData.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Edit_Stray.EditStray(args);
				frame.setVisible(false);
			}
		});
		btnEditData.setFont(new Font("Times New Roman", Font.PLAIN, 14));
		btnEditData.setBounds(203, 370, 89, 23);
		frame.getContentPane().add(btnEditData);
	}
}
