import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.SwingConstants;
import javax.swing.JComboBox;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Select_Table {

	private JFrame frame;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Select_Table window = new Select_Table(args);
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Select_Table(String [] args) {
		initialize(args);
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize(String [] args) {
		frame = new JFrame();
		frame.setBounds(100, 100, 428, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblDatabaseTables = new JLabel("Database Tables");
		lblDatabaseTables.setHorizontalAlignment(SwingConstants.CENTER);
		lblDatabaseTables.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 20));
		lblDatabaseTables.setBounds(10, 11, 392, 24);
		frame.getContentPane().add(lblDatabaseTables);
		
		JLabel lblPleaseSelectA = new JLabel("Please select a table:");
		lblPleaseSelectA.setFont(new Font("Times New Roman", Font.PLAIN, 14));
		lblPleaseSelectA.setBounds(10, 46, 132, 24);
		frame.getContentPane().add(lblPleaseSelectA);
		
		JButton btnAnimalsTable = new JButton("Animal's Table");
		btnAnimalsTable.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				View_Animals_Table.main(args);
				frame.setVisible(false);
			}
		});
		btnAnimalsTable.setFont(new Font("Times New Roman", Font.PLAIN, 14));
		btnAnimalsTable.setBounds(36, 97, 115, 23);
		frame.getContentPane().add(btnAnimalsTable);
		
		JButton btnNewButton = new JButton("Stray Animal's Table");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				View_Stray_Animals_Table.main(args);
				frame.setVisible(false);
			}
		});
		btnNewButton.setFont(new Font("Times New Roman", Font.PLAIN, 14));
		btnNewButton.setBounds(10, 147, 169, 23);
		frame.getContentPane().add(btnNewButton);
		
		JButton btnEventParticipantsTable = new JButton("Event Participants Table");
		btnEventParticipantsTable.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				View_Event_Participants_Table.main(args);
				frame.setVisible(false);
			}
		});
		btnEventParticipantsTable.setFont(new Font("Times New Roman", Font.PLAIN, 14));
		btnEventParticipantsTable.setBounds(10, 209, 169, 23);
		frame.getContentPane().add(btnEventParticipantsTable);
		
		JButton btnNewButton_1 = new JButton("Request for a Dog Table");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				View_Request_Dog.main(args);
				frame.setVisible(false);
			}
		});
		btnNewButton_1.setFont(new Font("Times New Roman", Font.PLAIN, 14));
		btnNewButton_1.setBounds(231, 97, 171, 23);
		frame.getContentPane().add(btnNewButton_1);
		
		JButton btnRequestForA = new JButton("Request for a Cat Table");
		btnRequestForA.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				View_Request_Cat.main(args);
				frame.setVisible(false);
			}
		});
		btnRequestForA.setFont(new Font("Times New Roman", Font.PLAIN, 14));
		btnRequestForA.setBounds(231, 148, 171, 23);
		frame.getContentPane().add(btnRequestForA);
		
		JButton btnExit = new JButton("Exit");
		btnExit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.exit(0);
			}
		});
		btnExit.setFont(new Font("Times New Roman", Font.PLAIN, 14));
		btnExit.setBounds(267, 209, 89, 23);
		frame.getContentPane().add(btnExit);
	}
}
