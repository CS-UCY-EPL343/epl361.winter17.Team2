import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JSpinner;
import javax.swing.JTextField;
import javax.swing.SpinnerNumberModel;
import javax.swing.SwingConstants;

public class Search_Request_Dog {

	private JFrame frame;
	private JTextField textField;
	private JTextField textField_2;
	private JTextField textField_5;
	private JTextField textField_6;
	private JTextField textField_1;
	private JTextField textField_3;
	private JTextField textField_4;
	private JTextField textField_7;

	/**
	 * Launch the application.
	 */
	public static void SearchRequestDog(String [] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Search_Request_Dog window = new Search_Request_Dog(args);
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Search_Request_Dog(String [] args) {
		initialize(args);
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize(String [] args) {
		frame = new JFrame();
		frame.setBounds(100, 100, 417, 545);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblSearchData = new JLabel("Search Data");
		lblSearchData.setHorizontalAlignment(SwingConstants.CENTER);
		lblSearchData.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 20));
		lblSearchData.setBounds(10, 11, 381, 24);
		frame.getContentPane().add(lblSearchData);
		
		JLabel lblAnimalNumber = new JLabel("Adopter's Name:");
		lblAnimalNumber.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		lblAnimalNumber.setBounds(10, 64, 93, 14);
		frame.getContentPane().add(lblAnimalNumber);
		
		textField = new JTextField();
		textField.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		textField.setBounds(113, 61, 86, 20);
		frame.getContentPane().add(textField);
		textField.setColumns(10);
		
		JComboBox comboBox = new JComboBox();
		comboBox.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		comboBox.setModel(new DefaultComboBoxModel(new String[] {"...", "AND", "OR"}));
		comboBox.setBounds(79, 89, 54, 20);
		frame.getContentPane().add(comboBox);
		
		JLabel lblAnimalAge = new JLabel("Adopter's Address:");
		lblAnimalAge.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		lblAnimalAge.setBounds(10, 120, 103, 14);
		frame.getContentPane().add(lblAnimalAge);
		
		JComboBox comboBox_1 = new JComboBox();
		comboBox_1.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		comboBox_1.setModel(new DefaultComboBoxModel(new String[] {"...", "AND", "OR"}));
		comboBox_1.setBounds(79, 146, 54, 20);
		frame.getContentPane().add(comboBox_1);
		
		JLabel lblTypeOfAnimal = new JLabel("Adopter's Phone:");
		lblTypeOfAnimal.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		lblTypeOfAnimal.setBounds(10, 177, 92, 14);
		frame.getContentPane().add(lblTypeOfAnimal);
		
		JComboBox comboBox_2 = new JComboBox();
		comboBox_2.setModel(new DefaultComboBoxModel(new String[] {"...", "AND", "OR"}));
		comboBox_2.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		comboBox_2.setBounds(79, 202, 54, 20);
		frame.getContentPane().add(comboBox_2);
		
		JLabel lblDateOfAdoption = new JLabel("Adopter's Email:");
		lblDateOfAdoption.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		lblDateOfAdoption.setBounds(11, 233, 92, 14);
		frame.getContentPane().add(lblDateOfAdoption);
		
		textField_2 = new JTextField();
		textField_2.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		textField_2.setColumns(10);
		textField_2.setBounds(113, 230, 86, 20);
		frame.getContentPane().add(textField_2);
		
		JComboBox comboBox_4 = new JComboBox();
		comboBox_4.setModel(new DefaultComboBoxModel(new String[] {"...", "AND", "OR"}));
		comboBox_4.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		comboBox_4.setBounds(79, 258, 54, 20);
		frame.getContentPane().add(comboBox_4);
		
		JLabel lblMicrochip = new JLabel("Adopter's Age:");
		lblMicrochip.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		lblMicrochip.setBounds(10, 289, 80, 14);
		frame.getContentPane().add(lblMicrochip);
		
		JComboBox comboBox_5 = new JComboBox();
		comboBox_5.setModel(new DefaultComboBoxModel(new String[] {"...", "AND", "OR"}));
		comboBox_5.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		comboBox_5.setBounds(79, 314, 54, 20);
		frame.getContentPane().add(comboBox_5);
		
		JLabel lblAdoptersName = new JLabel("Family Members:");
		lblAdoptersName.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		lblAdoptersName.setBounds(10, 348, 93, 14);
		frame.getContentPane().add(lblAdoptersName);
		
		JComboBox comboBox_6 = new JComboBox();
		comboBox_6.setModel(new DefaultComboBoxModel(new String[] {"...", "AND", "OR"}));
		comboBox_6.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		comboBox_6.setBounds(79, 377, 54, 20);
		frame.getContentPane().add(comboBox_6);
		
		JLabel lblAdoptersPhone = new JLabel("Discussed with Family:");
		lblAdoptersPhone.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		lblAdoptersPhone.setBounds(10, 408, 123, 20);
		frame.getContentPane().add(lblAdoptersPhone);
		
		JComboBox comboBox_7 = new JComboBox();
		comboBox_7.setModel(new DefaultComboBoxModel(new String[] {"...", "AND", "OR"}));
		comboBox_7.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		comboBox_7.setBounds(79, 439, 54, 20);
		frame.getContentPane().add(comboBox_7);
		
		JButton btnSearch = new JButton("Search");
		btnSearch.setFont(new Font("Times New Roman", Font.PLAIN, 14));
		btnSearch.setBounds(36, 470, 89, 23);
		frame.getContentPane().add(btnSearch);
		
		JButton btnBack = new JButton("Back");
		btnBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				View_Request_Dog.main(args);
				frame.setVisible(false);
			}
		});
		btnBack.setFont(new Font("Times New Roman", Font.PLAIN, 14));
		btnBack.setBounds(158, 470, 89, 23);
		frame.getContentPane().add(btnBack);
		
		JButton btnExit = new JButton("Exit");
		btnExit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.exit(0);
			}
		});
		btnExit.setFont(new Font("Times New Roman", Font.PLAIN, 14));
		btnExit.setBounds(284, 470, 80, 23);
		frame.getContentPane().add(btnExit);
		
		textField_5 = new JTextField();
		textField_5.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		textField_5.setColumns(10);
		textField_5.setBounds(112, 120, 86, 20);
		frame.getContentPane().add(textField_5);
		
		textField_6 = new JTextField();
		textField_6.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		textField_6.setColumns(10);
		textField_6.setBounds(113, 174, 86, 20);
		frame.getContentPane().add(textField_6);
		
		JSpinner spinner = new JSpinner();
		spinner.setModel(new SpinnerNumberModel(18, 18, 66, 1));
		spinner.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		spinner.setBounds(122, 289, 42, 20);
		frame.getContentPane().add(spinner);
		
		JComboBox comboBox_3 = new JComboBox();
		comboBox_3.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		comboBox_3.setBounds(114, 345, 84, 20);
		frame.getContentPane().add(comboBox_3);
		
		JCheckBox chckbxNewCheckBox = new JCheckBox("");
		chckbxNewCheckBox.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		chckbxNewCheckBox.setBounds(152, 408, 21, 23);
		frame.getContentPane().add(chckbxNewCheckBox);
		
		JLabel lblAni = new JLabel("Dog's Number:");
		lblAni.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		lblAni.setBounds(209, 64, 93, 14);
		frame.getContentPane().add(lblAni);
		
		textField_1 = new JTextField();
		textField_1.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		textField_1.setColumns(10);
		textField_1.setBounds(305, 61, 86, 20);
		frame.getContentPane().add(textField_1);
		
		JComboBox comboBox_8 = new JComboBox();
		comboBox_8.setModel(new DefaultComboBoxModel(new String[] {"...", "AND", "OR"}));
		comboBox_8.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		comboBox_8.setBounds(274, 89, 54, 20);
		frame.getContentPane().add(comboBox_8);
		
		JLabel lblCatsName = new JLabel("Dog's Name:");
		lblCatsName.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		lblCatsName.setBounds(209, 120, 93, 14);
		frame.getContentPane().add(lblCatsName);
		
		textField_3 = new JTextField();
		textField_3.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		textField_3.setColumns(10);
		textField_3.setBounds(305, 117, 86, 20);
		frame.getContentPane().add(textField_3);
		
		JLabel lblDogsName = new JLabel("Dog's Name:");
		lblDogsName.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		lblDogsName.setBounds(209, 177, 93, 14);
		frame.getContentPane().add(lblDogsName);
		
		JLabel lblCatsBreed = new JLabel("Dog's Breed:");
		lblCatsBreed.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		lblCatsBreed.setBounds(209, 233, 93, 14);
		frame.getContentPane().add(lblCatsBreed);
		
		textField_4 = new JTextField();
		textField_4.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		textField_4.setColumns(10);
		textField_4.setBounds(305, 174, 86, 20);
		frame.getContentPane().add(textField_4);
		
		textField_7 = new JTextField();
		textField_7.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		textField_7.setColumns(10);
		textField_7.setBounds(305, 230, 86, 20);
		frame.getContentPane().add(textField_7);
		
		JLabel lblCatsGender = new JLabel("Dog's Gender:");
		lblCatsGender.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		lblCatsGender.setBounds(209, 289, 93, 14);
		frame.getContentPane().add(lblCatsGender);
		
		JComboBox comboBox_9 = new JComboBox();
		comboBox_9.setModel(new DefaultComboBoxModel(new String[] {"Select...", "Male", "Female"}));
		comboBox_9.setBounds(305, 286, 86, 20);
		frame.getContentPane().add(comboBox_9);
		
		JLabel lblCatsAge = new JLabel("Dog's Age:");
		lblCatsAge.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		lblCatsAge.setBounds(208, 348, 93, 14);
		frame.getContentPane().add(lblCatsAge);
		
		JSpinner spinner_1 = new JSpinner();
		spinner_1.setModel(new SpinnerNumberModel(1, 1, 15, 1));
		spinner_1.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		spinner_1.setBounds(305, 345, 49, 20);
		frame.getContentPane().add(spinner_1);
		
		JComboBox comboBox_10 = new JComboBox();
		comboBox_10.setModel(new DefaultComboBoxModel(new String[] {"...", "AND", "OR"}));
		comboBox_10.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		comboBox_10.setBounds(274, 146, 54, 20);
		frame.getContentPane().add(comboBox_10);
		
		JComboBox comboBox_11 = new JComboBox();
		comboBox_11.setModel(new DefaultComboBoxModel(new String[] {"...", "AND", "OR"}));
		comboBox_11.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		comboBox_11.setBounds(274, 202, 54, 20);
		frame.getContentPane().add(comboBox_11);
		
		JComboBox comboBox_12 = new JComboBox();
		comboBox_12.setModel(new DefaultComboBoxModel(new String[] {"...", "AND", "OR"}));
		comboBox_12.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		comboBox_12.setBounds(274, 258, 54, 20);
		frame.getContentPane().add(comboBox_12);
		
		JComboBox comboBox_13 = new JComboBox();
		comboBox_13.setModel(new DefaultComboBoxModel(new String[] {"...", "AND", "OR"}));
		comboBox_13.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		comboBox_13.setBounds(274, 314, 54, 20);
		frame.getContentPane().add(comboBox_13);
		
		JLabel lblEmployeed = new JLabel("Employeed:");
		lblEmployeed.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		lblEmployeed.setBounds(209, 411, 93, 14);
		frame.getContentPane().add(lblEmployeed);
		
		JCheckBox checkBox = new JCheckBox("");
		checkBox.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		checkBox.setBounds(274, 407, 21, 23);
		frame.getContentPane().add(checkBox);
		
		JComboBox comboBox_14 = new JComboBox();
		comboBox_14.setModel(new DefaultComboBoxModel(new String[] {"...", "AND", "OR"}));
		comboBox_14.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		comboBox_14.setBounds(274, 377, 54, 20);
		frame.getContentPane().add(comboBox_14);
	}

}
