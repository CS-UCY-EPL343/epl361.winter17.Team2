import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JSpinner;
import javax.swing.JTextField;
import javax.swing.SpinnerNumberModel;
import javax.swing.SwingConstants;

public class Edit_Participant {

	private JFrame frame;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;

	/**
	 * Launch the application.
	 */
	public static void EditParticipant(String [] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Edit_Participant window = new Edit_Participant(args);
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Edit_Participant(String [] args) {
		initialize(args);
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize(String [] args) {
		frame = new JFrame();
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblInsertData = new JLabel("Edit/Update a Table's Record");
		lblInsertData.setHorizontalAlignment(SwingConstants.CENTER);
		lblInsertData.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 20));
		lblInsertData.setBounds(10, 0, 414, 24);
		frame.getContentPane().add(lblInsertData);
		
		JLabel lblName = new JLabel("Name: ");
		lblName.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		lblName.setBounds(47, 99, 46, 14);
		frame.getContentPane().add(lblName);
		
		textField = new JTextField();
		textField.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		textField.setBounds(103, 96, 86, 20);
		frame.getContentPane().add(textField);
		textField.setColumns(10);
		
		JLabel lblSurname = new JLabel("Surname: ");
		lblSurname.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		lblSurname.setBounds(223, 46, 54, 14);
		frame.getContentPane().add(lblSurname);
		
		textField_1 = new JTextField();
		textField_1.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		textField_1.setBounds(287, 43, 86, 20);
		frame.getContentPane().add(textField_1);
		textField_1.setColumns(10);
		
		JLabel lblPhoneNumber = new JLabel("Phone Number:");
		lblPhoneNumber.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		lblPhoneNumber.setBounds(199, 99, 86, 14);
		frame.getContentPane().add(lblPhoneNumber);
		
		textField_2 = new JTextField();
		textField_2.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		textField_2.setBounds(287, 96, 86, 20);
		frame.getContentPane().add(textField_2);
		textField_2.setColumns(10);
		
		JLabel lblEmailAddress = new JLabel("Email Address:");
		lblEmailAddress.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		lblEmailAddress.setBounds(199, 156, 78, 14);
		frame.getContentPane().add(lblEmailAddress);
		
		textField_3 = new JTextField();
		textField_3.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		textField_3.setColumns(10);
		textField_3.setBounds(287, 153, 86, 20);
		frame.getContentPane().add(textField_3);
		
		JLabel lblNumberOfParticipants = new JLabel("Number of Participants:");
		lblNumberOfParticipants.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		lblNumberOfParticipants.setBounds(10, 156, 123, 14);
		frame.getContentPane().add(lblNumberOfParticipants);
		
		JSpinner spinner = new JSpinner();
		spinner.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		spinner.setModel(new SpinnerNumberModel(new Integer(1), new Integer(1), null, new Integer(1)));
		spinner.setBounds(143, 153, 46, 20);
		frame.getContentPane().add(spinner);
		
		JButton btnSave = new JButton("Save");
		btnSave.setFont(new Font("Times New Roman", Font.PLAIN, 14));
		btnSave.setBounds(25, 212, 89, 23);
		frame.getContentPane().add(btnSave);
		
		JButton btnExit = new JButton("Exit");
		btnExit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.exit(0);
			}
		});
		btnExit.setFont(new Font("Times New Roman", Font.PLAIN, 14));
		btnExit.setBounds(317, 213, 89, 23);
		frame.getContentPane().add(btnExit);
		
		JButton btnBack = new JButton("Back");
		btnBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				View_Event_Participants_Table.main(args);
				frame.setVisible(false);
			}
		});
		btnBack.setFont(new Font("Times New Roman", Font.PLAIN, 14));
		btnBack.setBounds(172, 212, 89, 23);
		frame.getContentPane().add(btnBack);
		
		JLabel lblSn = new JLabel("S/N :");
		lblSn.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		lblSn.setBounds(47, 46, 35, 14);
		frame.getContentPane().add(lblSn);
		
		JSpinner spinner_1 = new JSpinner();
		spinner_1.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		spinner_1.setModel(new SpinnerNumberModel(new Integer(1), new Integer(1), null, new Integer(1)));
		spinner_1.setBounds(103, 43, 40, 20);
		frame.getContentPane().add(spinner_1);
	}

}
