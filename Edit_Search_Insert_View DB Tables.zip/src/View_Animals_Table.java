import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.SwingConstants;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

public class View_Animals_Table {

	private JFrame frame;
	private JTable table;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					View_Animals_Table window = new View_Animals_Table(args);
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public View_Animals_Table(String[]args) {
		initialize(args);
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize(String [] args) {
		frame = new JFrame();
		frame.setBounds(100, 100, 750, 455);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblViewAnimalsTable = new JLabel("View 'Animals' Table");
		lblViewAnimalsTable.setHorizontalAlignment(SwingConstants.CENTER);
		lblViewAnimalsTable.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 20));
		lblViewAnimalsTable.setBounds(10, 31, 714, 37);
		frame.getContentPane().add(lblViewAnimalsTable);
		
		table = new JTable();
		table.setModel(new DefaultTableModel(
			new Object[][] {
				{"S/N", "Animal's Number", "Age", "Type of Animal", "Picture", "Date of Adoption", "Microchip", "Adopter's Fullname", "Adopter's Phone", "Adopter's Email", "Comments"},
				{null, null, null, null, null, null, null, null, null, null, null},
				{"1", "215", "2", "Dog", "C://Adoptions/Dogs/1", "28.07.2000", "YES", "Vasos Ioannou", "96525265", "vasos_ioan@gmail.com", null},
				{"2", "265", "3", "Dog", "C://Adoptions/Dogs/5", "01.11.2015", "YES", "Eleftherios Andreou", "97215653", "eleftherios_andreou@gmail.com", null},
				{"3", "156", "1", "Bird", "C://Adoptions/Birds/3", null, "NO", null, null, null, null},
				{"4", "486", "5", "Dog", "C://Adoptions/Dogs/20", null, "YES", null, null, null, null},
				{"5", "345", "7", "Cat", "C://Adoptions/Cats/1", "19.04.2010", "NO", "Maria Papa", "99316516", "papa.mar54@yahoo.gr", null},
				{"6", "148", "9", "Cat", "C://Adoptions/Dogs/9", "20.03.2006", "NO", "Antigoni Theodoulou", "96365165", null, null},
				{"7", "100", "2", "Other", "C://Adoptions/Others/1", null, "NO", null, null, null, null},
				{"8", "386", "9", "Cat", "C://Adoptions/Cats/12", null, "YES", null, null, null, null},
				{"9", "498", "4", "Cat", "C://Adoptions/Cats/4", "09.09.2004", "NO", "Costas Christou", "96462213", null, null},
				{"10", "401", "6", "Other", "C://Adoptions/Others/4", "25.10.2017", "NO", "Christos Antoniou", "99863316", "antonchristos@outlook.com", null},
				{"11", "96", "10", "Dog", "C://Adoptions/Dogs/25", "30.01.2012", "YES", "Maria Michael", "99316353", "marmichael@hotmail.com", null},
				{"12", "35", "3", "Dog", "C://Adoptions/Dogs/17", null, "YES", null, null, null, null},
				{"13", "178", "1", "Cat", "C://Adoptions/Cats/14", "14.11.2013", "YES", "Antonia Georgiou", "97326333", "ageorg@yahoo.com", null},
			},
			new String[] {
				"S/N", "Animal's Number", "Age", "Type of Animal", "Picture", "Date of Adoption", "Microchip", "Adopter's Fullname", "Adopter's Phone", "Adopter's Email", "Comments"
			}
		));
		table.getColumnModel().getColumn(0).setPreferredWidth(30);
		table.getColumnModel().getColumn(4).setPreferredWidth(120);
		table.getColumnModel().getColumn(7).setPreferredWidth(105);
		table.getColumnModel().getColumn(8).setPreferredWidth(90);
		table.getColumnModel().getColumn(9).setPreferredWidth(158);
		table.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		table.setBounds(10, 87, 714, 241);
		frame.getContentPane().add(table);
		
		JButton btnClose = new JButton("Close");
		btnClose.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.exit(0);
			}
		});
		btnClose.setFont(new Font("Times New Roman", Font.PLAIN, 14));
		btnClose.setBounds(570, 370, 89, 23);
		frame.getContentPane().add(btnClose);
		
		JButton btnInsertData = new JButton("Insert Data");
		btnInsertData.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Insert_Animals_Table.Insert_Animal(args);
				frame.setVisible(false);
			}
		});
		btnInsertData.setFont(new Font("Times New Roman", Font.PLAIN, 14));
		btnInsertData.setBounds(387, 370, 107, 23);
		frame.getContentPane().add(btnInsertData);
		
		JButton btnSearch = new JButton("Search");
		btnSearch.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Search_Animal.SearchAnimal(args);
				frame.setVisible(false);
			}
		});
		btnSearch.setFont(new Font("Times New Roman", Font.PLAIN, 14));
		btnSearch.setBounds(61, 370, 89, 23);
		frame.getContentPane().add(btnSearch);
		
		JButton btnEditData = new JButton("Edit Data");
		btnEditData.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Edit_Animal.EditAnimal(args);
				frame.setVisible(false);
			}
		});
		btnEditData.setFont(new Font("Times New Roman", Font.PLAIN, 14));
		btnEditData.setBounds(222, 370, 89, 23);
		frame.getContentPane().add(btnEditData);
	}

}
