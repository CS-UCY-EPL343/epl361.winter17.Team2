package epl361_project;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.BorderLayout;
import javax.swing.ImageIcon;
import java.awt.Font;
import javax.swing.SwingConstants;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.JButton;
import javax.swing.JComboBox;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.Color;
import javax.swing.JPanel;
import javax.swing.UIManager;

public class admin_webuser {

	public JFrame frame;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					admin_webuser window = new admin_webuser();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public admin_webuser() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.getContentPane().setBackground(Color.WHITE);
		frame.setBounds(100, 100, 769, 506);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setIcon(new ImageIcon(admin_webuser.class.getResource("/epl361_project/23721782_1771329182908750_1673673037_n.jpg")));
		lblNewLabel.setBounds(0, 0, 113, 101);
		frame.getContentPane().add(lblNewLabel);
		
		JLabel lblAdminPanel = new JLabel("H&H Administrator Panel");
		lblAdminPanel.setForeground(new Color(178, 34, 34));
		lblAdminPanel.setHorizontalAlignment(SwingConstants.CENTER);
		lblAdminPanel.setFont(new Font("Times New Roman", Font.BOLD, 30));
		lblAdminPanel.setBounds(182, 22, 427, 57);
		frame.getContentPane().add(lblAdminPanel);
		
		    
		
		String tabs[] ={"Home","Successful Stories", "Events","Animal's Gallery","Advices&Tips"};		
		JComboBox comboBox = new JComboBox(tabs);
		comboBox.setFont(new Font("Tahoma", Font.BOLD, 12));
		comboBox.setForeground(Color.BLACK);
		comboBox.setBackground(UIManager.getColor("Button.background"));
		comboBox.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent event) {
                //
                // Get the source of the component, which is our combo
                // box.
                //
                JComboBox comboBox = (JComboBox) event.getSource();

                Object selected = comboBox.getSelectedItem();
                if(selected.toString().equals("Home")) {
                	frame.setVisible(false);
                new Tabs().setVisible(true);}
                else if(selected.toString().equals("Events")) {
                	frame.setVisible(false);
                new EventTab().setVisible(true);}
                else if(selected.toString().equals("Adoptions")) {
                	frame.setVisible(false);
                new Tabs().setVisible(true);}
                else if(selected.toString().equals("Animal's Gallery")) {
                	frame.setVisible(false);
                new GalleryOption().setVisible(true);} 
                else if(selected.toString().equals("Advices&Tips")) {
                	frame.setVisible(false);
                new Tabs().setVisible(true);}
                else if(selected.toString().equals("Successful Stories")) {
                	frame.setVisible(false);
                new Tabs().setVisible(true);}
               
                

            }
        });
		
		comboBox.setBounds(403, 169, 175, 48);
		frame.getContentPane().add(comboBox);
		
		JButton btnView = new JButton("View Website");
		btnView.setFont(new Font("Tahoma", Font.BOLD, 12));
		btnView.setForeground(Color.BLACK);
		btnView.setBackground(UIManager.getColor("Button.background"));
		btnView.setBounds(83, 169, 256, 48);
		frame.getContentPane().add(btnView);
		JButton btnEdit = new JButton("Edit Website");
		btnEdit.setFont(new Font("Tahoma", Font.BOLD, 12));
		btnEdit.setBackground(UIManager.getColor("Button.darkShadow"));
		btnEdit.addActionListener(new ActionListener() {	
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				btnEdit.setVisible(false);
				
				comboBox.setVisible(!comboBox.isVisible());}
						
		});
		comboBox.setVisible(Boolean.FALSE);
		//frame.getContentPane().add(comboBox);
		frame.getContentPane().add(comboBox);
		
		btnEdit.setBounds(390, 169, 256, 48);
		frame.getContentPane().add(btnEdit);
		
		
		
		JLabel label = new JLabel("");
		label.setBackground(Color.WHITE);
		label.setIcon(new ImageIcon(admin_webuser.class.getResource("/epl361_project/1511588_604719249605970_1089402828_n1.jpg")));
		label.setBounds(10, 197, 718, 317);
		frame.getContentPane().add(label);
		
		JPanel panel = new JPanel();
		panel.setBackground(Color.BLACK);
		panel.setBounds(0, 101, 753, 10);
		frame.getContentPane().add(panel);

		btnView.addActionListener(new ActionListener() {	
			@Override
			public void actionPerformed(ActionEvent e) {
				try { 
			         String url = "http://eriakouppari97.mozello.com/";
			         java.awt.Desktop.getDesktop().browse(java.net.URI.create(url));
			       }
			       catch (java.io.IOException ex) {
			           System.out.println(ex.getMessage());
			       }}
						
		});
		
		
	
	}
}
