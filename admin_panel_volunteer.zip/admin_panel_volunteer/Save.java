package epl361_project;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JLabel;
import javax.swing.JTextField;
import java.awt.event.ActionListener;
import java.io.File;
import java.awt.event.ActionEvent;
import javax.swing.SwingConstants;
import java.awt.Color;
import java.awt.Font;

public class Save extends JFrame {

	private JPanel contentPane;
	private JTextField textField;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Save frame = new Save();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Save() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 317, 174);
		contentPane = new JPanel();
		contentPane.setBackground(Color.WHITE);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JButton btnAttachAPhoto = new JButton("Save Post");
		btnAttachAPhoto.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
				Tabs win=new Tabs();
				win.setVisible(true);
				
			}
		});
		btnAttachAPhoto.setBounds(167, 63, 105, 37);
		contentPane.add(btnAttachAPhoto);
		
		JLabel lblGiveName = new JLabel("Give Name");
		lblGiveName.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblGiveName.setForeground(Color.BLACK);
		lblGiveName.setHorizontalAlignment(SwingConstants.LEFT);
		lblGiveName.setBounds(20, 25, 66, 30);
		contentPane.add(lblGiveName);
		
		textField = new JTextField();
		textField.setBounds(20, 66, 124, 30);
		contentPane.add(textField);
		textField.setColumns(10);
	}
}
